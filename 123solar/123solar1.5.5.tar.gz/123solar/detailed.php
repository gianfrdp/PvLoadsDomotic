<?php 
include("styles/globalheader.php");
  
if (!empty ($_POST['date1'])) { $date1= $_POST['date1']; }
if (!empty ($_GET['date2'])) { $date2= $_GET['date2']; }
if (!empty ($_GET['invtnum'])) { $invtnum= $_GET['invtnum']; }
  
if (!empty ($date2)) {
  $ts = strftime("%s", floor($date2/1000));
  $date1=date('d/m/Y', $ts);
}

if (!empty ($_POST['invtnum'])) { $invtnum= $_POST['invtnum']; }
if (!empty ($_POST['checkpower'])) { $checkpower = $_POST['checkpower']; } else { $checkpower='off'; }
if (!empty ($_POST['checkavgpower'])) { $checkavgpower = $_POST['checkavgpower']; } else { $checkavgpower='off'; }
if (!empty ($_POST['checkPROD'])) { $checkPROD= $_POST['checkPROD']; } else { $checkPROD='off'; }
if (!empty ($_POST['checkPEFF'])) { $checkPEFF= $_POST['checkPEFF']; } else { $checkPEFF='off'; }
if (!empty ($_POST['checkI1V'])) { $checkI1V = $_POST['checkI1V']; } else { $checkI1V='off'; }
if (!empty ($_POST['checkI1A'])) { $checkI1A = $_POST['checkI1A']; } else { $checkI1A='off'; }
if (!empty ($_POST['checkI1P'])) { $checkI1P = $_POST['checkI1P']; } else { $checkI1P='off'; }
if (!empty ($_POST['checkPEFF1'])) { $checkPEFF1= $_POST['checkPEFF1']; } else { $checkPEFF1='off'; }  
if (!empty ($_POST['checkI2V'])) { $checkI2V = $_POST['checkI2V']; } else { $checkI2V='off'; }
if (!empty ($_POST['checkI2A'])) { $checkI2A = $_POST['checkI2A']; } else { $checkI2A='off'; }
if (!empty ($_POST['checkI2P'])) { $checkI2P = $_POST['checkI2P']; } else { $checkI2P='off'; }
if (!empty ($_POST['checkPEFF2'])) { $checkPEFF2= $_POST['checkPEFF2']; } else { $checkPEFF2='off'; }  
if (!empty ($_POST['checkGV'])) { $checkGV = $_POST['checkGV']; } else { $checkGV='off'; }
if (!empty ($_POST['checkGA'])) { $checkGA = $_POST['checkGA']; } else { $checkGA='off'; }
if (!empty ($_POST['checkGP'])) { $checkGP = $_POST['checkGP']; } else { $checkGP='off'; }
if (!empty ($_POST['checkFRQ'])) { $checkFRQ = $_POST['checkFRQ']; } else { $checkFRQ='off'; }
if (!empty ($_POST['checkEFF'])) { $checkEFF = $_POST['checkEFF']; } else { $checkEFF='off'; }
if (!empty ($_POST['checkINVT'])) { $checkINVT = $_POST['checkINVT']; } else { $checkINVT='off'; }
if (!empty ($_POST['checkBOOT'])) { $checkBOOT = $_POST['checkBOOT']; } else { $checkBOOT='off'; }

include("scripts/read_invtcfg.php");

if (ereg ("([0-9]{2})/([0-9]{2})/([0-9]{4})", $date1)) { // test date1 
//Nothing selected
if ($checkpower=='off'&&$checkavgpower=='off'&&$checkPROD=='off'&&$checkPEFF=='off'&&$checkI1V=='off'&&$checkI1A=='off'&&$checkI1P=='off'&&$checkPEFF1=='off'&&$checkI2V=='off'&&$checkI2A=='off'&&$checkI2P=='off'&&$checkPEFF2=='off'&&$checkGV=='off'&&$checkGA=='off'&&$checkGP=='off'&&$checkFRQ=='off'&&$checkEFF=='off'&&$checkINVT=='off'&&$checkBOOT=='off') {
$checkavgpower='on';
}
$titledate = substr($date1,0,10) ;
$date1 =(substr($date1,6,4)).(substr($date1,3,2)).(substr($date1,0,2)).".csv";
?>
<script type="text/javascript">

$(document).ready(function()
{
Highcharts.setOptions({
global: {
useUTC: true
},
lang: {
decimalPoint: '<?php echo $DPOINT ?>',
thousandsSep: '<?php echo $THSEP ?>'
}
});

var Mychart, options = {
chart: {
renderTo: 'container',
backgroundColor: null,
zoomType: 'xy',
resetZoomButton: {
                position: {
                    align: 'right',
                    verticalAlign: 'top'
                }
},
loading: {
 labelStyle: { top: '45%' },
 style: { backgroundColor: null }
},
spaceRight:20
},
credits: {enabled: false},
<?php 
echo"
subtitle: { text: '$lgDETAILSUBTITLE' },
xAxis: {
type: 'datetime',
maxZoom: 300000,
dateTimeLabelFormats: {minute: '%H:%M'}
},
yAxis: [";
if ($checkpower=='on'|| $checkavgpower=='on' || $checkI1P=='on'|| $checkI2P=='on'|| $checkGP=='on') {
if (!empty ($date2)) {
  echo "{ max: $YMAX,";
} else {
  echo "{";
}
echo"
min: 0,
maxZoom: 100,
labels: { formatter: function() { return this.value +'W';}},
title: { text: '$lgPOWER'}
},";
}
if ($checkPROD=='on') {
echo "
{
min: 0,
labels: { formatter: function() { return this.value +'kW';}},
title: { text: 'Prod'},
opposite: true       
},";  
}
if ($checkPEFF=='on'||$checkPEFF1=='on'||$checkPEFF2=='on') {
echo "
{
min: 0,
maxZoom: 100,
labels: { formatter: function() { return this.value +'mW/mWp';}},
title: { text: 'Perf'}
},";  
}
if ($checkI1V=='on'|| $checkI2V=='on'|| $checkGV=='on') {
echo "{
maxZoom: 10,
labels: { formatter: function() { return this.value +'V';}},
title: { text: '$lgVOLTAGE'}
},";
}
if ($checkI1A=='on'|| $checkI2A=='on'|| $checkGA=='on') {
echo"{
min: 0,
maxZoom: 1,
labels: { formatter: function() { return this.value +'A';}},
title: { text: '$lgAMPERAGE'}
},";
}
if ($checkFRQ=='on') {
echo"{
min: 40,
maxZoom: 5,
labels: { formatter: function() { return this.value +'Hz';}},
title: { text: '$lgFREQ'},
opposite: true
},";
}
if ($checkEFF=='on') {
echo"{
min: 0,
max:110,
maxZoom: 5,
labels: { formatter: function() { return this.value +'%';}},
title: { text: '$lgEFFICIENCY'},
opposite: true
},";
}
if ($checkINVT=='on'|| $checkBOOT=='on') {
echo "{
min: 10,
maxZoom: 2,
labels: { formatter: function() { return this.value +'c';}},
title: { text: '$lgTEMP'},
opposite: true
},";
}
echo"
],
tooltip: {
formatter: function() {
  var unit = {
  '$lgDPOWERINSTANT' : 'W',
  '$lgDPOWERAVG': 'W',
  '$lgPROD': 'kW',
  '$lgDPEFF' : 'mW/mWp',
  '$lgDCURRENT1': 'A',
  '$lgDVOLTAGE1': 'V',
  '$lgDPOWER1': 'W',
  '$lgDPEFF1' : 'mW/mWp',
  '$lgDCURRENT2': 'A',
  '$lgDVOLTAGE2': 'V',
  '$lgDPOWER2': 'W',
  '$lgDPEFF2' : 'mW/mWp',
  '$lgDGRIDCURRENT': 'A',
  '$lgDGRIDVOLTAGE': 'V',
  'Grid Power': 'W',
  '$lgDFREQ': 'Hz',
  '$lgDEFFICIENCY': '%',
  '$lgDINVERTERTEMP': 'c',
  '$lgDBOOSTERTEMP': 'c'
  }[this.series.name];
return '<b>' + Highcharts.numberFormat(this.y,'1') + unit + '</b><br/>' + Highcharts.dateFormat('%H:%M', this.x)
}
},
legend: {
layout: 'horizontal',
align: 'center',
floating: false,
backgroundColor: '#FFFFFF'
},
plotOptions: {
 areaspline: {
 fillOpacity: 0.3
 }
},
exporting: {
filename: '123Solar-chart',
width: 1200
},
series: []
};
"; // End of echo

// transmit the value to proceed them via _GET
echo "
var invtnum = $invtnum
var date1 = '$date1'
var checkpower='$checkpower'
var checkavgpower='$checkavgpower'
var checkPROD='$checkPROD' 
var checkPEFF='$checkPEFF'                
var checkI1V='$checkI1V'
var checkI1A='$checkI1A'
var checkI1P='$checkI1P'
var checkPEFF1='$checkPEFF1'
var checkI2V='$checkI2V'
var checkI2A='$checkI2A'
var checkI2P='$checkI2P'
var checkPEFF2='$checkPEFF2'
var checkGV='$checkGV'
var checkGA='$checkGA'
var checkGP='$checkGP'
var checkFRQ='$checkFRQ'
var checkEFF='$checkEFF'
var checkINVT='$checkINVT'
var checkBOOT='$checkBOOT'

Mychart= new Highcharts.Chart(options);
Mychart.showLoading();
  $.getJSON('programs/programdetailed.php', { invtnum: invtnum, date1: date1, checkpower: checkpower, checkPROD: checkPROD, checkPEFF: checkPEFF, checkavgpower: checkavgpower, checkI1V: checkI1V, checkI1A: checkI1A, checkI1P: checkI1P, checkPEFF1: checkPEFF1, checkI2V: checkI2V, checkI2A: checkI2A, checkI2P: checkI2P, checkPEFF2: checkPEFF2, checkGV: checkGV, checkGA: checkGA, checkGP: checkGP, checkFRQ: checkFRQ, checkEFF: checkEFF, checkINVT: checkINVT, checkBOOT: checkBOOT }, function(JSONResponse) 
{
options.series = JSONResponse.data;
Mychart= new Highcharts.Chart(options);
Mychart.setTitle({text: JSONResponse.title});
Mychart.hideLoading();
});
 
});
</script>
"; //End of echo
} // End of date valid
?>
<div align="center">
<div id="container" style="width: 100%; height: 550px"></div>
<?php
$year = substr($date1, 0, 4);
$month = substr($date1, 4, 2);
$day = substr($date1, 6, 2);
$sun_info = date_sun_info(strtotime("$year-$month-$day"), $LATITUDE, $LONGITUDE);
echo "<font size='-1'>  $lgSUNRISE ".date("H:i", $sun_info['sunrise'])." - $lgTRANSIT ".date("H:i", $sun_info['transit'])." - $lgSUNSET ".date("H:i", $sun_info['sunset'])."</font>";
?>
<br>&nbsp;
<FORM><INPUT type="button" value="<?php echo "$lgBACK";?>" OnClick="window.location.href='indexdetailed.php'"></FORM>
</div>

<?php include("styles/default/footer.php"); ?>