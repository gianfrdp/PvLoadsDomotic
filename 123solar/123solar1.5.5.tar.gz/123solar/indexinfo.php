<?php 
include("styles/globalheader.php");
include("config/version.php"); 
if(!empty($_POST['invtnum'])) {$invtnum=$_POST['invtnum'];} else {$invtnum=1;}
include("scripts/read_invtcfg.php");
?>
<script type="text/javascript">
  function updateit() {

  $.getJSON("programs/programloggerinfo.php", function(data){
  json = eval(data);
  document.getElementById("cpu").value= json[0].cpuuse;
  document.getElementById("uptime").innerHTML = json[0].uptime;
  document.getElementById("cpuuse").innerHTML = json[0].cpuuse;
  document.getElementById("memtot").innerHTML = json[0].memtot;
  document.getElementById("mem").max= json[0].memtot;
  document.getElementById("mem").value= json[0].memuse;
  document.getElementById("mem").high = (json[0].memtot*0.85);
  document.getElementById("memfree").innerHTML = json[0].memfree;
  document.getElementById("diskuse").innerHTML = json[0].diskuse;
  document.getElementById("diskfree").innerHTML = json[0].diskfree;
  })
  }
  $(document).ready(function() {
  updateit();
  setInterval(updateit, 1000);
  })  
</script> 
<?php
if ($NUMINV>1) {
$currentFile = $_SERVER["PHP_SELF"];

echo"<table width='95%' border=0 align=center cellpadding=0 CELLSPACING=0>
<tr><td>
<form method='POST' action=\"$currentFile\"><select name='invtnum' onchange='this.form.submit()'>";
for ($i=1;$i<=$NUMINV;$i++) {
if ($invtnum==$i) {
echo "<option SELECTED value=$i>";
} else {
echo "<option value=$i>";
}
  echo "$lgINVT$i</option>";
    }
echo "</select></form></td></tr></table>";
} ?>

<table width="95%" border=0 align=center cellpadding="0" CELLSPACING="20">
<tr valign="top"><td>
<img src="images/brightness.png" width="16" height="16" border="0"><b>&nbsp;<?php echo "$lgPLANTINFO";?></b><br>
<hr align=left size=1 width="90%">
<table width="60%" border=0>
<tr><td>
<?php
$PLANT_POWER = number_format($PLANT_POWER, 0, $DPOINT, $THSEP);
echo "$lgLOCATION: <a href=\"http://maps.google.com/maps?q=$LATITUDE,$LONGITUDE\">$LOCATION</a><br>
$lgPLANTPOWER: $PLANT_POWER W<br>";
?>
</td>
<td align="left">
<a href="plantdetails.php?invtnum=<?php echo $invtnum?>"><img src="images/zoom.png" width="32" height="32" border="0"></a>
</td>
</tr></table>

</td><td>
<img src="images/counter.png" width="16" height="16" border="0"><b>&nbsp;<?php echo "$lgCOUNTER";?></b><br>
<hr align=left size=1 width="90%">
<?php
$dir = 'data/invt'.$invtnum.'/csv';
$cmd='ls -r '.$dir.' | grep .csv';
$output = shell_exec($cmd);
$output = explode ("\n",$output);
$log=$dir."/".$output[0];
$lines=file($log);
$contalines = count($lines);
$array = preg_split("/,/",$lines[$contalines-1]);
$KWHP=($array[14]+$INITIALCOUNT)*$CORRECTFACTOR;
$CO2=(($KWHP/1000)*456);
if ($CO2>1000) {
$CO2v="Tonnes";
$CO2 = number_format(($CO2/1000), 3, $DPOINT, $THSEP);
}
else {
$CO2v="Kg";
$CO2 = number_format(($CO2),1, $DPOINT, $THSEP);
}

$KWHP = number_format($KWHP, 1, $DPOINT, $THSEP);

$info="data/invt$invtnum/infos/infos.txt";

$updtd=date ("d M H:i.", filemtime($info));

echo "$lgTOTALPROD $KWHP kWh<br>
<img src='images/leaf.png' width='16' height='16' border='0'> $CO2 $CO2v CO<sub>2</sub>&nbsp;<img src='images/info10.png' width='10' height='10' border='0' title='$lgECOLOGICALINFOB'>
</td></tr>
<tr valign='top'><td>
<img src='images/monitor.png' width='16' height='16' border='0'><b>&nbsp;$lgINVERTERINFO</b>&nbsp;<img src='images/info10.png' width='10' height='10' border='0' title=\"$lgINVERTERINFOB $updtd)\"'><br>
<hr align=left size=1 width='90%'>
";
$lines=file($info);
$contalines = count($lines);
for ($i=0;$i<$contalines;$i++) {
  if ( strlen($lines[$i]) > 1 ) {
    echo "$lines[$i]<br>";
  }
}
?>
</td><td>
<img src="images/gear.png" width="16" height="16" border="0"><b>&nbsp;<?php echo "$lgLOGGERINFO";?></b><br>
<hr align=left size=1 width="90%">
Uptime: <span id='uptime'>--</span>
<br>OS: <?php system("uname -ors"); ?>
<br>System: <?php system("uname -nmi"); ?>
<br><?php system("cat /proc/cpuinfo | grep 'Processor'");?>
<meter id='cpu' high='85' min='0' max='100'></meter> <span id='cpuuse'>--</span>%
<br>Memory: <span id='memtot'>--</span>MB
<meter id='mem' min='0'></meter> <span id='memfree'>--</span>MB free 
<br>Disk Usage: <span id='diskuse'>--</span>, <span id='diskfree'>--</span> avail.
<br>Software: <?php echo $VERSION;?>
</td></tr>
<tr  valign="top"><td> 
<img src="images/calendar-day.png" width="16" height="16" border="0"><b>&nbsp;<?php echo "$lgEVENTS";?></b><br>
<hr align=left size=1 width="90%">
<textarea style="resize: none;background-color: #DCDCDC" cols="55" rows="10">
<?php
$filename="data/invt$invtnum/infos/events.txt";
$handle = fopen($filename, "r");
$contents = fread($handle, filesize($filename));
fclose($handle);
echo $contents;
?>
</textarea> 
</td><td>
<?php
if ($PVOUTPUT==1) {
$SYSID= intval($SYSID); 
echo "<img src='images/link.png' width='16' height='16' border='0'><b>&nbsp;PVoutput</b><br>
<hr align=left size=1 width='90%'>
<br>
<script src='http://pvoutput.org/widget/inc.jsp'></script> 
<script src='http://pvoutput.org/widget/graph.jsp?sid=$SYSID&w=200&h=80&n=1&d=1&t=1&c=1'></script>
<font size='-1'><a href='http://pvoutput.org/listteam.jsp?tid=317'>(123Solar Team)</a></font>
";
}
?>
</td></tr>
</table>

<?php include("styles/".$user_style."/footer.php"); ?>
