<?php 
include('scripts/read_maincfg.php'); 
if ($NUMINV==1) {
header('Location: index_mono.php');
} elseif ($NUMINV>1)  {
header('Location: index_multi.php');
} else {
echo "Constants aren't loaded in memory..
<br><br><a href='debug.php'>Click here to debug</a>
";
}
?>

