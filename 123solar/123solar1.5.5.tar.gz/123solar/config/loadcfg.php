#!/usr/bin/php
<?php
// Load all config to memory
if (isset($_SERVER['REMOTE_ADDR'])) {
    die('Direct access not permitted');
}
define('checkaccess', TRUE);
include('config_main.php');
date_default_timezone_set($DTZ);

$SCRDIR = dirname(__FILE__);

// some checks
$Err   = false;
$input = '{ "jsontest" : " <br>Json extension loaded" }';
$val   = json_decode($input, true);
if ($val["jsontest"] != "") {
} else {
    $Err = true;
    echo "\n/!\ Json extension -NOT- loaded /!\\";
}

if (!extension_loaded('shmop')) {
    $Err = true;
    echo "\n/!\ Shmop extension -NOT- loaded /!\\";
}

if ($Err == true) {
    echo "\nPlease update php.ini.\n\n";
}

if (!extension_loaded('calendar')) {
    echo "Notice : Calendar extension not loaded\n";
}

if (!extension_loaded('curl')) {
    echo "Notice : curl extension not loaded\n";
}

$NUMSMA = 0;
for ($invtnum = 1; $invtnum <= $NUMINV; $invtnum++) {
    include("config_invt$invtnum.php");
    $systemid = '123' . $invtnum; // Invt cfg
    @$shmid = shmop_open($systemid, 'a', 0444, 1024);
    if (!empty($shmid)) {
        shmop_delete($shmid);
        shmop_close($shmid);
    }
    $data = "$INVNAME;$PLANT_POWER;$CORRECTFACTOR;$INITIALCOUNT;$STRING;$PORT;$PROTOCOL;$DAEMONMODE;$ADR;$COMOPTION;$SYNC;$SKIPMONITORING;$DEBUG;$LOGCOM;$YMAX;$YINTERVAL;$PRODXDAYS;$LOCATION;$PANELS1;$ROOF_ORIENTATION1;$ROOF_PITCH1;$PANELS2;$ROOF_ORIENTATION2;$ROOF_PITCH2;$ARRAY1_POWER;$ARRAY2_POWER;$EXPECTEDPROD;$EXPECTJAN;$EXPECTFEB;$EXPECTMAR;$EXPECTAPR;$EXPECTMAY;$EXPECTJUN;$EXPECTJUI;$EXPECTAUG;$EXPECTSEP;$EXPECTOCT;$EXPECTNOV;$EXPECTDEC;$EMAIL;$REPORT;$PUSHO;$POUKEY;$AWPOOLING;$DIGESTMAIL;$FILTER;$SENDALARMS;$SENDMSGS;$NORESPM;$VGRIDUT;$VGRIDT;$VGRIDTM;$RISOT;$RISOTM;$ILEAKT;$ILEAKTM;$PVOUTPUT;$APIKEY;$SYSID;$PVOC";
  
    $shmid = shmop_open($systemid, 'c', 0666, 1024);
    shmop_write($shmid, $data, 0);
    shmop_close($shmid);
    if ($PROTOCOL == 'SMA-RS485' && $DAEMONMODE == 1) { // checking num of SMA to call sma_get daemon
        $NUMSMA++;
    }
    if ($PVOUTPUT==1) {
    $pvoutput   = shell_exec('curl -d tid=317 -H "X-Pvoutput-Apikey: ' . $APIKEY . '" -H "X-Pvoutput-SystemId: ' . $SYSID . '" http://pvoutput.org/service/r2/jointeam.jsp &');
    }
}

$systemid = 1230; // Main cfg to memory
@$shmid = shmop_open($systemid, 'a', 0444, 1024);
if (!empty($shmid)) {
    shmop_delete($shmid);
    shmop_close($shmid);
}
$data  = "$NUMINV;$NUMSMA;$AUTOMODE;$DISTRO;$DTZ;$LATITUDE;$LONGITUDE;$DATEFORMAT;$DPOINT;$THSEP;$TITLE;$SUBTITLE;$KEEPDDAYS;$AMOUNTLOG;$SCRDIR";  
$shmid = shmop_open($systemid, 'c', 0666, 1024);
shmop_write($shmid, $data, 0);
shmop_close($shmid);
?>
