<?php include('control.php'); ?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" >
<title>123Solar Administration</title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link rel="stylesheet" href="../styles/default/css/style.css" type="text/css">
  <script type="text/javascript" src="../js/jquery.min.js"></script>
  <script type="text/javascript" src="../js/jquery-ui.min.js"></script>
  <link rel="stylesheet" href="../js/jqueryuicss/jquery-ui.css" type="text/css">
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
  <style type='text/css'>
    #map {
      width: 550px;
      height: 550px;
    }
  </style>
    <script>
    $(function() {
        $( document ).tooltip();
    });
    </script>
</head>
<body>
<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center" height="90%">
  <tr bgcolor="#FFFFFF"> 
    <td class="cadretopleft" width="128"><img src="../styles/default/images/sun12880.png" width="128" height="80" alt="123Solar"></td>
  <td class="cadretop" align="center"><b>123Solar Administration</b><br></td>
  </tr>
  <tr valign="top"> 
    <td height="100%" COLSPAN="3"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" height="100%">
        <tr valign="top"> 
          <td width="128" class="cadrebotleft" bgcolor="#CCCC66" height="98%"> 
            <div class="menu"> 
            </div>
          </td>
          <td class="cadrebotright" bgcolor="#d3dae2" height="98%"> 
            <table border="0" cellspacing="10" cellpadding="0" width="100%" height="100%" align="center">
              <tr valign="top"> 
                <td> <!-- #BeginEditable "mainbox" -->
<?php
define('checkaccess', TRUE);
include('config_main.php');

echo "<div id='ipDialog' align='center'>
    <div id='map'></div> 
</div>
<div align=center><br><form action='admin_main.php' method='post'>
<fieldset style='width:80%;'>
<legend><b>Main </b></legend>
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td>Number of inverter(s) <input type='number' name='NUMINV2' value='$NUMINV' min='1' max='64' style='width:40px'></td>
<td>
Auto-pooling 
<select name='AUTOMODE2' title='Start and stop the pooling with sunrise/sunset according to your geographical location'>";
 if ($AUTOMODE==1) {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  } else {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  }
echo "
</select>
</td>
<td>Linux distro
<select name='DISTRO2'>
";

$dir = '../scripts/distros/';
$output = glob("$dir*.php");
sort($output);
$cnt=count($output);

for ($i=0;$i<$cnt;$i++){ 
$output[$i] = str_replace("$dir", '', "$output[$i]");
$option = substr($output[$i],0,-4);
if ($DISTRO==$option) {
  echo "<option SELECTED>";
  } else {
  echo "<option>";
  }
echo "$option</option>";
}
echo "
</select>
</td>
</tr>
</table>  
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td colspan=2><b>Localization : </b></td></tr>
<tr><td>
Latitude <input type='number' id='latval' step='any' name='LATITUDE2' value='$LATITUDE' maxlength=6 style='width:70px'> Longitude <input type='number' id='longval' step='any' name='LONGITUDE2' value='$LONGITUDE' maxlength=6 style='width:70px'> <input type='submit' id='bt' value='Edit location'></td>
<td>Date format 
<input type='text' name='DATEFORMAT2' value='$DATEFORMAT' size=4 title='For events log and messages. It must be a in valid php format'>
</td></tr>
<tr><td>TimeZone 
<select name='DTZ2'>";
$timezone_identifiers = DateTimeZone::listIdentifiers();
$cnt=count($timezone_identifiers);
for ($i=0;$i<$cnt;$i++){ 
if ($DTZ==$timezone_identifiers[$i]) {
  echo "<option SELECTED>";
  } else {
  echo "<option>";
  }
echo "$timezone_identifiers[$i]</option>";
}
echo "</select>
</td><td>
Decimal mark <select name='DPOINT2'>";
if ($DPOINT==',') {
  echo "<option value='.'>dot</option>";
  echo "<option value=',' SELECTED>comma</option>";
  } else {
  echo "<option value='.' SELECTED>dot</option>";
  echo "<option value=','>comma</option>";
  }
echo "</select>
Thousands separator  <select name='THSEP2'>";
$THlist=array("",".",","," ","'","·");
$cnt=count($THlist);
for ($i=0;$i<$cnt;$i++){ 
if ($THSEP==$THlist[$i]) {
  echo "<option SELECTED ";
  } else {
  echo "<option ";
  }
 if ($THlist[$i]=="") {
 echo "value=''>null</option>";
 } elseif ($THlist[$i]==" ") {
 echo "value=' '>space</option>";
 } else {
 echo "value='$THlist[$i]'>$THlist[$i]</option>";
 }
}

echo "</select>
</td></tr>
<tr><td colspan=2><b>Web pages : </b></td></tr>
<tr><td>Title <input type='text' name='TITLE2' value='$TITLE' size=50></td>
<td>Subtitle <input type='text' name='SUBTITLE2' value='$SUBTITLE' size=50></td>
</tr>
<tr><td colspan=2><b>Daily cleanup : </td></tr>
<tr></td><td>Keep <input type='number' name='KEEPDDAYS2' value='$KEEPDDAYS' maxlength='4' min='0' style='width:60px' title='0 is unlimited'>fully detailed days
<td>Keep logs size to <input type='number' name='AMOUNTLOG2' value='$AMOUNTLOG' maxlength='4' min='0' style='width:60px'>lines</td></tr>
</table>
</fieldset>  
<div align=center><input type='submit' value='Save main config.'></div>
</form>
";

if (!empty ($_POST['invt_num'])) { $invt_num= $_POST['invt_num']; }
else { 
	if (!empty ($_GET['invt_num'])) {
	$invt_num=($_GET['invt_num']);
	} else {
	$invt_num=1; 
	}
}

    if ($NUMINV>1) { //multi
echo "    
<table border='0' cellspacing='5' cellpadding='0' width='80%' align='center'><tr><td>
<form method='POST' action='admin.php'>
  <div align=left><b>Select an inverter </b><select name='invt_num' onchange='this.form.submit()'>
"; 
for ($i=1;$i<=$NUMINV;$i++) {
if ($invt_num==$i) {
echo "<option SELECTED>";
} else {
echo "<option>";
}
  echo "$i</option>";
    }
echo "
</select></div>
</form></td></tr></table>";
  }// multi
if (file_exists('config_invt'.$invt_num.'.php')) {  
include('config_invt'.$invt_num.'.php'); 
} else {
include('config_invt1.php'); 
$ADR='';
$CORRECTFACTOR='1';
$INITIALCOUNT='0';
$INVNAME='';
$COMOPTION='';
}
echo "
<div align=center><form action='admin_invt.php' method='post'>
<fieldset style='width:80%;'>
<legend><b>Inverter #$invt_num </b></legend>
<div align='left'> Short description name <input type='text' name='INVNAME2' value='$INVNAME' size=10</div><br>
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td colspan=3><b>Specs : </b></td></tr>
<tr>
<td>Plant Power <input type='number' name='PLANT_POWER2' value='$PLANT_POWER' min=0 style='width:60px'>Wp</td>
<td>Correction factor <input type='text' name='CORRECTFACTOR2' value='$CORRECTFACTOR' size=3 min='0' max='2' style='width:60px' title='If your inverter production is not equal with another calibrated counter, you may adujst this parameter
(If your inverter is 2% too optimist, put 0.98)'>
</td>
<td>Initial counter value <input type='number' name='INITIALCOUNT2' value='$INITIALCOUNT' size=3 min=0 style='width:80px' title='If your total counter have been reset or passed 99999kWh'>kWh</td>
</tr><tr>  
<td>
  <select name='PHASE2' title='Single/Three phased' disabled>";
 if ($PHASE==1) {
  echo "<option SELECTED value=1>Three</option><option value=0>Single</option>";
  } else {
  echo "<option value=1>Three</option><option SELECTED value=0>Single</option>";
  }
echo "
</select> phase
</td>
<td>
Show <select name='STRING2'>";
 if ($STRING==1) {
  echo "<option value=0>both</option><option SELECTED value=1>only first</option><option value=2>only second</option>";
  } elseif ($STRING==2) {
  echo "<option value=0>both</option><option value=1>only first</option><option SELECTED value=2>only second</option>";
  } else {
  echo "<option SELECTED value=0>both</option><option value=1>only first</option><option value=2>only second</option>";
  }
echo "
</select> array(s)
</td>
<td></td></tr> 
</table>
<hr>
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td colspan=3><b>Protocol : </b></td></tr>
<tr>
<td>Port <input type='text' name='PORT2' value='$PORT' size=10></td>
<td>
Protocol <select name='PROTOCOL2' onchange='this.form.submit()'>";

$dir = '../scripts/protocols/';
$output = glob("$dir*.php");
sort($output);
$cnt=count($output);

for ($i=0;$i<$cnt;$i++){ 
$output[$i] = str_replace("$dir", '', "$output[$i]");
$option = substr_replace($output[$i],"",-4);
  if (!preg_match("/_checks/",$option)&&!preg_match("/_startup/",$option)) {
	 if ($PROTOCOL==$option) {
	  echo "<option SELECTED>";
 	 } else {
 	  echo "<option>";
 	 }
	 echo "$option</option>";
  }
}
echo "
</select>
";

if ($PROTOCOL=='sma_get') {
echo "Daemon <select name='DAEMONMODE2'>";
 if ($DAEMONMODE==1) {
  echo "<option value=0>No</option><option SELECTED value=1>Yes</option>";
  } else {
  echo "<option SELECTED value=0>No</option><option value=1>Yes</option>";
  }
echo "
  </select></td>";
}
echo "<td>";  
if ($PROTOCOL=='sma_get' || $PROTOCOL=='SMAspot') {
  echo "SMA inverter Num. 0-9 ";
} else {
  echo "RS485 adress ";
}
echo "
<input type='number' name='ADR2' value='$ADR' min='0' max='256' style='width:40px'>
</td>  
</tr><tr>
<td>Communication options <input type='text' name='COMOPTION2' value='$COMOPTION' size=10  title='Not available for all protocols : If you got com. errors, please read the manual for all available options'></td>  
<td>Sync. inverter time daily 
<select name='SYNC2' title='If available'>";
 if ($SYNC==1) {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  } else {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  }
echo "
</select>
</td>  
<td>Skip monitoring <select name='SKIPMONITORING2' title='During inverter maintenance'>";
if ($NUMINV>1) {
 if ($SKIPMONITORING==0) {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  } else {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  }
} else {
  echo "<option SELECTED value=0>No</option>";
}
echo "
</select>
</td></tr><tr>
<td>Debug 
<select name='DEBUG2' title='If available : Check .err files in data/errors'>";
 if ($DEBUG==1) {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  } else {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  }
echo "
</select>
</td>
<td>Log com. errors 
<select name='LOGCOM2' title='It will log communication errors in event'>";
 if ($LOGCOM==1) {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  } else {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  }
echo "
</select>
  </td><td></td></tr>
</table>
";
$PLANT_POWERm=round($PLANT_POWER*0.9,0);
echo "
<hr>
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td colspan=3><b>Front page : </b></td></tr>
<tr><td>yAxis Maximum <input type='number' name='YMAX2' value='$YMAX' min='$PLANT_POWERm' style='width:60px'>W</td>
<td>yAxis Tick interval <input type='number' name='YINTERVAL2' value='$YINTERVAL' min=200 style='width:60px'>W</td>
<td>Display <input type='number' name='PRODXDAYS2' value='$PRODXDAYS' min=7 max=60 style='width:40px'> last days</td>
</tr>
</table>
<hr>
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td colspan=2><b>Info details :</td></tr>
<tr><td>Location <input type='text' name='LOCATION2' value='$LOCATION'></td>
</tr>
<tr><td><u>String 1 detail :</u></td></tr>
<tr><td>Panels for array1 <input type='text' name='PANELS12' value='$PANELS1' size=20> Roof orientation <input type='number' step='any' name='ROOF_ORIENTATION12' value='$ROOF_ORIENTATION1' style='width:60px'>°
Roof pitch <input type='number' step='any' name='ROOF_PITCH12' value='$ROOF_PITCH1' style='width:40px'>°</td></tr>
<tr><td><u>String 2 detail :</u></td></tr>
<tr><td>Panels for array2 <input type='text' name='PANELS22' value='$PANELS2' size=20> Roof orientation <input type='number' step='any' name='ROOF_ORIENTATION22' value='$ROOF_ORIENTATION2' style='width:60px'>°
Roof pitch <input type='number' step='any' name='ROOF_PITCH22' value='$ROOF_PITCH2' style='width:40px'>°</td></tr>
</table>
<hr>
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td colspan=2><b>Dashboard : </b></td></tr>
<tr><td>Array 1 DC Power <input type='number' name='ARRAY1_POWER2' value='$ARRAY1_POWER' min=0 style='width:60px'>Wp</td>
<td>Array 2 DC Power <input type='number' name='ARRAY2_POWER2' value='$ARRAY2_POWER' min=0 style='width:60px'>Wp</td>
</td></tr>
</table>
<hr>
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td colspan=2><b>Expected Production : </b></td></tr>
<tr><td colspan=4>Expected annual production <input type='number' name='EXPECTEDPROD2' value='$EXPECTEDPROD' style='width:80px'>kWh</td>
</tr>
  <tr><td colspan=4><u>Ratio :</u></td></tr> 
<tr><td>Jan. <input type='number' step='any' name='EXPECTJAN2' value='$EXPECTJAN' style='width:60px'>%</td>
<td>Apr. <input type='number' step='any' name='EXPECTAPR2' value='$EXPECTAPR' style='width:60px'>%</td>
<td>Jul. <input type='number' step='any' name='EXPECTJUI2' value='$EXPECTJUI' style='width:60px'>%</td>
<td>Oct. <input type='number' step='any' name='EXPECTOCT2' value='$EXPECTOCT' style='width:60px'>%</td>
</tr>
<tr><td>Feb. <input type='number' step='any' name='EXPECTFEB2' value='$EXPECTFEB' style='width:60px'>%</td>
<td>May <input type='number' step='any' name='EXPECTMAY2' value='$EXPECTMAY' style='width:60px'>%</td>
<td>Aug. <input type='number' step='any' name='EXPECTAUG2' value='$EXPECTAUG' style='width:60px'>%</td>
<td>Nov. <input type='number' step='any' name='EXPECTNOV2' value='$EXPECTNOV' style='width:60px'>%</td>
</tr>
<tr><td>Mar. <input type='number' step='any' name='EXPECTMAR2' value='$EXPECTMAR' style='width:60px'>%</td>
<td>Jun. <input type='number' step='any' name='EXPECTJUN2' value='$EXPECTJUN' style='width:60px'>%</td>
<td>Sep. <input type='number' step='any' name='EXPECTSEP2' value='$EXPECTSEP' style='width:60px'>%</td>
<td>Dec. <input type='number' step='any' name='EXPECTDEC2' value='$EXPECTDEC' style='width:60px'>%</td>
</tr>
</table>
<hr>
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td colspan=2><b>Notification and report : </b></td></tr>
<tr><td>Email <input type='email' name='EMAIL2' value='$EMAIL' title='You need to configure a SMTP client for PHP'> <input type='submit' name='bntsubmit' value='Test mail'></td>
<td>Report production by mail
<select name='REPORT2'>";
 if ($REPORT=="daily") {
  echo "<option value='never'>Never</option><option SELECTED value='daily'>Daily</option><option value='monthly'>Monthly</option>";
  } elseif ($REPORT=="monthly" )  {
  echo "<option value='never'>Never</option><option value='daily'>Daily</option><option SELECTED value='monthly'>Monthly</option>";
  } else {
  echo "<option SELECTED value='never'>Never</option><option value='daily'>Daily</option><option value='monthly'>Monthly</option>";
  }
echo "
</select>
</td></tr>
<tr><td>
Enable Pushover <a href='https://pushover.net/' target='_blank'><img src='../images/link.png' width='16' height='16' border='0'></a>
<select name='PUSHO2'>";
 if ($PUSHO==1) {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  } else {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  }
echo "
</select>
<input type='submit' name='bntsubmit' value='Test Pushover'>
</td><td>
User key <input type='text' size=42 name='POUKEY2' value='$POUKEY'>
</td></tr>
</table>
<hr>
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td colspan=3><b>Alarms and Warnings : </b></td></tr>
<tr>
<td>Check each
<input type='number' name='AWPOOLING2' value='$AWPOOLING' style='width:40px' min=1 max=10>
minute(s)
</td>
<td>Digest messages <input type='number' name='DIGESTMAIL2' value='$DIGESTMAIL' style='width:60px' min=0 max=60 title='The first alarm/warning will be send when detected, the following ones will be grouped. 0 send all when detected'>
minute(s)</td>
<td>Notification filter <input type='text' name='FILTER2' value='$FILTER' title='Put some words seperated by a comma, if you wish to filter some inverter messages notification'></td>
</tr>
<tr><td>Notice inverter alarms
<select name='SENDALARMS2'>";
 if ($SENDALARMS==1) {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  } else {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  }
echo "
</select>
</td>
<td>Notice inverter messages
<select name='SENDMSGS2'>";
 if ($SENDMSGS==1) {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  } else {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  }
echo "
</select>
</td>
<td>  
Warn connection lost 
<select name='NORESPM2' title='Feature only available in Auto-mode. Check if the connection have been lost for more than 60 sec.'>";
if ($NORESPM==1) {
echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
} else {
echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
}
echo "
</select>
</td></tr>
</table>
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td width=50%>VGrid Threshold range < <input type='number' step='any' name='VGRIDUT2' value='$VGRIDUT' style='width:60px' min=80 max=380> ><input type='number' step='any' name='VGRIDT2' value='$VGRIDT' style='width:60px' min=110 max=380>V</td>
<td align=left>
Notice
<select name='VGRIDTM2'>";
 if ($VGRIDTM==1) {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  } else {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  }
echo "
</select>
</td></tr>
<tr><td>Riso Threshold <<input type='number' step='any' name='RISOT2' value='$RISOT' style='width:60px' min=1 max=20>MOhm</td>
<td>
Notice
<select name='RISOTM2'>";
 if ($RISOTM==1) {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  } else {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  }
echo "
</select>
</td></tr>

<tr><td>iLeak Threshold ><input type='number' step='any' name='ILEAKT2' value='$ILEAKT' style='width:60px' min=0.1 max=500>mA</td>
<td>
Notice
<select name='ILEAKTM2'>";
 if ($ILEAKTM==1) {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  } else {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  }
echo "
</select>
</td></tr>
</table>
<hr>
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr><td><b>PVoutput.org : </b></td></tr>
<tr><td><a href='http://www.pvoutput.org/listteam.jsp?tid=317' target='_blank'><img src='../images/link.png' width='16' height='16' border='0'></a> Live Feed 
<select name='PVOUTPUT2' title='Do not forget to change the status interval to 5min in your PVoutput system settings'>";
 if ($PVOUTPUT==1) {
  echo "<option SELECTED value=1>Yes</option><option value=0>No</option>";
  } else {
  echo "<option value=1>Yes</option><option SELECTED value=0>No</option>";
  }
echo "
</select>
API key <input type='text' size=42 name='APIKEY2' value='$APIKEY' title='See in the PVoutput API settings'>&nbsp;Sys. ID <input type='text' title='You may use the same SysID if you own several inverters' size=3 name='SYSID2' value='$SYSID'>
Consumption <select name='PVOC2' title='Feed PVoutput with consumption'>";

$dir = '../scripts/pvoconsumption/';

if ($PVOC=='no') {
	  echo "<option SELECTED>";
} else {
 	  echo "<option>";
}
echo "no</option>";

$output = glob("$dir*.php");
sort($output);
$cnt=count($output);

for ($i=0;$i<$cnt;$i++){ 
$output[$i] = str_replace("$dir", '', "$output[$i]");
$option = substr_replace($output[$i],"",-4);
	 if ($PVOC==$option) {
	  echo "<option SELECTED>";
 	 } else {
 	  echo "<option>";
 	 }
	 echo "$option</option>";
}
echo "
</select>
</td>
</tr>
</table>
</fieldset> 
<table border='0' cellspacing='5' cellpadding='0' width='90%' align='center'>
<tr><td colspan=2 align=center><input type='submit' name='bntsubmit' value='Save inverter config.'>&nbsp;<INPUT TYPE='button' onClick=\"location.href='logout.php'\" value='Logout'></td></tr>
</table>
<input type='hidden' name='invt_num2' value='$invt_num'>
</form></div>";
?>
          <!-- #EndEditable -->
          
          </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>
<script type='text/javascript'>
var map = null;
var infoWindow;
var gmapmarker;

jQuery(document).ready(function() {
    var ipDialog = $("#ipDialog").dialog({
        modal: false,
        width: 590,
        height: 610,
        autoOpen: false,
        resizable: false,
        position: [250,100],
        title: "Longitude Latitude Picker",
        resizeStop: function(event, ui) {
            google.maps.event.trigger(map, 'resize')
        },
        open: function(event, ui) {
            google.maps.event.trigger(map, 'resize');
        },
    });

    $("#bt").on("click", function() {
        googleMap("map", <?php echo "$LATITUDE, $LONGITUDE"; ?>);
        $('#ipDialog').dialog('open');
        return false;
    });
});

function googleMap(selector, lat, lng) {
    var myLatlng = new google.maps.LatLng(lat, lng);

    if (!map) {
        var myOptions = {
            zoom: 4,
            center: myLatlng,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        map = new google.maps.Map(document.getElementById(selector), myOptions);
        gmapmarker = new google.maps.Marker({
            map: map,
            position: myLatlng
        });
        infoWindow = new google.maps.InfoWindow;
        google.maps.event.addListener(map, 'click', function(event) {
            document.getElementById("longval").value = event.latLng.lng().toFixed(3);
            document.getElementById("latval").value = event.latLng.lat().toFixed(3);
            gmapmarker.setPosition(event.latLng);
            if_gmap_updateInfoWindow();
        });

        google.maps.event.addListener(gmapmarker, 'click', function() {
            if_gmap_updateInfoWindow();
            infoWindow.open(map, gmapmarker);
        });

    } else {
        map.setCenter(myLatlng);
    }
}
</script>
</body>
</html>
