<?php
if (file_exists('123pass.php')) {
$lines  = file('123pass.php');
$pepper='123soleil';
$_admin_pass = md5(trim($lines[1]).$pepper);
$_admin_login = 'admin';
}
?>
