<?php include('control.php'); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>123Solar Administration</title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link rel="stylesheet" href="../styles/default/css/style.css" type="text/css">
</head>
<body>
<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center" height="90%">
  <tr bgcolor="#FFFFFF"> 
    <td class="cadretopleft" width="128"><img src="../styles/default/images/sun12880.png" width="128" height="80" alt="123Solar"></td>
  <td class="cadretop" align="center"><b>123Solar Administration</b><br></td>
  </tr>
  <tr valign="top"> 
    <td height="100%" COLSPAN="3"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" height="100%">
        <tr valign="top"> 
          <td width="128" class="cadrebotleft" bgcolor="#CCCC66" height="98%"> 
            <div class="menu"> 
            </div>
          </td>
          <td class="cadrebotright" bgcolor="#d3dae2" height="98%"> 
            <table border="0" cellspacing="10" cellpadding="0" width="100%" height="100%" align="center">
              <tr valign="top"> 
                <td> <!-- #BeginEditable "mainbox" -->
<?php
$unallowedchar = array(";", "<", ">");

if (!empty ($_POST['invt_num2']) && is_numeric($_POST['invt_num2'])) { $invt_num2= $_POST['invt_num2']; }
if (!empty ($_POST['INVNAME2']) && is_string($_POST['INVNAME2'])) { $INVNAME2 = $_POST['INVNAME2']; $INVNAME2 = str_replace($unallowedchar, "",$INVNAME2);} else { $INVNAME2=''; }
  
if (!empty ($_POST['PLANT_POWER2']) && is_numeric($_POST['PLANT_POWER2'])) { $PLANT_POWER2 = $_POST['PLANT_POWER2']; } else { $PLANT_POWER2=5000; }  
if (!empty ($_POST['CORRECTFACTOR2']) && is_numeric($_POST['CORRECTFACTOR2'])) { $CORRECTFACTOR2 = $_POST['CORRECTFACTOR2']; } else { $CORRECTFACTOR2=1; }
if (!empty ($_POST['INITIALCOUNT2']) && is_numeric($_POST['INITIALCOUNT2'])) { $INITIALCOUNT2 = $_POST['INITIALCOUNT2']; } else { $INITIALCOUNT2=0; }
if (!empty ($_POST['STRING2']) && is_numeric($_POST['STRING2'])) { $STRING2 = $_POST['STRING2']; } else { $STRING2=0; }
  
if (!empty ($_POST['PORT2']) && is_string($_POST['PORT2'])) { $PORT2 = $_POST['PORT2']; $PORT2 = str_replace($unallowedchar, "",$PORT2);} else { $PORT2='/dev/ttyUSB0'; }
if (!empty ($_POST['PROTOCOL2']) && is_string($_POST['PROTOCOL2'])) { $PROTOCOL2 = $_POST['PROTOCOL2']; $PROTOCOL2 = str_replace($unallowedchar, "",$PROTOCOL2);} else { $PROTOCOL2='aurora'; }
if (!empty ($_POST['DAEMONMODE2']) && is_numeric($_POST['DAEMONMODE2'])) { $DAEMONMODE2 = $_POST['DAEMONMODE2']; } else { $DAEMONMODE2=0; }
if (!empty ($_POST['ADR2']) && is_numeric($_POST['ADR2'])) { $ADR2 = $_POST['ADR2']; } else { $ADR2=0; }
if (!empty ($_POST['COMOPTION2']) && is_string($_POST['COMOPTION2'])) { $COMOPTION2 = $_POST['COMOPTION2']; $COMOPTION2 = str_replace($unallowedchar, "",$COMOPTION2);} else { $COMOPTION2='';}  
if (!empty ($_POST['SYNC2']) && is_numeric($_POST['SYNC2'])) { $SYNC2 = $_POST['SYNC2']; } else { $SYNC2='0'; }
if (!empty ($_POST['SKIPMONITORING2']) && is_numeric($_POST['SKIPMONITORING2'])) { $SKIPMONITORING2= $_POST['SKIPMONITORING2']; }  else { $SKIPMONITORING2=0; }  
if (!empty ($_POST['DEBUG2']) && is_numeric($_POST['DEBUG2'])) { $DEBUG2 = $_POST['DEBUG2']; } else { $DEBUG2='0'; }
if (!empty ($_POST['LOGCOM2']) && is_numeric($_POST['LOGCOM2'])) { $LOGCOM2 = $_POST['LOGCOM2']; }   else {$LOGCOM2=0; }

if (!empty ($_POST['YMAX2']) && is_numeric($_POST['YMAX2'])) { $YMAX2 = $_POST['YMAX2']; }  else { $YMAX2=5000; }
if (!empty ($_POST['YINTERVAL2']) && is_numeric($_POST['YINTERVAL2'])) { $YINTERVAL2 = $_POST['YINTERVAL2']; } else { $YINTERVAL2=1000; }
if (!empty ($_POST['PRODXDAYS2']) && is_numeric($_POST['PRODXDAYS2'])) { $PRODXDAYS2 = $_POST['PRODXDAYS2']; } else { $PRODXDAYS2=20; }

if (!empty ($_POST['LOCATION2']) && is_string($_POST['LOCATION2'])) { $LOCATION2 = $_POST['LOCATION2']; $LOCATION2 = str_replace($unallowedchar, "",$LOCATION2);} else { $LOCATION2=''; }
if (!empty ($_POST['PANELS12']) && is_string($_POST['PANELS12'])) { $PANELS12 = $_POST['PANELS12']; $PANELS12 = str_replace($unallowedchar, "",$PANELS12);} else { $PANELS12 =''; }
if (!empty ($_POST['ROOF_ORIENTATION12']) && is_numeric($_POST['ROOF_ORIENTATION12'])) { $ROOF_ORIENTATION12 = $_POST['ROOF_ORIENTATION12']; } else  { $ROOF_ORIENTATION12 = 0; } 
if (!empty ($_POST['ROOF_PITCH12']) && is_numeric($_POST['ROOF_PITCH12'])) { $ROOF_PITCH12 = $_POST['ROOF_PITCH12']; } else  { $ROOF_PITCH12 = 0; } 
if (!empty ($_POST['PANELS22']) && is_string($_POST['PANELS22'])) { $PANELS22 = $_POST['PANELS22']; $PANELS22 = str_replace($unallowedchar, "",$PANELS22);} else { $PANELS22 =''; }
if (!empty ($_POST['ROOF_ORIENTATION22']) && is_numeric($_POST['ROOF_ORIENTATION22'])) { $ROOF_ORIENTATION22 = $_POST['ROOF_ORIENTATION22']; } else  { $ROOF_ORIENTATION22 = 0; } 
if (!empty ($_POST['ROOF_PITCH22']) && is_numeric($_POST['ROOF_PITCH22'])) { $ROOF_PITCH22 = $_POST['ROOF_PITCH22']; } else  { $ROOF_PITCH22 = 0; } 

if (!empty ($_POST['ARRAY1_POWER2']) && is_numeric($_POST['ARRAY1_POWER2'])) { $ARRAY1_POWER2 = $_POST['ARRAY1_POWER2']; } else  { $ARRAY1_POWER2 = 2500; } 
if (!empty ($_POST['ARRAY2_POWER2']) && is_numeric($_POST['ARRAY2_POWER2'])) { $ARRAY2_POWER2 = $_POST['ARRAY2_POWER2']; } else  { $ARRAY2_POWER2 = 2500; }

if (!empty ($_POST['EXPECTEDPROD2']) && is_numeric($_POST['EXPECTEDPROD2'])) { $EXPECTEDPROD2 = $_POST['EXPECTEDPROD2']; } else { $EXPECTEDPROD2=5000; }
if (!empty ($_POST['EXPECTJAN2']) && is_numeric($_POST['EXPECTJAN2'])) { $EXPECTJAN2 = $_POST['EXPECTJAN2']; } else { $EXPECTJAN2=2.4; }
if (!empty ($_POST['EXPECTFEB2']) && is_numeric($_POST['EXPECTFEB2'])) { $EXPECTFEB2 = $_POST['EXPECTFEB2']; } else { $EXPECTFEB2=3.6; }
if (!empty ($_POST['EXPECTMAR2']) && is_numeric($_POST['EXPECTMAR2'])) { $EXPECTMAR2 = $_POST['EXPECTMAR2']; } else { $EXPECTMAR2=8.1; }
if (!empty ($_POST['EXPECTAPR2']) && is_numeric($_POST['EXPECTAPR2'])) { $EXPECTAPR2 = $_POST['EXPECTAPR2']; } else { $EXPECTAPR2=12.3; }
if (!empty ($_POST['EXPECTMAY2']) && is_numeric($_POST['EXPECTMAY2'])) { $EXPECTMAY2 = $_POST['EXPECTMAY2']; } else { $EXPECTMAY2=13.9; }
if (!empty ($_POST['EXPECTJUN2']) && is_numeric($_POST['EXPECTJUN2'])) { $EXPECTJUN2 = $_POST['EXPECTJUN2']; } else { $EXPECTJUN2=14.35; }
if (!empty ($_POST['EXPECTJUI2']) && is_numeric($_POST['EXPECTJUI2'])) { $EXPECTJUI2 = $_POST['EXPECTJUI2']; } else { $EXPECTJUI2=13.65; }
if (!empty ($_POST['EXPECTAUG2']) && is_numeric($_POST['EXPECTAUG2'])) { $EXPECTAUG2 = $_POST['EXPECTAUG2']; } else { $EXPECTAUG2=11.8; }
if (!empty ($_POST['EXPECTSEP2']) && is_numeric($_POST['EXPECTSEP2'])) { $EXPECTSEP2 = $_POST['EXPECTSEP2']; } else { $EXPECTSEP2=9.1; }
if (!empty ($_POST['EXPECTOCT2']) && is_numeric($_POST['EXPECTOCT2'])) { $EXPECTOCT2 = $_POST['EXPECTOCT2']; } else { $EXPECTOCT2=5.9; }
if (!empty ($_POST['EXPECTNOV2']) && is_numeric($_POST['EXPECTNOV2'])) { $EXPECTNOV2 = $_POST['EXPECTNOV2']; } else { $EXPECTNOV2=3; }
if (!empty ($_POST['EXPECTDEC2']) && is_numeric($_POST['EXPECTDEC2'])) { $EXPECTDEC2 = $_POST['EXPECTDEC2']; } else { $EXPECTDEC2=1.9; }

if (!empty ($_POST['EMAIL2']) && is_string($_POST['EMAIL2'])) { $EMAIL2 = $_POST['EMAIL2']; $EMAIL2 = str_replace($unallowedchar, "",$EMAIL2);} else { $EMAIL2='no@be.org'; }
if (!empty ($_POST['REPORT2']) && is_string($_POST['REPORT2'])) { $REPORT2 = $_POST['REPORT2']; $REPORT2 = str_replace($unallowedchar, "",$REPORT2);} else { $REPORT2='never'; }
if (!empty ($_POST['PUSHO2']) && is_numeric($_POST['PUSHO2'])) { $PUSHO2= $_POST['PUSHO2']; } else { $PUSHO2=0; }
if (!empty ($_POST['POUKEY2']) && is_string($_POST['POUKEY2'])) { $POUKEY2= $_POST['POUKEY2']; $POUKEY2 = str_replace($unallowedchar, "",$POUKEY2);} else  { $POUKEY2 = ''; } 

if (!empty ($_POST['AWPOOLING2']) && is_numeric($_POST['AWPOOLING2'])) { $AWPOOLING2 = $_POST['AWPOOLING2']; } else { $AWPOOLING2=10; }
if (!empty ($_POST['DIGESTMAIL2']) && is_numeric($_POST['DIGESTMAIL2'])) { $DIGESTMAIL2 = $_POST['DIGESTMAIL2']; } else  { $DIGESTMAIL2 = 0; } 
if (!empty ($_POST['FILTER2']) && is_string($_POST['FILTER2'])) { $FILTER2 = $_POST['FILTER2']; $FILTER2 = str_replace($unallowedchar, "",$FILTER2);} else { $FILTER2='';}
if (!empty ($_POST['SENDALARMS2']) && is_numeric($_POST['SENDALARMS2'])) { $SENDALARMS2 = $_POST['SENDALARMS2']; } else {$SENDALARMS2=0;}
if (!empty ($_POST['SENDMSGS2']) && is_numeric($_POST['SENDMSGS2'])) { $SENDMSGS2 = $_POST['SENDMSGS2']; } else {$SENDMSGS2=0;}
if (!empty ($_POST['NORESPM2']) && is_numeric($_POST['NORESPM2'])) { $NORESPM2 = $_POST['NORESPM2']; } else {$NORESPM2=0;}
if (!empty ($_POST['VGRIDUT2']) && is_numeric($_POST['VGRIDUT2'])) { $VGRIDUT2 = $_POST['VGRIDUT2']; } else {$VGRIDUT2=210;}
if (!empty ($_POST['VGRIDT2']) && is_numeric($_POST['VGRIDT2'])) { $VGRIDT2 = $_POST['VGRIDT2']; }  else {$VGRIDT2=251;}
if (!empty ($_POST['VGRIDTM2']) && is_numeric($_POST['VGRIDTM2'])) { $VGRIDTM2 = $_POST['VGRIDTM2']; }  else {$VGRIDTM2=0;}
if (!empty ($_POST['RISOT2']) && is_numeric($_POST['RISOT2'])) { $RISOT2 = $_POST['RISOT2']; } else {$RISOT2=10;}
if (!empty ($_POST['RISOTM2']) && is_numeric($_POST['RISOTM2'])) { $RISOTM2 = $_POST['RISOTM2']; }  else {$RISOTM2=0;}
if (!empty ($_POST['ILEAKT2']) && is_numeric($_POST['ILEAKT2'])) { $ILEAKT2 = $_POST['ILEAKT2']; }  else {$ILEAKT2=20;}
if (!empty ($_POST['ILEAKTM2']) && is_numeric($_POST['ILEAKTM2'])) { $ILEAKTM2 = $_POST['ILEAKTM2']; }  else {$ILEAKTM2=0;}

if (!empty ($_POST['PVOUTPUT2']) && is_numeric($_POST['PVOUTPUT2'])) { $PVOUTPUT2 = $_POST['PVOUTPUT2']; }  else {$PVOUTPUT2=0;}
if (!empty ($_POST['APIKEY2']) && is_string($_POST['APIKEY2'])) { $APIKEY2 = $_POST['APIKEY2']; $APIKEY2 = str_replace($unallowedchar, "",$APIKEY2);}  else {$APIKEY2='';}
if (!empty ($_POST['SYSID2']) && is_numeric($_POST['SYSID2'])) { $SYSID2 = $_POST['SYSID2']; } else  { $SYSID2 = '0'; } 
if (!empty ($_POST['PVOC2']) && is_string($_POST['PVOC2'])) { $PVOC2 = $_POST['PVOC2']; $PVOC2 = str_replace($unallowedchar, "",$PVOC2);} else  { $PVOC2 = 'no'; } 

if (!empty ($_POST['submit'])) { $submit = $_POST['submit']; }
if (!empty ($_POST['bntsubmit'])) { $bntsubmit = $_POST['bntsubmit']; }

function testemail($adress) 
{ 
   $Syntaxe='#^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,6}$#'; 
   if(preg_match($Syntaxe,$adress)) 
      return true; 
   else 
     return false; 
}

$Err=false;
if (!isset($submit)){
$submit="send";
}

if ($bntsubmit=="Test mail") {
  if(!testemail($EMAIL2)) {
  echo "EMAIL is not correct<br>";
  } else {
   $sent = mail($EMAIL2, "123Solar: Hello", "Hi,\r\n\r\nThanks for using 123Solar !", "From: \"123Solar\" $EMAIL");
  if($sent) {
    echo "
    <br><div align=center><font color='#228B22'><b>Mail sent to $EMAIL2</b></font>
    <br>&nbsp;
    <br>&nbsp;
    <INPUT TYPE='button' onClick=\"location.href='admin.php'\" value='Back'>
    </div>";
     } else {
    echo "
    <br><div align=center><font color='#8B0000'><b>We encountered an error sending your mail</b></font>
    <br>&nbsp;
    <br>&nbsp;
    <INPUT TYPE='button' onClick=\"location.href='admin.php'\" value='Back'>
    </div>";
    }
   }
} elseif ($bntsubmit=="Test Pushover") {

  $pushover = shell_exec('curl -s -F "title=Hello" -F "token=soh71JI4Eln1eecvyV8G87NrRiLwxS" -F "user=' . $POUKEY2 . '" -F "message=Thanks for using 123Solar !" https://api.pushover.net/1/messages.json');
  if(preg_match('/"status":1/', $pushover)) {
      echo "
      <br><div align=center><font color='#228B22'><b>Push message send !</b></font>
      <br>&nbsp;
      <br>&nbsp;
      <INPUT TYPE='button' onClick=\"location.href='admin.php'\" value='Back'>
      </div>";
       } else {
      echo "
      <br><div align=center><font color='#8B0000'><b>We encountered an error sending the message</b></font>
      <br>&nbsp;
      <br>&nbsp;
      <INPUT TYPE='button' onClick=\"location.href='admin.php'\" value='Back'>
      </div>";
      }


} else {
if(!testemail($EMAIL2)) {
echo "EMAIL is not correct<br>";
$Err=true;
}

if (!is_numeric($CORRECTFACTOR2)) {
echo "CORRECTFACTOR value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTJAN2)) {
echo "EXPECTJAN value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTFEB2)) {
echo "EXPECTFEB value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTMAR2)) {
echo "EXPECTMAR value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTAPR2)) {
echo "EXPECTAPR value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTMAY2)) {
echo "EXPECTMAY value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTJUN2)) {
echo "EXPECTJUN value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTJUI2)) {
echo "EXPECTJUI value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTAUG2)) {
echo "EXPECTAUG value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTSEP2)) {
echo "EXPECTSEP value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTOCT2)) {
echo "EXPECTOCT value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTNOV2)) {
echo "EXPECTNOV value not correct<br>";
$Err=true;
}
if (!is_numeric($EXPECTDEC2)) {
echo "EXPECTDEC value not correct<br>";
$Err=true;
}
 
if ($Err!=true) {
  if ($PVOUTPUT2==1) {
  $pvoutput   = shell_exec('curl -d tid=317 -H "X-Pvoutput-Apikey: ' . $APIKEY2 . '" -H "X-Pvoutput-SystemId: ' . $SYSID2 . '" http://pvoutput.org/service/r2/jointeam.jsp &');
  }

  $myFile = 'config_invt'.$invt_num2.'.php';
  $fh = fopen($myFile, 'w+') or die("<font color='#8B0000'><b>Can't open $myFile file. Configuration not saved !</b></font>");
  $stringData="<?php
if(!defined('checkaccess')){die('Direct access not permitted');}

// ### GENERAL FOR INVERTER #$invt_num2
\$INVNAME='$INVNAME2';
// ### SPECS
\$PLANT_POWER=$PLANT_POWER2;    
\$CORRECTFACTOR=$CORRECTFACTOR2;
\$INITIALCOUNT=$INITIALCOUNT2;    
\$STRING=$STRING2;
// #### PROTOCOL
\$PORT='$PORT2';
\$PROTOCOL='$PROTOCOL2';
\$DAEMONMODE=$DAEMONMODE2;
\$ADR=$ADR2;
\$COMOPTION='$COMOPTION2';
\$SYNC=$SYNC2;
\$SKIPMONITORING=$SKIPMONITORING2;
\$DEBUG=$DEBUG2;
\$LOGCOM=$LOGCOM2;

// ### FRONT PAGE
\$YMAX=$YMAX2;
\$YINTERVAL=$YINTERVAL2;
\$PRODXDAYS=$PRODXDAYS2;

// ### INFO DETAILS
\$LOCATION='$LOCATION2';
\$PANELS1='$PANELS12';
\$ROOF_ORIENTATION1=$ROOF_ORIENTATION12;
\$ROOF_PITCH1=$ROOF_PITCH12;
\$PANELS2='$PANELS22';
\$ROOF_ORIENTATION2=$ROOF_ORIENTATION22;
\$ROOF_PITCH2=$ROOF_PITCH22;

// ### DASHBOARD
\$ARRAY1_POWER=$ARRAY1_POWER2;
\$ARRAY2_POWER=$ARRAY2_POWER2;

// ### EXPECTED PRODUCTION
\$EXPECTEDPROD=$EXPECTEDPROD2;
\$EXPECTJAN=$EXPECTJAN2;
\$EXPECTFEB=$EXPECTFEB2;
\$EXPECTMAR=$EXPECTMAR2;
\$EXPECTAPR=$EXPECTAPR2;
\$EXPECTMAY=$EXPECTMAY2;
\$EXPECTJUN=$EXPECTJUN2;
\$EXPECTJUI=$EXPECTJUI2;
\$EXPECTAUG=$EXPECTAUG2;
\$EXPECTSEP=$EXPECTSEP2;
\$EXPECTOCT=$EXPECTOCT2;
\$EXPECTNOV=$EXPECTNOV2;
\$EXPECTDEC=$EXPECTDEC2;

// ### NOTIFICATION
\$EMAIL='$EMAIL2';
\$REPORT='$REPORT2';
\$PUSHO=$PUSHO2;
\$POUKEY='$POUKEY2';

// ### ALARMS AND WARNINGS
\$AWPOOLING=$AWPOOLING2;
\$DIGESTMAIL=$DIGESTMAIL2;
\$FILTER='$FILTER2';
\$SENDALARMS=$SENDALARMS2;
\$SENDMSGS=$SENDMSGS2;
\$NORESPM=$NORESPM2;
\$VGRIDUT=$VGRIDUT2;
\$VGRIDT=$VGRIDT2;
\$VGRIDTM=$VGRIDTM2;
\$RISOT=$RISOT2;
\$RISOTM=$RISOTM2;
\$ILEAKT=$ILEAKT2;
\$ILEAKTM=$ILEAKTM2;

// ### PVOUTPUT.org 
\$PVOUTPUT=$PVOUTPUT2;
\$APIKEY='$APIKEY2';
\$SYSID=$SYSID2;
\$PVOC='$PVOC2';
?>
";
  fwrite($fh, $stringData);
  fclose($fh);

if (!file_exists('../data/invt'.$invt_num2.'/')) {mkdir("../data/invt$invt_num2",0777);}
chmod("../data/invt$invt_num2", 0777); 
if (!file_exists('../data/invt'.$invt_num2.'/csv')) {mkdir("../data/invt$invt_num2/csv",0777);}
chmod("../data/invt$invt_num2/csv", 0777); 
if (!file_exists('../data/invt'.$invt_num2.'/errors')) {mkdir("../data/invt$invt_num2/errors",0777);}
chmod("../data/invt$invt_num2/errors", 0777); 
if (!file_exists('../data/invt'.$invt_num2.'/infos')) {mkdir("../data/invt$invt_num2/infos",0777);}
chmod("../data/invt$invt_num2/infos", 0777); 
if (!file_exists('../data/invt'.$invt_num2.'/mailqueue')) {mkdir("../data/invt$invt_num2/mailqueue",0777);}
chmod("../data/invt$invt_num2/mailqueue", 0777); 
if (!file_exists('../data/invt'.$invt_num2.'/production')) {mkdir("../data/invt$invt_num2/production",0777);}
chmod("../data/invt$invt_num2/production", 0777); 

echo "
<br><div align=center><font color='#228B22'><b>Configuration for inverter #$invt_num2 saved</b></font>
<br>&nbsp;
<br><font size='-1'>123Solar must be restarted for these changes to take effect</font>
<br>&nbsp;
<br>&nbsp;
<INPUT TYPE='button' onClick=\"location.href='admin.php?invt_num=$invt_num2'\" value='Back'>
</div>
";

} else {
echo "
<br><div align=center><font color='#8B0000'><b>Error configuration not saved !</b></font><br>
<INPUT TYPE='button' onClick=\"location.href='admin.php?invt_num=$invt_num2'\" value='Back'>
</div>
";
}

}


?>
          <!-- #EndEditable -->
          
          </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>  
</body>
</html>
