<?php include'control.php'; ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>123Solar Administration</title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link rel="stylesheet" href="../styles/default/css/style.css" type="text/css">
</head>
<body>
<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center" height="90%">
  <tr bgcolor="#FFFFFF"> 
    <td class="cadretopleft" width="128"><img src="../styles/default/images/sun12880.png" width="128" height="80" alt="123Solar"></td>
  <td class="cadretop" align="center"><b>123Solar Administration</b><br></td>
  </tr>
  <tr valign="top"> 
    <td height="100%" COLSPAN="3"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" height="100%">
        <tr valign="top"> 
          <td width="128" class="cadrebotleft" bgcolor="#CCCC66" height="98%"> 
            <div class="menu"> 
            </div>
          </td>
          <td class="cadrebotright" bgcolor="#d3dae2" height="98%"> 
            <table border="0" cellspacing="10" cellpadding="0" width="100%" height="100%" align="center">
              <tr valign="top"> 
                <td> <!-- #BeginEditable "mainbox" -->
<?php
$unallowedchar = array(";", "<", ">");

if (!empty ($_POST['NUMINV2']) && is_numeric($_POST['NUMINV2'])) { $NUMINV2 = $_POST['NUMINV2']; }
if (!empty ($_POST['AUTOMODE2']) && is_numeric($_POST['AUTOMODE2'])) { $AUTOMODE2 = $_POST['AUTOMODE2']; } else { $AUTOMODE2='0'; }
if (!empty ($_POST['DISTRO2']) && is_string($_POST['DISTRO2'])) { $DISTRO2 = $_POST['DISTRO2']; }  
if (!empty ($_POST['LATITUDE2']) && is_numeric($_POST['LATITUDE2'])) { $LATITUDE2 = $_POST['LATITUDE2']; } else { $LATITUDE2=50.61; }
if (!empty ($_POST['LONGITUDE2']) && is_numeric($_POST['LONGITUDE2'])) { $LONGITUDE2 = $_POST['LONGITUDE2']; } else { $LONGITUDE2=4.635; }
if (!empty ($_POST['DTZ2']) && is_string($_POST['DTZ2'])) { $DTZ2= $_POST['DTZ2'];  $DTZ2 = str_replace($unallowedchar, "",$DTZ2);} 
if (!empty ($_POST['DATEFORMAT2']) && is_string($_POST['DATEFORMAT2'])) { $DATEFORMAT2 = $_POST['DATEFORMAT2']; $DATEFORMAT2 = str_replace($unallowedchar, "",$DATEFORMAT2);} else { $DATEFORMAT2='d/m/Y'; }
if (!empty ($_POST['DPOINT2']) && is_string($_POST['DPOINT2'])) { $DPOINT2 = $_POST['DPOINT2']; $DPOINT2 = str_replace($unallowedchar, "",$DPOINT2);} else { $DPOINT2=','; }
if (!empty ($_POST['THSEP2']) && is_string($_POST['THSEP2'])) { $THSEP2 = $_POST['THSEP2']; $THSEP2 = str_replace($unallowedchar, "",$THSEP);} else { $THSEP2='.'; }
if (!empty ($_POST['TITLE2']) && is_string($_POST['TITLE2'])) { $TITLE2 = $_POST['TITLE2']; $TITLE2 = str_replace($unallowedchar, "",$TITLE2);} else { $TITLE2=''; }
if (!empty ($_POST['SUBTITLE2']) && is_string($_POST['SUBTITLE2'])) { $SUBTITLE2 = $_POST['SUBTITLE2']; $SUBTITLE2 = str_replace($unallowedchar, "",$SUBTITLE2);} else { $SUBTITLE2=''; }
if (!empty ($_POST['KEEPDDAYS2']) && is_numeric($_POST['KEEPDDAYS2'])) { $KEEPDDAYS2 = $_POST['KEEPDDAYS2']; } else { $KEEPDDAYS2=0; }
if (!empty ($_POST['AMOUNTLOG2']) && is_numeric($_POST['AMOUNTLOG2'])) { $AMOUNTLOG2 = $_POST['AMOUNTLOG2']; } else { $AMOUNTLOG2=1500; }

if (!is_numeric($LATITUDE2)) {
echo "LATITUDE value not correct<br>";
$Err=true;
}
if (!is_numeric($LONGITUDE2)) {
echo "LONGITUDE value not correct<br>";
$Err=true;
}
  
if (!isset($Err)) {
$Err=false;
}
if ($Err!=true) {
  $myFile = 'config_main.php';
  $fh = fopen($myFile, 'w+') or die("<font color='#8B0000'><b>Can't open $myFile file. Configuration not saved !</b></font>");
  $stringData="<?php
if(!defined('checkaccess')){die('Direct access not permitted');}
// ### GENERAL
\$NUMINV=$NUMINV2;
\$AUTOMODE=$AUTOMODE2;
\$DISTRO='$DISTRO2';

// ### LOCALIZATION
\$DTZ='$DTZ2';
\$LATITUDE=$LATITUDE2;
\$LONGITUDE=$LONGITUDE2;
\$DATEFORMAT='$DATEFORMAT2';
\$DPOINT='$DPOINT2';
\$THSEP='$THSEP2';

// ### WEB PAGE
\$TITLE='$TITLE2';
\$SUBTITLE='$SUBTITLE2';
 
// ### CLEANUP
\$KEEPDDAYS=$KEEPDDAYS2;
\$AMOUNTLOG=$AMOUNTLOG2;
?>
";
fwrite($fh, $stringData);
fclose($fh);

echo "
<br><div align=center><font color='#228B22'><b>Main configuration saved</b></font>
<br>
<br><font size='-1'>123Solar must be restarted for these changes to take effect</font>
<br>&nbsp;
<br>&nbsp;
<INPUT TYPE='button' onClick=\"location.href='admin.php'\" value='Back'>
</div>
";
} else {
echo "
<br><div align=center><font color='#8B0000'><b>Error configuration not saved !</b></font><br>
<INPUT TYPE='button' onClick=\"location.href='admin.php'\" value='Back'>
</div>
";
}

?>
          <!-- #EndEditable -->
          
          </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>  
</body>
</html>
