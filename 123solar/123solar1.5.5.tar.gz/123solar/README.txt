 ╔═════════════════════════════════════════════════════════════════════════════╗
 ║                                                                             ║
 ║                           - 123Solar Web Logger -                           ║
 ║             PHP/JS Monitoring for Aurora Power One and SMA Inverters        ║
 ║                                                                             ║
 ║             Version     : 1.5.5                                             ║
 ║             Made by     : Louviaux Jean-Marc                                ║
 ║             Last Update : 07/10/13                                          ║
 ║                                                                             ║
 ╚═════════════════════════════════════════════════════════════════════════════╝
 
 What can 123Solar do for you ? ───────────────────────────────────────────────

  123Solar is a set of PHP/JS files that will create a web solar logger for Power One Aurora and SMA Inverters.
    
 Prerequisites ────────────────────────────────────────────────────────────────
 
  For Power One, 123Solar rely on the communication application aurora from Curtronics. For RS485 SMA it rely on sma-get writed by Roland Breedveld. For BT SMA, it rely on SMAspot.
  None of these applications are included in this package.
  Json, Calendar and Shmop extensions have to be enable in php.
  
 Warning ──────────────────────────────────────────────────────────────────────
 
  Do not open the inverter enclosure when under load. High-voltage can cause serious injuries !
  
 Installation ─────────────────────────────────────────────────────────────────
 
 - Install the communication application(s) for your inverter(s)
 - Extract 123Solar on your web server's folder. 
 - Install 123Solar with ./install.sh

 Update ───────────────────────────────────────────────────────────────────────

 - Make a backup of the whole 123Solar repertory. Stop the previous instance of 123Solar, remove everything but keep the "data" repertory intact.
 - You may use your previous backuped configuration files. Move then "config_main.php" and "config_invtX.php" to to new config repertory.
 - Launch ./install.sh and start the 123Solar administration, check all parameters then save (always !) the main configuration and the configuration for -each- inverters.

 License & External copyrights ────────────────────────────────────────────────

  123Solar is released under the GNU GPLv3 license (General Public License).
  This license allows you to freely integrate this library in your applications, modify the code and redistribute it in bundled packages as long as your application is also distributed with the GPL license. 

  The GPLv3 license description can be found at http://www.gnu.org/licenses/gpl.html

  Highcharts, the javascript charting library is bundled in this package. It is free for non-commercial use only. (http://highcharts.com)
    
 Support, Update & Contact ────────────────────────────────────────────────────

  To get support, updates or contact please go to http://www.123solar.org
