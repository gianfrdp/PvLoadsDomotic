<?php 
include('styles/globalheader.php');

if (!empty ($_POST['whichyear']) && is_numeric($_POST['whichyear'])) { $whichyear = $_POST['whichyear']; } else { $whichyear= date("Y"); }
if (!empty ($_POST['compare']) && is_string($_POST['compare'])) { $compare = htmlspecialchars($_POST['compare'], ENT_QUOTES, "UTF-8"); } else { $compare=""; }
if(!isset($invtnum)) { $startinv=1; $uptoinv=$NUMINV; } else { $startinv=$invtnum; $uptoinv=$invtnum;}

for ($invt_num=$startinv;$invt_num<=$uptoinv;$invt_num++) {  // Multi
	$invtnum=$invt_num;
	include('scripts/read_invtcfg.php');
	$PLANT_POWERlist[$invt_num]=$PLANT_POWER;
} // multi
if(!empty($_POST['invtnum'])) {
	$invtnum=$_POST['invtnum'];
	$PLANT_POWER=$PLANT_POWERlist[$invtnum];
} else {
	if ($NUMINV>1) {
		$invtnum=0;
		$PLANT_POWER=array_sum($PLANT_POWERlist);
	} else {
	$invtnum=1;
	$PLANT_POWER=$PLANT_POWERlist[$invtnum];
	}
}
?>
<table width="95%" border=0 align=center cellpadding="8">
<tr><td>
<form method="POST" action="indexproduction.php">
<?php
if ($invtnum==0) {
$dir = 'data/invt1/production/'; 
} else {
$dir = 'data/invt'.$invtnum.'/production/';
}
$output = glob($dir . '*.csv');
sort($output);
$xyears=count($output);

if ($NUMINV>1) {
echo "<select name='invtnum' onchange='this.form.submit()'>";
if ($invtnum==0) {
echo "<option SELECTED value=0>$lgALL</option>";
} else {
echo "<option value=0>$lgALL</option>";  
}
for ($i=1;$i<=$NUMINV;$i++) {
if ($invtnum==$i) {
echo "<option SELECTED value=$i>";
} else {
echo "<option value=$i>";
}
  echo "$lgINVT$i</option>";
    }
echo '</select> ';
}
echo"$lgCHOOSEDATE :
<select name='whichyear' onchange='this.form.submit()'>";
$newy = date('dm');
if ($xyears== 0 || $newy =='0101') {
$newy = date('Y');
echo "<option>$newy</option>";
}

for ($i=($xyears-1);$i>=0;$i--){
$output[$i] = str_replace("$dir", '', "$output[$i]");
$option = substr($output[$i],-8,4);
  if ($whichyear==$option) {
  echo '<option SELECTED>';
  } else {
  echo '<option>';
  }
echo "$option</option>";
}
echo '
</select>
';
echo "  
$lgSHOWEXPECTED :
";
if ($compare=='expected') {
  echo "<input type='checkbox' name='compare' value='expected' checked onclick='if(this) this.form.submit();'>";
  } else {
  echo "<input type='checkbox' name='compare' value='expected' onclick='if(this) this.form.submit();'>";
  }
?>
</form>
</td></tr>
</table>

<script type="text/javascript">
var PLANT_POWER='<?php echo $PLANT_POWER;?>';
  
$(document).ready(function() {
Highcharts.setOptions({
global: {useUTC: true},
lang: {
months: ['<?php for($i=1;$i<12;$i++) {echo "$lgMONTH[$i]','";} echo $lgMONTH[12]?>'],
shortMonths: ['<?php for($i=1;$i<12;$i++) {echo "$lgSMONTH[$i]','";} echo $lgSMONTH[12]?>'],
weekdays: ['<?php for($i=1;$i<7;$i++) {echo "$lgWEEKD[$i]','";} echo $lgWEEKD[7]?>']
}
});
var colors = Highcharts.getOptions().colors;
data = [];
  
function setChart(name, data, color, xAxis) {
   chart.series[0].remove();
   chart.addSeries({
     name: name,
     xAxis: xAxis || 0,
     data: data,
     color: color || 'white'
   });
}

    var options = {
        chart: {
                renderTo: 'container',
                type: 'column',
                backgroundColor: null
            },
            subtitle: {text: '<?php echo "$lgPRODSUBTITLE";?>'},
            xAxis: [{
                type: 'datetime',
                labels: {
                    formatter: function() {
                        return Highcharts.dateFormat('%b', this.value);
                    }
                }},
                {
                type: 'datetime',
                offset: 0,
                labels: {
                    formatter: function() {
                        return Highcharts.dateFormat('%a %d %b', this.value);
                    }
                }}],
            yAxis: {
                title: {text: 'kWh'}
            },
          plotOptions: {
            series: {shadow: true,pointInterval: 24 * 3600 * 1000,minPointLength: 3},
                column: {
                    cursor: 'pointer',
                    point: {
                        events: {
                            click: function() {
                                var drilldown = this.drilldown;
                                if (drilldown) {
                                  drilldown.name = Highcharts.getOptions().lang.months[drilldown.month] + ' ' + <?php echo $whichyear ?>+ ' ('+ Highcharts.numberFormat(drilldown.prod_month,'1') + 'kWh)';
                                  chart.setTitle({text: drilldown.name }, { text : '<?php echo "$lgPRODSUBTITLE2";?>'});
                                  setChart(drilldown.name, drilldown.data, drilldown.color, drilldown.xAxis);
                                } else {
                                    chart.setTitle({text: chart.name}, { text : '<?php echo "$lgPRODSUBTITLE";?>'}); 
                                    setChart(name, options.series[0].data);
                                }
                           }
                        }
                    },
                    dataLabels: {
                        enabled: true,
                        color: colors[0],
                        style: {
                            fontWeight: 'bold'
                        },
                        formatter: function() {
                            return Highcharts.numberFormat(this.y,'1');
                        }
                    }
                }
            },
        tooltip: {
            formatter: function() {
              var point = this.point;
              if (this.point.color=='#89A54E') {
                s = '<b>'+ Highcharts.dateFormat('%b', this.x) + ' '+ Highcharts.numberFormat(this.y,'1') +' kWh</b>';
                s += '<b><?php echo " $lgPRODTOOLTIPEXPECTED";?></b>';
              } else if (point.drilldown) {
                s = '<b>'+ Highcharts.dateFormat('%b %Y', this.x) + ': '+ Highcharts.numberFormat(this.y,'1') +' kWh</b>';
                s += '<br><?php echo "$lgEFFICIENCY";?>: ' + (this.y/(PLANT_POWER/1000)).toFixed(2)+ ' kWh/kWp';
                s += '<br><?php echo "$lgPRODTOOLTIP";?><br>';
              } else {
                s = '<b>'+ Highcharts.dateFormat('%A %e %b', this.x) + ': '+ Highcharts.numberFormat(this.y,'1') +' kWh</b>';
                s += '<br><?php echo "$lgEFFICIENCY";?>: ' + Highcharts.numberFormat((this.y/(PLANT_POWER/1000)).toFixed(2)) + ' kWh/kWp';
                s += '<br><?php echo "$lgPRODTOOLTIP2";?>';
              }
              return s;
            }
          },
  exporting: {
  filename: '123Solar-chart',
  width: 1200
  },
  legend: {
  enabled: false
  },
  credits: {
  enabled: false
  },
  series: [{
  name: name,
  data: data,
  color: 'white'}]
 };
<?php
$destination="programs/programproduction.php?whichyear=$whichyear&compare=$compare";
if ($invtnum==0 || $NUMINV==1) {
$parttitle='';
} else {
$parttitle="$lgINVT$invtnum - ";
}
echo "
var invtnum = $invtnum;
$.getJSON('$destination', { invtnum: invtnum }, function(JSONResponse) {
  options.series[0].data = JSONResponse.data;
  chart = new Highcharts.Chart(options);
  prod_y = JSONResponse.prod_y;
  chart.name= '$parttitle $lgPRODTITLE $whichyear ('+ prod_y +'kWh)';
  chart.setTitle({ text: chart.name});
  chart.hideLoading();
";
?>
});
});
</script>

<table width="100%" border=0 align=center cellpadding="0">
<tr><td><div id="container" style="width: 95%; height: 450px"></div></td></tr>
</table>
<?php include("styles/".$user_style."/footer.php"); ?>