<?php include("styles/globalheader.php");
if (!isset($PLANT_POWERtot)) {
    $PLANT_POWERtot = 0;
}
if (!isset($YMAXtot)) {
    $YMAXtot = 0;
}
if (!isset($PRODXDAYStot)) {
    $PRODXDAYStot = 0;
}
if (!isset($YINTERVALtot)) {
    $YINTERVALtot = 0;
}

for ($i=1;$i<=$NUMINV;$i++) {
 $invtnum=$i;
 include("scripts/read_invtcfg.php"); 
 $PLANTPOWER[$i] = $PLANT_POWER;
 $PLANT_POWERtot+=$PLANT_POWER;
 $YMAXtot+=$YMAX;
 if ($PRODXDAYS>$PRODXDAYStot) {
 $PRODXDAYStot= $PRODXDAYS;
 }
 $YINTERVALtot+=$YINTERVAL;
}

?>

<script type="text/javascript">
var myPLANT_POWER=new Array();
<?php
for ($i=1;$i<=$NUMINV;$i++) {
echo "myPLANT_POWER[$i] ='$PLANTPOWER[$i]';\n";
}
echo "var PLANT_POWERtot='$PLANT_POWERtot';\n";
?>
$(document).ready(function() 
{
Highcharts.setOptions({
global: {useUTC: true},
lang: {
thousandsSep: '<?php echo $THSEP ?>',
decimalPoint: '<?php echo $DPOINT ?>',
months: ['<?php for($i=1;$i<12;$i++) {echo "$lgMONTH[$i]','";} echo $lgMONTH[12]?>'],
shortMonths: ['<?php for($i=1;$i<12;$i++) {echo "$lgSMONTH[$i]','";} echo $lgSMONTH[12]?>'],
weekdays: ['<?php for($i=1;$i<7;$i++) {echo "$lgWEEKD[$i]','";} echo $lgWEEKD[7]?>']
}
});

/// Main Day prod ///
var Mychartmain, options1 = {
chart: {
renderTo: 'container1',
backgroundColor: null,
         events: {
            load: function() {
              setInterval(function() {  
               $.getJSON('programs/programmultidayfeed.php', function(data){
               json = eval(data);
<?php
$j=0;
for ($invtnum=1;$invtnum<=$NUMINV;$invtnum++) { 
echo "
    x$invtnum = json[$j].x;
    y$invtnum = json[$j].y;";
$j++;
}
echo "
    scat_MaxTime = json[$j].MaxTime;
    scat_MaxPow = json[$j].MaxPow;";
$j++;
echo "
    scat_LastTime = json[$j].LastTime;
    scat_LastValue = json[$j].LastValue;";
$j++;
echo "          
    ptitle = json[$j].PTITLE;
"; 
$j=0;
for ($invtnum=1;$invtnum<=$NUMINV;$invtnum++) { echo "\n    Mychartmain.series[$j].addPoint([x$invtnum, y$invtnum]);";
$j++;
}
echo "
    Mychartmain.series[$j].data[0].update([scat_MaxTime, scat_MaxPow],false,false,true);
    Mychartmain.series[$j].data[1].update([scat_LastTime, scat_LastValue ],false,false,true);
    Mychartmain.setTitle({ text: ptitle});";
?>
    
    });
    Mychartmain.redraw();
              }, 30000);
         }
    }
},
colors: [
	'#4572A7', 
	'#AA4643', 
	'#89A54E', 
	'#80699B', 
	'#3D96AE', 
	'#DB843D', 
	'#92A8CD', 
	'#A47D7C', 
	'#B5CA92'
],
loading: {
   labelStyle: { top: '45%'  },
   style: { backgroundColor: null }
},
title: {
<?php echo "text: '$lgTODAYTITLE (... kWh)'";?>
},
subtitle: {
  <?php echo "text: '$lgSUNRISE ..... - $lgTRANSIT ..... - $lgSUNSET .....'";?>  
},
credits: {enabled: false},
legend: { enabled: true},
plotOptions: {
            series: {
                stacking: 'normal'
            },
            areaspline: {
                fillOpacity: 0.5,
                   marker: {
                   enabled: false,
                   symbol: 'circle',
                   radius: 2,
                   states: { hover: { enabled: true } }
           }
        },
            scatter: {
  dataLabels: {
  enabled: true,
  color: '#4572A7',
  formatter: function() {
  return Highcharts.numberFormat(this.y,'0') + 'W'
  }
  },
   marker: {
   fillColor: '#FFFFFF',
   lineWidth: 2,
   lineColor: '#4572A7', 
   states: {hover: {enabled: false}}
   }
} 
},
xAxis: {type: 'datetime'},
yAxis: {
title: { text: '<?php echo $lgAVGP ?> (W)'},
max: <?php echo $YMAXtot ?>,
min: 0,  
endOnTick: false,
tickInterval: <?php echo $YINTERVALtot ?>,
minorTickInterval: 'auto'
},
tooltip: {
formatter: function() { return '<b>' + Highcharts.numberFormat(this.y,'1') + 'W' + '</b><br/>' + Highcharts.dateFormat('%H:%M', this.x)}
},
exporting: {enabled: false},
series: []
};

/// Yesterday prod ///
var Mychart2, options2 = {
chart: {
renderTo: 'container2',
backgroundColor: null
},
colors: [
	'#4572A7', 
	'#AA4643', 
	'#89A54E', 
	'#80699B', 
	'#3D96AE', 
	'#DB843D', 
	'#92A8CD', 
	'#A47D7C', 
	'#B5CA92'
],
loading: {
   labelStyle: { top: '45%'  },
   style: { backgroundColor: null }
},
title: {
<?php echo "text: '$lgYESTERDAYTITLE (... kWh)'";?>
},
credits: {enabled: false},
legend: {enabled: false},
plotOptions: {
areaspline: {
  marker: {
    enabled: false,
    symbol: 'circle',
    radius: 2,
    states: {hover: {enabled: true}}
  }
},
scatter: {
  dataLabels: {
  enabled: true,
  color: '#4572A7',
  formatter: function() {
  return Highcharts.numberFormat(this.y,'0') + 'W'
  }
  },
   marker: {
   fillColor: '#FFFFFF',
   lineWidth: 2,
   lineColor: '#4572A7', 
   states: {hover: {enabled: false}}
   }
} 
},
xAxis: {type: 'datetime'},
yAxis: {
<?php echo "max: $YMAXtot,";?>
title: {text: '<?php echo "$lgAVGP";?> (W)'},
endOnTick: false,
minorTickInterval: 'auto',
<?php echo "tickInterval: $YINTERVALtot,";?>
min: 0
},
tooltip: {
formatter: function() {
return '<b>' + Highcharts.numberFormat(this.y,'0') + 'W' + '</b><br/>' + Highcharts.dateFormat('%H:%M', this.x)
}
},
exporting: {enabled: false},
series: []
};

/// Last days prod ///
var Mychart3, options3 = {
chart: {
renderTo: 'container3',
backgroundColor: null,
defaultSeriesType: 'column'
},
colors: [
	'#4572A7', 
	'#AA4643', 
	'#89A54E', 
	'#80699B', 
	'#3D96AE', 
	'#DB843D', 
	'#92A8CD', 
	'#A47D7C', 
	'#B5CA92'
],
loading: {
   labelStyle: { top: '45%'  },
   style: { backgroundColor: null }
},                 
credits: {enabled: false},
title: {
<?php echo "text: '$lgLASTPRODTITLE $PRODXDAYStot $lgDAYS'";?>
},
subtitle: {text: '<?php echo $lgLASTPRODSUBTITLE;?>'},
xAxis: {
type: 'datetime',
tickmarkPlacement: 'on',
dateTimeLabelFormats: {day: '%e %b'}
},
yAxis: {
title: {text: '<?php echo "$lgENERGY";?> (kWh)'},
stackLabels: {
enabled: true,
formatter: function() { return Highcharts.numberFormat(this.total,'1')}
},
minorGridLineWidth: 1,
minorTickInterval: 'auto'
},
min: 0,
legend: {enabled: false},
tooltip: {
formatter: function() {
var point = this.point,
s = '<b>'+Highcharts.dateFormat('%a %e %b', this.x) + ': '+ Highcharts.numberFormat((this.point.stackTotal).toFixed(1),'1') +' kWh</b><br>';
s += '<?php echo "$lgEFFICIENCY";?>: ' + Highcharts.numberFormat((this.point.stackTotal/(PLANT_POWERtot/1000)).toFixed(2),'2')+ ' kWh/kWp<br>';
s +=  this.series.name+': '+ Highcharts.numberFormat(this.y,'1') + ' kWh ('+ Highcharts.numberFormat((this.y/(myPLANT_POWER[this.series.index]/1000)).toFixed(2),'2')+ ' kWh/kWp)';
return s;
}
},
plotOptions: {
    series: {
    shadow: true,	
    minPointLength: 3,
    point:{
      events: {
        click: function(event) {
          window.location = 'detailed.php?invtnum='+this.series.index+'&date2='+this.x;
        }
      }
    }
  },
column: {
stacking: 'normal'
}
},
exporting: {enabled: false},
series: [
{
name : ''
},
<?php
for ($i=1;$i<=$NUMINV;$i++) {
echo "{
name: '$lgINVT$i',
animation: false,
dataLabels: {
    enabled: false
}
}";
  if ($i!=$NUMINV) {
  echo ",";
  }
}
?>
]
};

/// Live gauge ///
var Mygauge, options4 = {
  chart: {
    renderTo: 'container4',
    type: 'gauge',
    backgroundColor: null,
    plotBackgroundColor: null,
    plotBackgroundImage: null,
    plotBorderWidth: 0,
    plotShadow: false,
    height: 250,
          events: {
        load: function() {
        var series = this.series[0];
        var invtnum = <?php echo $invtnum; ?>;  
        setInterval(function () {
        $.getJSON("programs/programmultilive.php", function(data){
    json = eval(data);
    var point = Mygauge.series[0].points[0];
    point.update(json[0].GPTOT);
    document.getElementById('PMAXOTD').innerHTML = json[0].PMAXOTD;
    document.getElementById('PMAXOTDTIME').innerHTML = json[0].PMAXOTDTIME;   
         });
        }, 500);
            }
         }
  },
  title: {
    text: ''
  },
  plotOptions: {
  gauge: {
    pivot: {
      radius: 8,
      borderWidth: 1,
      borderColor: '#303030',
      backgroundColor: {
        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
        stops: [
          [0, '#AAA'],
          [1, '#333']
        ]
      }
    },
    dial: {
      baseLength : 10,
      baseWidth: 8,
      backgroundColor: '#666',
      radius : 70,
      rearLength: 40
    }
  }},
  pane: {
    startAngle: -150,
    endAngle: 150,
            background: [{
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 1, x2: 0, y2: 0 },
                    stops: [
                        [0, '#333'],
                        [1, '#AAA']
                    ]
                },
                borderWidth: 0,
                outerRadius: '115%'
            }, {
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 1, x2: 0, y2:0 },
                    stops: [
                        [0, '#AAA'],
                        [1, '#FFF']
                    ]
                },
                borderWidth: 1,
                outerRadius: '113%'
            },{
                // default background
            }, {
                backgroundColor: Highcharts.svg ? {
                    radialGradient: {
                        cx: 0.5,
                        cy: -0.6,
                        r: 1.6
                    },
                    stops: [
                        [0.5, 'rgba(255, 255, 255, 0.1)'],
                        [0.3, 'rgba(200, 200, 200, 0.1)']
                    ]
                } : null },{
                backgroundColor: Highcharts.svg ? {
                    radialGradient: {
                        cx: 0.5,
                        cy: -0.9,
                        r: 2.6
                    },
                    stops: [
                        [0.5, 'rgba(255, 255, 255, 0.1)'],
                        [0.3, 'rgba(200, 200, 200, 0.1)']
                    ]
                } : null }
                        ]
  },
  yAxis: {
    min: 0,
    max: <?php echo "$YMAXtot";?>,
    
    minorTickInterval: 'auto',
    minorTickWidth: 1,
    minorTickLength: 5,
    minorTickPosition: 'inside',
    minorTickColor: '#666',

    tickPixelInterval: 50,
    tickWidth: 2,
    tickPosition: 'inside',
    tickLength: 15,
    tickColor: '#666',
    labels: {
      step: 2,
      rotation: 'auto'
    },
    title: {
      style: {
        color: '#555',
        fontSize: '18px'
      },
      y: 125,
      text: 'W'
    },
    plotBands: [{
      from: 0,
      to: <?php $Y9=round(($YMAXtot/9),0); echo $Y9;?>,
      color: '#F10D17'
    }, {
      from: <?php echo $Y9;?> ,
      to: <?php echo $Y9*2;?>,
      color: '#F76415'
    }, {
      from: <?php echo $Y9*2;?>,
      to: <?php echo $Y9*3;?>,
      color: '#F29D16'
    }, {
      from: <?php echo $Y9*3;?>,
      to: <?php echo $Y9*4;?>,
      color: '#FFEA32'
    }, {
      from: <?php echo $Y9*4;?>,
      to: <?php echo $Y9*5;?>,
      color: '#FFFF45'
    }, {
      from: <?php echo $Y9*5;?>,
      to: <?php echo $Y9*6;?>,
      color: '#ECFF31'
    }, {
      from: <?php echo $Y9*6;?>,
      to: <?php echo $Y9*7;?>,
      color: '#94DE40'
    }, {
      from: <?php echo $Y9*7;?>,
      to: <?php echo $Y9*8;?>,
      color: '#2EC846'
    }, {
      from: <?php echo $Y9*8;?>,
      to: <?php echo $YMAXtot;?>,
      color: '#0DB44C'
    }]        
  },
  exporting: {enabled: false},
  credits: {enabled: false},
  series: [{
    name: 'power',
    data: [0],
    tooltip: {
      valueSuffix: 'W'
    },
    dataLabels: {
      enabled: true,
  formatter: function() {
    if (this.y>=1000) {
    return Highcharts.numberFormat(this.y,'0');
    } else {
    return Highcharts.numberFormat(this.y,'1');
    }
  },
      color: '#666',
      x: 0,
      y: 40,
      style: {
      fontSize: '12px'
      }
    }
  }]
};
  
Mychartmain= new Highcharts.Chart(options1);
Mychartmain.showLoading();
Mychart2 = new Highcharts.Chart(options2);
Mychart2.showLoading();
Mychart3 = new Highcharts.Chart(options3);
Mychart3.showLoading();
  
$.getJSON('programs/programmultiday.php', function(JSONResponse) {
options1.series = JSONResponse.data;
Mychartmain.hideLoading();
Mychartmain= new Highcharts.Chart(options1);
Mychartmain.setTitle({text: JSONResponse.title}, {text: JSONResponse.subtitle});
});

$.getJSON('programs/programmultiyesterday.php', function(JSONResponse) {
options2.series = JSONResponse.data;
Mychart2.hideLoading();
Mychart2= new Highcharts.Chart(options2);
Mychart2.setTitle({text: JSONResponse.title});
});

<?php
for ($i=1;$i<=$NUMINV;$i++) {
echo "
$.getJSON('programs/programlastdays.php', { invtnum: $i} ,function(JSONResponse) {
Mychart3.series[$i].setData(JSONResponse);
});
";
}
?>
Mychart3.hideLoading();

Mygauge = new Highcharts.Chart(options4);
Mygauge.series[0].data[0].dataLabel.box.hide();

});
</script>   
  
<table width="100%" border=0 align=center cellpadding="0">
<tr><td width="80%"><b><?php echo "$lgPOWERPLANT" ?></b><div id="container1" style="height: 300px"></div></td><td width="20%"><div id="container4" align="center" valign="MIDDLE"></div>
<p align="center"><font size="-2"><?php echo $lgPMAX; ?><br><b id='PMAXOTD'>--</b> W @ <b id='PMAXOTDTIME'>--</b><br>
</font></p>
</td></tr>
</table>
<table width="100%" border=0 align=center cellpadding="0">
<tr><td width="50%"><div id="container2" style="height: 300px"></div></td>
<td width="50%"><div id="container3" style="height: 300px"></div></td></tr>
</table>
<?php include("styles/".$user_style."/footer.php"); ?>
