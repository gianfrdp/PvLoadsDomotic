<?php
// Credit Louviaux Jean-Marc 2013
include('../scripts/read_maincfg.php');
date_default_timezone_set('GMT');
if (!empty($_GET['invtnum']) && is_numeric($_GET['invtnum'])) {
$invtnum = $_GET['invtnum'];
}

include('../scripts/read_invtcfg.php');

if (isset($_COOKIE['user_lang'])) {
    $user_lang = $_COOKIE['user_lang'];
} else {
    $user_lang = 'English';
}

include('../languages/' . $user_lang . '.php');

$dir    = '../data/invt' . $invtnum . '/csv/';
$output = glob($dir . '*.csv');
sort($output);
$cnt = count($output);
$option = $output[$cnt - 2];
$option = str_replace("$dir", '', "$option");

if ($cnt > 1) {
    $file       = file($dir . '/' . $option);
    $contalines = count($file);
    
    $year  = substr($option, 0, 4);
    $month = substr($option, 4, 2);
    $day   = substr($option, 6, 2);
    
    $fileUTCdate = strtotime(date("$year$month$day"));
    $ystdayUTC   = strtotime(date('Ymd', strtotime("-1 day")));
    
    for ($line_num = 1; $line_num < $contalines; $line_num++) {
        $array = preg_split('/,/', $file[$line_num]);
        
        $SDTE[$line_num] = $array[0];
        $KWHT[$line_num] = $array[14];
        
        if ($line_num == 1) {
            $pastline_num = 1;
        } else {
            $pastline_num = $line_num - 1;
        }
        
        $hour    = substr($SDTE[$line_num], 0, 2);
        $minute  = substr($SDTE[$line_num], 3, 2);
        $seconde = substr($SDTE[$line_num], 6, 2);
        
        $pasthour    = substr($SDTE[$pastline_num], 0, 2);
        $pastminute  = substr($SDTE[$pastline_num], 3, 2);
        $pastseconde = substr($SDTE[$pastline_num], 6, 2);
        
        $UTCdate = strtotime($year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute . ':' . $seconde);
        
        // It's more precise to calculate average power between 2 samples
        $diffUTCdate = strtotime($year . '-' . $month . '-' . $day . ' ' . $pasthour . ':' . $pastminute . ':' . $pastseconde);
        $diffTime    = $UTCdate - $diffUTCdate;
        
        if ($diffTime != 0) {
            $AvgPOW = round((((($KWHT[$line_num] - $KWHT[$pastline_num]) * 3600) / $diffTime) * 1000), 1);
        } else {
            $AvgPOW = 0;
        }
        
        $UTCdate          = $UTCdate * 1000;
        $stack[$line_num] = array(
            $UTCdate,
            $AvgPOW
        );
        if (!isset($MaxPow)) {
            $MaxPow = 0;
        }
        if ($AvgPOW >= $MaxPow && $line_num < $contalines) { // Maximum
            $MaxPow    = $AvgPOW;
            $stack2[0] = array(
                $UTCdate,
                $MaxPow
            );
        }
    }
    
    $contalines--;
    $KWHD = round((($KWHT[$contalines] - $KWHT[1]) * $CORRECTFACTOR), 1);
    $KWHD = number_format($KWHD, 1, $DPOINT, $THSEP);
    
    if ($fileUTCdate == $ystdayUTC) {
        $title = stripslashes("$lgYESTERDAYTITLE ($KWHD kWh)");
    } else {
        $dday  = date($DATEFORMAT, $fileUTCdate);
        $title = stripslashes("$dday ($KWHD kWh)");
    }
    
    sort($stack);
    $data = array(
        0 => array(
            'name' => 'Avg. Power',
            'type' => 'areaspline',
            'data' => $stack
        ),
        1 => array(
            'name' => 'Max',
            'type' => 'scatter',
            'data' => $stack2
        )
    );
    
    $jsonreturn = array(
        'data' => $data,
        'title' => $title
    );
} else {
    $stack      = null;
    $data       = array(
        0 => array(
            'name' => 'Avg. Power',
            'type' => 'areaspline',
            'data' => $stack
        )
    );
    $title      = stripslashes("$lgYESTERDAYTITLE (--- kWh)");
    $jsonreturn = array(
        'data' => $data,
        'title' => $title
    );
}
header("Content-type: text/json");
echo json_encode($jsonreturn);
?>
