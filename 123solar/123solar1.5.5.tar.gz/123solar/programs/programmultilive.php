<?php
// Credit Louviaux Jean-Marc 2013
include('../scripts/read_maincfg.php');
date_default_timezone_set($DTZ);

function tricsv($var)
{
    return !is_dir($var) && preg_match('/\.csv$/i', $var);
}

for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) {
    $invtnum = $invt_num;
    include('../scripts/read_invtcfg.php');
    $systemid = '1231' . $invt_num;
    @$shmid = shmop_open($systemid, 'a', 0444, 256);
    if (!empty($shmid)) {
        $livedash[0] = shmop_read($shmid, 0, 256);
        shmop_close($shmid);
    } else {
        $nowUTC      = strtotime(date('Ymd H:i:s'));
        $livedash[0] = "$nowUTC,0,0,0,0,0,0,0,0,0,0,0,0,0,0";
    }
    $array = preg_split('/,/', $livedash[0]);
    
    if (!isset($GPTOT)) {
        $GPTOT = 0;
    }
    
    $array[9] *= $CORRECTFACTOR;
    $GPTOT += $array[9];
}

if ($GPTOT > 1000) {
    $GPTOT = round($GPTOT, 0);
} else {
    $GPTOT = round($GPTOT, 1);
}

@$shmid = shmop_open(12320, 'a', 0444, 32); //pmotd
if (!empty($shmid)) {
    $data = shmop_read($shmid, 0, 32);
} else {
    $nowUTC      = strtotime(date('Ymd H:i:s'));
    $data = "$nowUTC,0";
}
$pmotdarray = preg_split('/,/', $data);
$pmotd_t    = date('H:i', $pmotdarray[0]);

$arr = array(
    'GPTOT' => floatval($GPTOT),
    'PMAXOTD' => floatval(round($pmotdarray[1], 0)),
    'PMAXOTDTIME' => ($pmotd_t)
);

$ret = array(
    $arr
);
header("Content-type: text/json");
echo json_encode($ret);
?>
