<?php
// Credit Louviaux Jean-Marc 2013
include('../scripts/read_maincfg.php');
date_default_timezone_set('GMT');

if (!empty($_GET['invtnum']) && is_numeric($_GET['invtnum'])) {
$invtnum = $_GET['invtnum'];
}

if (isset($_COOKIE['user_lang'])) {
    $user_lang = $_COOKIE['user_lang'];
} else {
    $user_lang = 'English';
}
;
include('../languages/' . $user_lang . '.php');

if (!empty($_GET['whichyear']) && is_numeric($_GET['whichyear'])) {
    $whichyear = $_GET['whichyear'];
} else {
    $whichyear = date('Y');
}
if (!empty($_GET['compare']) && is_string($_GET['compare'])) {
    $compare = $_GET['compare'];
    $compare = htmlspecialchars($compare, ENT_QUOTES, "UTF-8");
} else {
    $compare = '';
}

if ($invtnum == 0) {
    $startinv = 1;
    $uptoinv  = $NUMINV;
} else {
    $startinv = $invtnum;
    $uptoinv  = $invtnum;
}

if ($compare == 'expected') {
    $upto = 24;
    for ($i = 1; $i < 24; $i++) {
        $prod_month[$i] = 0;
        $i++;
    }
} else {
    $upto = 12;
}

for ($invt_num = $startinv; $invt_num <= $uptoinv; $invt_num++) { // Multi
    $invtnum = $invt_num;
    include('../scripts/read_invtcfg.php');
    $dir = '../data/invt' . $invt_num . '/production/';
    
    if (file_exists($dir . 'energy' . $whichyear . '.csv')) {
        $thefile    = file($dir . 'energy' . $whichyear . '.csv');
        $contalines = count($thefile);
        for ($line_num = 0; $line_num < $contalines; $line_num++) {
            $array           = preg_split("/,/", $thefile[$line_num]);
            $year            = substr($array[0], 0, 4);
            $month           = substr($array[0], 4, 2);
            $day             = substr($array[0], 6, 2);
            $KWHT[$line_num] = $array[1] * $CORRECTFACTOR;
            $date1           = strtotime($year . "-" . $month . "-" . $day);
            if ($compare == "expected") {
                $month = (int) (($month - 1) * 2);
            } else {
                $month = (int) ($month - 1);
            }
            $day                               = (int) ($day);
            $subdate[$month][$day]             = $date1 * 1000;
            $prod_day[$invt_num][$month][$day] = round($KWHT[$line_num], 1);
        } // end of looping through the file
    }
    
    if ($whichyear == date('Y')) { // Add today prod
        $dir     = '../data/invt' . $invt_num . '/csv/';
        $output2 = glob($dir . '*.csv');
        sort($output2);
        $cnt        = count($output2);
	$option = $output2[$cnt - 1];
	$option = str_replace($dir, '', $option);
        $lines      = file($dir . '/' . $option);
        $contalines = count($lines);
        $array      = preg_split('/,/', $lines[1]);
        $array2     = preg_split('/,/', $lines[$contalines - 1]);
        $year       = substr($option, 0, 4);
        $month      = substr($option, 4, 2);
        $day        = substr($option, 6, 2);
        $date1      = strtotime($year . "-" . $month . "-" . $day);
        if ($compare == 'expected') {
            $month = (int) (($month - 1) * 2);
        } else {
            $month = (int) ($month - 1);
        }
        $day                               = (int) ($day);
        $subdate[$month][$day]             = $date1 * 1000;
        $prod_day[$invt_num][$month][$day] = round((($array2[14] - $array[14]) * $CORRECTFACTOR), 1);
    } // end of today prod
    
    // Fill blanks dates
    $stmonth = 1;
    for ($h = 0; $h < $upto; $h++) {
        $daythatm = cal_days_in_month(CAL_GREGORIAN, $stmonth, $whichyear);
        if (isset($prod_day[$invt_num][$h])) {
            $month_len = count($prod_day[$invt_num][$h]);
        } else {
            $month_len = 0;
        }
        if ($month_len < $daythatm) {
            for ($i = 1; $i <= $daythatm; $i++)
                if (!isset($prod_day[$invt_num][$h][$i])) {
                    $date1                       = strtotime($whichyear . "-" . $stmonth . "-" . $i);
                    $subdate[$h][$i]             = $date1 * 1000;
                    $prod_day[$invt_num][$h][$i] = 0;
                }
        }
        if ($compare == 'expected') {
            $h++;
        }
        $stmonth++;
    }
    
    if ($compare == 'expected') { // Expected
        $EXPECTEDPROD = $EXPECTEDPROD / 100;
        $prod_month[1] += round(($EXPECTJAN * $EXPECTEDPROD), 0);
        $prod_month[3] += round(($EXPECTFEB * $EXPECTEDPROD), 0);
        $prod_month[5] += round(($EXPECTMAR * $EXPECTEDPROD), 0);
        $prod_month[7] += round(($EXPECTAPR * $EXPECTEDPROD), 0);
        $prod_month[9] += round(($EXPECTMAY * $EXPECTEDPROD), 0);
        $prod_month[11] += round(($EXPECTJUN * $EXPECTEDPROD), 0);
        $prod_month[13] += round(($EXPECTJUI * $EXPECTEDPROD), 0);
        $prod_month[15] += round(($EXPECTAUG * $EXPECTEDPROD), 0);
        $prod_month[17] += round(($EXPECTSEP * $EXPECTEDPROD), 0);
        $prod_month[19] += round(($EXPECTOCT * $EXPECTEDPROD), 0);
        $prod_month[21] += round(($EXPECTNOV * $EXPECTEDPROD), 0);
        $prod_month[23] += round(($EXPECTDEC * $EXPECTEDPROD), 0);
    }
} // End of multi

for ($invt_num = $startinv; $invt_num <= $uptoinv; $invt_num++) { // Multi
    for ($h = 0; $h < $upto; $h++) {
        if (!isset($prod_month[$h])) {
            $prod_month[$h] = 0;
        }
        $prod_month[$h] += array_sum($prod_day[$invt_num][$h]); // Month prod
        if ($compare == 'expected') {
            $h++;
        }
    }
} // End of multi
if (!isset($prod_year)) {
    $prod_year = 0;
}
for ($h = 0; $h < $upto; $h++) {
    $prod_year += $prod_month[$h]; // Year prod  
    if ($compare == 'expected') {
        $h++;
    }
}

$prod_year = number_format($prod_year, 1, $DPOINT, $THSEP);

$i = 1;
$m = 0;
for ($h = 0; $h < $upto; $h++) { // Rearrange 'em all
    $cnt       = count($subdate[$h]);
    $k         = 0;
    $date1     = strtotime($whichyear . '-' . $i . '-01');
    $fstd[$h]  = $date1 * 1000;
    $date1     = strtotime($whichyear . '-' . $i . '-15');
    $fstd2[$h] = $date1 * 1000;
    for ($j = 1; $j <= $cnt; $j++) {
        for ($invt_num = $startinv; $invt_num <= $uptoinv; $invt_num++) { // Multi
            if (!isset($prod_day2[$k])) {
                $prod_day2[$k] = 0;
            }
            $prod_day2[$k] += $prod_day[$invt_num][$h][$j];
        } //  End of multi
        $drilldata[$k] = array(
            $subdate[$h][$j],
            $prod_day2[$k]
        );
        $k++;
    }
    
    $drilldown[$h] = array(
        'color' => '#4572A7',
        'xAxis' => 1,
        'data' => $drilldata,
        'prod_month' => $prod_month[$h],
        'month' => $m
    );
    $prod_day2     = array(); // empty
    $drilldata     = array();
    if ($compare == 'expected') {
        $h++;
    }
    $m++;
    $i++;
}

for ($h = 0; $h < $upto; $h++) {
    $datareturn[$h] = array(
        'x' => $fstd[$h],
        'y' => $prod_month[$h],
        'color' => '#4572A7',
        'drilldown' => $drilldown[$h]
    );
    if ($compare == 'expected') {
        $h++;
        $datareturn[$h] = array(
            'x' => $fstd2[$h - 1],
            'y' => $prod_month[$h],
            'color' => '#89A54E'
        );
    }
}

$jsonreturn = array(
    'data' => $datareturn,
    'prod_y' => $prod_year
);
header("Content-type: text/json");
echo json_encode($jsonreturn);
?>
