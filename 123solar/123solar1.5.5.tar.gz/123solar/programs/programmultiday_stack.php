<?php
// Credit Louviaux Jean-Marc 2013
include('../scripts/read_maincfg.php');
date_default_timezone_set('GMT');

if (isset($_COOKIE['user_lang'])) {
    $user_lang = $_COOKIE['user_lang'];
} else {
    $user_lang = 'English';
}

include('../languages/' . $user_lang . '.php');

$i          = 0;
$latestfile = 0;
for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) { // Check files dates
    $dir    = '../data/invt' . $invt_num . '/csv/';
    $output = glob($dir . '*.csv');
    sort($output);
    $cnt             = count($output);
    $option = $output[$cnt - 1];
    $option = str_replace($dir, '', $option);
    $year            = substr($option, 0, 4);
    $month           = substr($option, 4, 2);
    $day             = substr($option, 6, 2);
    $fileUTCdate[$i] = strtotime($year . '-' . $month . '-' . $day);
    if ($fileUTCdate[$i] > $latestfile) {
        $latestfile     = $fileUTCdate[$i];
        $latestfilename = $option;
    }
    $i++;
}

$year  = date('Y', $latestfile);
$month = date('m', $latestfile);
$day   = date('d', $latestfile);

$todayUTC = strtotime(date('Ymd'));

$i          = 0;
$lastsample = 0;
for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) { // multi
    $dir      = '../data/invt' . $invt_num . '/csv/';
    $filename = $dir . $latestfilename;
    if (file_exists($filename)) { // skip older files
        $invtnum = $invt_num;
        include('../scripts/read_invtcfg.php');
        $file       = file($filename);
        $contalines = count($file);
        
        for ($line_num = 1; $line_num < $contalines; $line_num++) {
            $array = preg_split('/,/', $file[$line_num]);
            
            $SDTE[$line_num] = $array[0];
            $KWHT[$line_num] = $array[14];
            
            if ($line_num == 1) {
                $pastline_num = 1;
            } else {
                $pastline_num = $line_num - 1;
            }
            
            $hour        = substr($SDTE[$line_num], 0, 2);
            $minute      = substr($SDTE[$line_num], 3, 2);
            $seconde     = substr($SDTE[$line_num], 6, 2);
            $pasthour    = substr($SDTE[$pastline_num], 0, 2);
            $pastminute  = substr($SDTE[$pastline_num], 3, 2);
            $pastseconde = substr($SDTE[$pastline_num], 6, 2);
            
            $UTCdate = strtotime($year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute . ':' . $seconde);
            
            $diffUTCdate = strtotime($year . '-' . $month . '-' . $day . ' ' . $pasthour . ':' . $pastminute . ':' . $pastseconde);
            $diffTime    = $UTCdate - $diffUTCdate;
            
            if ($diffTime != 0) {
                $AvgPOW[$invt_num] = round((((($KWHT[$line_num] - $KWHT[$pastline_num]) * 3600) / $diffTime) * 1000), 1);
            } else {
                $AvgPOW[$invt_num] = 0;
            }
            
            $UTCdate *= 1000;
            $stack[$invt_num][$line_num] = array(
                $UTCdate,
                $AvgPOW[$invt_num]
            );
            
            if (!isset($totstack[$hour . $minute][1])) {
                $totstack[$hour . $minute][1] = 0;
            }
            $totAvgPOW                 = $AvgPOW[$invt_num] + $totstack[$hour . $minute][1];
            $totstack[$hour . $minute] = array(
                $UTCdate,
                $totAvgPOW
            ); // minute precision
            if (!isset($MaxPow)) {
                $MaxPow = 0;
            }
            if ($totAvgPOW >= $MaxPow) { // Scatter max
                $MaxPow    = $totAvgPOW;
                $stack2[0] = array(
                    $UTCdate,
                    $MaxPow
                );
            }
        }
        $contalines--;
        $KWHD[$invt_num] = round((($KWHT[$contalines] - $KWHT[1]) * $CORRECTFACTOR), 1);
    } // skip older file
    $lastsampledate[$invt_num] = strtotime($year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute);
    if ($lastsampledate[$invt_num] > $lastsample) {
        $lastsample = $lastsampledate[$invt_num];
    }
    $i++;
    if (isset($stack[$invt_num])) {
        sort($stack[$invt_num]);
    }
} // multi

$j         = 0;
$totAvgPOW = 0;
$KWHDTOT   = 0;

for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) {
    if ($fileUTCdate[$j] == $latestfile) {
        $KWHDTOT += $KWHD[$invt_num];
    }
    if (!isset($AvgPOW[$invt_num])) {
        $AvgPOW[$invt_num] = 0;
    }
    if ($lastsample == $lastsampledate[$invt_num]) {
        $totAvgPOW += $AvgPOW[$invt_num]; //last sample
    }
    $j++;
}

$LastTime = $lastsample * 1000;

$stack2[1] = array(
    $LastTime,
    $totAvgPOW
); // Scatter latest value

$KWHDt = array_sum($KWHD);
$KWHDt = number_format($KWHDt, 1, $DPOINT, $THSEP);

if ($latestfile == $todayUTC) {
    $title = stripslashes("$lgTODAYTITLE ($KWHDt kWh)");
} elseif ($latestfile == strtotime(date('Ymd', strtotime("-1 day")))) {
    $title = stripslashes("$lgYESTERDAYTITLE ($KWHDt kWh)");
} else {
    $dday  = date($DATEFORMAT, $latestfile);
    $title = stripslashes("$dday ($KWHDt kWh)");
}

include('../scripts/read_maincfg.php');
date_default_timezone_set($DTZ);
$sun_info = date_sun_info(strtotime("$year-$month-$day"), $LATITUDE, $LONGITUDE);
$subtitle = "$lgSUNRISE " . date('H:i', $sun_info['sunrise']) . " - $lgTRANSIT " . date('H:i', $sun_info['transit']) . " - $lgSUNSET " . date('H:i', $sun_info['sunset']);

$j = 0;
for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) {
    if ($fileUTCdate[$j] == $latestfile) { // skip older files
        $data[$j] = array(
            'name' => "$lgINVT$invt_num",
            'data' => $stack[$invt_num],
            'type' => 'areaspline'
        );
    } else {
        $data[$j] = array(
            'name' => "$lgINVT$invt_num",
            'data' => array(
                array(
                    $LastTime,
                    0
                )
            ),
            'type' => 'areaspline'
        );
    }
    $j++;
}

$data[$j] = array(
    'name' => "Max",
    'data' => $stack2,
    'type' => 'scatter'
);

$jsonreturn = array(
    'data' => $data,
    'title' => $title,
    'subtitle' => $subtitle
);
header("Content-type: text/json");
echo json_encode($jsonreturn);
?>