<?php
// Credit Louviaux Jean-Marc 2013
include('../scripts/read_maincfg.php');
date_default_timezone_set($DTZ);
if (!empty($_GET['invtnum']) && is_numeric($_GET['invtnum'])) {
$invtnum = $_GET['invtnum'];
}
include('../scripts/read_invtcfg.php');
$array  = array();
$nowUTC = strtotime(date('Ymd H:i:s'));

$systemid = '1231' . $invtnum;
@$shmid = shmop_open($systemid, 'a', 0444, 256);
if (!empty($shmid)) {
    $data = shmop_read($shmid, 0, 256);
    shmop_close($shmid);
} else {
    $data = "$nowUTC,0,0,0,0,0,0,0,0,0,0,0,0,0,0";
}
$array = preg_split('/,/', $data);
$year    = substr($array[0], 0, 4);
$month   = substr($array[0], 4, 2);
$day     = substr($array[0], 6, 2);
$hour    = substr($array[0], 9, 2);
$minute  = substr($array[0], 12, 2);
$seconde = substr($array[0], 15, 2);
$UTCdate = strtotime($year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute . ':' . $seconde);
$dday    = date($DATEFORMAT . ' H:i:s', mktime($hour, $minute, $seconde, $month, $day, $year));

for ($i = 1; $i < 15; $i++) {
    if (!isset($array[$i])) {
        $array[$i] = 0;
    }
}

$array[9] *= $CORRECTFACTOR;
if ($array[9] > 1000) { // Round power > 1000W
    $array[9] = round($array[9], 0);
} else {
    $array[9] = round($array[9], 1);
}
if ($array[3] > 1000) {
    $array[3] = round($array[3], 0);
} else {
    $array[3] = round($array[3], 1);
}
if ($array[6] > 1000) {
    $array[6] = round($array[6], 0);
} else {
    $array[6] = round($array[6], 1);
}

$systemid = '1234' . $invtnum; //Awpeak msg
@$shmid = shmop_open($systemid, 'a', 0444, 64);
if (!empty($shmid)) {
    $data     = shmop_read($shmid, 0, 64);
    $parray   = preg_split("/,/", $data);
    $awdate_t = date('H:i', $parray[0]);
} else {
    $parray= array($nowUTC,0,0);
    $awdate_t = '--:--';
}

$systemid = '1232' . $invtnum; //pmotd
@$shmid = shmop_open($systemid, 'a', 0444, 32);
if (!empty($shmid)) {
    $data = shmop_read($shmid, 0, 32);
} else {
    $data = "$nowUTC,0";
}
$pmotdarray = preg_split('/,/', $data);
$pmotd_t    = date('H:i', $pmotdarray[0]);

$arr = array(
    'SDTE' => $UTCdate * 1000,
    'I1V' => floatval(round($array[1], 1)),
    'I1A' => floatval(round($array[2], 1)),
    'I1P' => floatval($array[3]),
    'I2V' => floatval(round($array[4], 1)),
    'I2A' => floatval(round($array[5], 1)),
    'I2P' => floatval($array[6]),
    'GV' => floatval(round($array[7], 1)),
    'GA' => floatval(round($array[8], 1)),
    'GP' => floatval($array[9]),
    'FRQ' => floatval(round($array[10], 1)),
    'EFF' => floatval(round($array[11], 1)),
    'INVT' => floatval(round($array[12], 1)),
    'BOOT' => floatval(round($array[13], 1)),
    'KWHT' => floatval($array[14]),
    'PMAXOTD' => floatval(round($pmotdarray[1], 0)),
    'PMAXOTDTIME' => ($pmotd_t),
    'timestamp' => $dday,
    'riso' => floatval(round($parray[2], 2)),
    'ileak' => floatval(round($parray[1], 1)),
    'awdate' => $awdate_t
);

if ($nowUTC - $UTCdate > 30) { // Too old data
    $awdate_t = '--:--';
    $arr      = array(
        'SDTE' => $nowUTC * 1000,
        'I1V' => floatval(0),
        'I1A' => floatval(0),
        'I1P' => floatval(0),
        'I2V' => floatval(0),
        'I2A' => floatval(0),
        'I2P' => floatval(0),
        'GV' => floatval(0),
        'GA' => floatval(0),
        'GP' => floatval(0),
        'FRQ' => floatval(0),
        'EFF' => floatval(0),
        'INVT' => floatval(0),
        'BOOT' => floatval(0),
        'PMAXOTD' => floatval(round($pmotdarray[1], 0)),
        'PMAXOTDTIME' => ($pmotd_t),
        'timestamp' => $dday,
        'riso' => floatval(round($parray[2], 2)),
        'ileak' => floatval(round($parray[1], 1)),
        'awdate' => $awdate_t
    );
}

$ret = array(
    $arr
);
header("Content-type: text/json");  
echo json_encode($ret);
?>
