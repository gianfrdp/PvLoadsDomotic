<?php
// Credit Louviaux Jean-Marc 2013
include('../scripts/read_maincfg.php');
date_default_timezone_set('GMT');
if (!empty($_GET['invtnum']) && is_numeric($_GET['invtnum'])) {
$invtnum = $_GET['invtnum'];
}
include('../scripts/read_invtcfg.php');

if (isset($_COOKIE['user_lang'])) {
    $user_lang = $_COOKIE['user_lang'];
} else {
    $user_lang = 'English';
}

include('../languages/' . $user_lang . '.php');

$dir    = '../data/invt' . $invtnum . '/csv/';
$output = glob($dir . '*.csv');
sort($output);
$cnt = count($output);
$option = $output[$cnt - 1];
$option = str_replace($dir, '', $option);
$file       = file($dir . '/' . $option);
$contalines = count($file);

$year  = substr($option, 0, 4);
$month = substr($option, 4, 2);
$day   = substr($option, 6, 2);

$fileUTCdate = strtotime(date("$year$month$day"));
$todayUTC    = strtotime(date('Ymd'));

for ($line_num = 1; $line_num < $contalines; $line_num++) {
    $array = preg_split('/,/', $file[$line_num]);
    
    $SDTE[$line_num] = $array[0];
    $KWHT[$line_num] = $array[14];
    
    if ($line_num == 1) {
        $pastline_num = 1;
    } else {
        $pastline_num = $line_num - 1;
    }
    
    $hour    = substr($SDTE[$line_num], 0, 2);
    $minute  = substr($SDTE[$line_num], 3, 2);
    $seconde = substr($SDTE[$line_num], 6, 2);
    
    $pasthour    = substr($SDTE[$pastline_num], 0, 2);
    $pastminute  = substr($SDTE[$pastline_num], 3, 2);
    $pastseconde = substr($SDTE[$pastline_num], 6, 2);
    
    $UTCdate = strtotime($year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute . ':' . $seconde);
    
    $diffUTCdate = strtotime($year . '-' . $month . '-' . $day . ' ' . $pasthour . ':' . $pastminute . ':' . $pastseconde);
    $diffTime    = $UTCdate - $diffUTCdate;
    
    if ($diffTime != 0) {
        $AvgPOW = round((((($KWHT[$line_num] - $KWHT[$pastline_num]) * 3600) / $diffTime) * 1000), 1);
    } else {
        $AvgPOW = 0;
    }
    
    $UTCdate = $UTCdate * 1000;
    if (!isset($MaxPow)) {
        $MaxPow = 0;
    }
    if ($AvgPOW >= $MaxPow && $line_num < $contalines) { // Past maximum
        $MaxPow  = $AvgPOW;
        $MaxTime = $UTCdate;
    }
}

$LatestPow  = $AvgPOW; // Latest value
$LatestTime = $UTCdate;

// Updating title
$array  = preg_split('/,/', $file[1]);
$array2 = preg_split('/,/', $file[$contalines - 1]);
$KWHD   = round((($array2[14] - $array[14]) * $CORRECTFACTOR), 1);
$KWHD   = number_format($KWHD, 1, $DPOINT, $THSEP);

if ($fileUTCdate == $todayUTC) {
    $PTITLE = stripslashes("$lgTODAYTITLE ($KWHD kWh)");
} elseif ($fileUTCdate == strtotime(date("Ymd", strtotime("-1 day")))) {
    $PTITLE = stripslashes("$lgYESTERDAYTITLE ($KWHD kWh)");
} else {
    $dday   = date($DATEFORMAT, $fileUTCdate);
    $PTITLE = stripslashes("$dday ($KWHD kWh)");
}

$data = array(
    0 => array( // Add the last point
        'LastTime' => $UTCdate,
        'LastValue' => $AvgPOW
    ),
    1 => array(
        'MaxTime' => $MaxTime,
        'MaxPow' => $MaxPow
    ),
    2 => array(
        'PTITLE' => $PTITLE
    )
);

header("Content-type: text/json");
echo json_encode($data);
?>
