<?php
// Credit Louviaux Jean-Marc 2013
if (!empty($_GET['invtnum']) && is_numeric($_GET['invtnum'])) {
$invtnum = $_GET['invtnum'];
}

$systemid = '1236' . $invtnum; // state
@$shmid = shmop_open($systemid, 'a', 0444, 256);
if (!empty($shmid)) {
    $state = shmop_read($shmid, 0, 256);
    shmop_close($shmid);
} else {
    $state = '';
}

$state = str_replace('\0', '',  $state); //null
$order   = array('\r\n', '\n', '\r');
$state = str_replace($order, "<br>", $state);

$systemid = '1234' . $invtnum; // peak
@$shmid = shmop_open($systemid, 'a', 0444, 64);
if (!empty($shmid)) {
    $data     = shmop_read($shmid, 0, 64);
    $data = str_replace('\0', '',  $data); //null
    $array   = preg_split('/,/', $data);
} else {
    $array= array(0,0,0,0,0);
}

$ret = array($state,$array[3],$array[4] );

header("Content-type: text/json");  
echo json_encode($ret);
?>
