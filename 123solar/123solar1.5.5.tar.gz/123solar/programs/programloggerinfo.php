<?php 
// Credit Louviaux Jean-Marc 2012
include('../scripts/read_maincfg.php'); 
include('../scripts/distros/'.$DISTRO.'.php'); 

$uptime=shell_exec($UPTIME);
$cpuuse=shell_exec($CPUUSE);
$memtot=shell_exec($MEMTOT);
$memuse=shell_exec($MEMUSE);
$memfree=shell_exec($MEMFREE);
$diskuse=shell_exec($DISKUSE); 
$diskfree=shell_exec($DISKFREE);

$arr= array(
'uptime' => trim($uptime),
'cpuuse' => trim($cpuuse),
'memtot' => trim($memtot),
'memuse' => trim($memuse),
'memfree' => trim($memfree),
'diskuse' => trim($diskuse),
'diskfree' => trim($diskfree)
);  
  
$ret= array($arr);

header("Content-type: text/json");  
echo json_encode($ret); 
?>
