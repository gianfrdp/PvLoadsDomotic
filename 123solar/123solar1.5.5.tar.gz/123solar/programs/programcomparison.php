<?php
// Credit Louviaux Jean-Marc 2013
include('../scripts/read_maincfg.php');
date_default_timezone_set('GMT');

if (!empty($_GET['invtnum_f']) && is_numeric($_GET['invtnum_f'])) {
$invtnum_f = $_GET['invtnum_f'];
}
if (isset($_COOKIE['user_lang'])) {
    $user_lang = $_COOKIE['user_lang'];
} else {
    $user_lang = 'English';
}

include('../languages/' . $user_lang . '.php');

if (!empty($_GET['whichmonth']) && is_numeric($_GET['whichmonth'])) {
    $whichmonth = $_GET['whichmonth'];
} else {
    $whichmonth = date('n');
}
if (!empty($_GET['whichyear']) && is_numeric($_GET['whichyear'])) {
    $whichyear = $_GET['whichyear'];
} else {
    $whichyear = date('Y');
}
if (!empty($_GET['comparemonth']) && is_numeric($_GET['comparemonth'])) {
    $comparemonth = $_GET['comparemonth'];
} else {
    $comparemonth = date('n');
}
if (!empty($_GET['compareyear']) && is_string($_GET['compareyear'])) {
    $compareyear = $_GET['compareyear'];
    $compareyear = htmlspecialchars($compareyear, ENT_QUOTES, "UTF-8");
} else {
    $compareyear = 'expected';
}

function getvalues($selectmonth, $selectyear, $invtnum)
{
    include('../scripts/read_maincfg.php');
    date_default_timezone_set('GMT');
    
    if ($invtnum == 0) { //all
        $startinv = 1;
        $uptoinv  = $NUMINV;
    } else {
        $startinv = $invtnum;
        $uptoinv  = $invtnum;
    }

    for ($invt_num = $startinv; $invt_num <= $uptoinv; $invt_num++) { // Multi
        $invtnum = $invt_num;
        include('../scripts/read_invtcfg.php');
        
        $dir = '../data/invt' . $invt_num . '/production/';
        if (file_exists($dir . 'energy' . $selectyear . '.csv')) {
            $thefile    = file($dir . 'energy' . $selectyear . '.csv');
            $contalines = count($thefile);
            
            $i = 0;
            for ($line_num = 0; $line_num < $contalines; $line_num++) {
                $array = preg_split('/,/', $thefile[$line_num]);
                
                $year  = $selectyear;
                $month = substr($array[0], 4, 2);
                $day   = substr($array[0], 6, 2);
                if ($month == $selectmonth || $selectmonth == 13) {
                    $date1 = strtotime($year . '-' . $month . '-' . $day);
                    $date1 *= 1000; // in ms
                    $month                             = (int) ($month);
                    $day                               = (int) ($day);
                    $prod_day[$invt_num][$month][$day] = round(($array[1] * $CORRECTFACTOR), 1);
                }
            } // end of looping through the file
        }
        if ($selectyear == date('Y') && ($selectmonth == date('n') || $selectmonth == 13)) { // Add today prod
            $dir     = '../data/invt' . $invt_num . '/csv/';
	    $output2 = glob($dir . '*.csv');
            sort($output2);
            $cnt   = count($output2);
	    $option = $output2[$cnt - 1];
            $option = str_replace($dir, '', $option);
            $lines = file($dir . '/' . $option);
            
            $contalines                        = count($lines);
            $array                             = preg_split('/,/', $lines[1]);
            $array2                            = preg_split('/,/', $lines[$contalines - 1]);
            $year                              = substr($option, 0, 4);
            $month                             = substr($option, 4, 2);
            $day                               = substr($option, 6, 2);
            $month                             = (int) ($month);
            $day                               = (int) ($day);
            $prod_day[$invt_num][$month][$day] = round((($array2[14] - $array[14]) * $CORRECTFACTOR), 1);
        } // end of today prod
    } // end of multi
    
    $i         = 0;
    $cumu_prod = 0; // Cumulative
    if ($selectmonth == 13) { // all year
        $selectmonth_start = 1;
        $selectmonth_stop  = 12;
    } else {
        $selectmonth_start = $selectmonth;
        $selectmonth_stop  = $selectmonth;
    }
    
    for ($k = $selectmonth_start; $k <= $selectmonth_stop; $k++) {
        $daythatm = cal_days_in_month(CAL_GREGORIAN, $k, $selectyear);
        for ($j = 1; $j <= $daythatm; $j++) {
            $date1 = strtotime($selectyear . '-' . $k . '-' . $j);
            $date1 *= 1000;
            for ($invt_num = $startinv; $invt_num <= $uptoinv; $invt_num++) { // Multi
                if (!isset($prod_day[$invt_num][$k][$j])) {
                    $prod_day[$invt_num][$k][$j] = 0; // Filling blanks dates
                }
                $cumu_prod += $prod_day[$invt_num][$k][$j];
            } // end of multi  
            $stack[$i] = array(
                $date1,
                $cumu_prod
            );
            $i++;
        }
    } // k selected month
    
    return $stack;
} // enf of fnct getvalues  

$datareturn = getvalues($whichmonth, $whichyear, $invtnum_f); // Call fnct

if ($compareyear == $whichyear && $comparemonth == $whichmonth) { //Same req
    $datareturn2 = $datareturn;
    $xaxe        = 0;
} else {
    if ($compareyear != 'expected') { // Compare with
        $datareturn2 = getvalues($comparemonth, $compareyear, $invtnum_f);
        $xaxe        = 1;
    } else { // Expected
        
        include('../scripts/read_maincfg.php');
        if ($invtnum_f == 0) { //all
            $startinv = 1;
            $uptoinv  = $NUMINV;
        } else {
            $startinv = $invtnum_f;
            $uptoinv  = $invtnum_f;
        }
        $compareyear = $lgPRODTOOLTIPEXPECTED; //name
        $prod_exp    = array();
        for ($i = 1; $i <= 12; $i++) {
            $prod_exp[$i] = 0;
        }
        for ($invt_num = $startinv; $invt_num <= $uptoinv; $invt_num++) { // Multi
            $invtnum = $invt_num;
            include('../scripts/read_invtcfg.php');
            $EXPECTEDPROD = $EXPECTEDPROD / 100;
            $prod_exp[1] += ($EXPECTJAN * $EXPECTEDPROD);
            $prod_exp[2] += ($EXPECTFEB * $EXPECTEDPROD);
            $prod_exp[3] += ($EXPECTMAR * $EXPECTEDPROD);
            $prod_exp[4] += ($EXPECTAPR * $EXPECTEDPROD);
            $prod_exp[5] += ($EXPECTMAY * $EXPECTEDPROD);
            $prod_exp[6] += ($EXPECTJUN * $EXPECTEDPROD);
            $prod_exp[7] += ($EXPECTJUI * $EXPECTEDPROD);
            $prod_exp[8] += ($EXPECTAUG * $EXPECTEDPROD);
            $prod_exp[9] += ($EXPECTSEP * $EXPECTEDPROD);
            $prod_exp[10] += ($EXPECTOCT * $EXPECTEDPROD);
            $prod_exp[11] += ($EXPECTNOV * $EXPECTEDPROD);
            $prod_exp[12] += ($EXPECTDEC * $EXPECTEDPROD);
        } // end of multi
        
        if ($comparemonth == 13) { // all year
            $selectmonth_start = 1;
            $selectmonth_stop  = 12;
            $startdate         = strtotime($whichyear . '-01-01');
        } else {
            $selectmonth_start = $comparemonth;
            $selectmonth_stop  = $comparemonth;
            $startdate         = strtotime($whichyear . '-' . $comparemonth . '-01');
        }
        $startdate *= 1000;
        $cumu_prod2 = 0;
        $i          = 0;
        //settype($cumu_prod2, "integer");
        for ($k = $selectmonth_start; $k <= $selectmonth_stop; $k++) {
            $daythatm     = cal_days_in_month(CAL_GREGORIAN, $k, $whichyear);
            $prodinexpday = round(($prod_exp[$k] / $daythatm), 1);
            for ($j = 0; $j < $daythatm; $j++) {
                $cumu_prod2 += $prodinexpday;
                $datareturn2[$i] = array(
                    $startdate,
                    $cumu_prod2
                );
                $startdate += 86400000; //next day
                $i++;
            }
        } // k selected month 
        
        if ($comparemonth == $whichmonth) {
            $xaxe = 0;
        } else {
            $xaxe = 1;
        }
    }
    
} // end of same req

$data = array(
    0 => array(
        'name' => "$lgSMONTH[$whichmonth] $whichyear",
        'type' => 'areaspline',
        'data' => $datareturn,
        'xAxis' => 0
    ),
    1 => array(
        'name' => "$lgSMONTH[$comparemonth] $compareyear",
        'type' => 'spline',
        'data' => $datareturn2,
        'xAxis' => $xaxe
    )
);

header("Content-type: text/json");
echo json_encode($data);
?>
