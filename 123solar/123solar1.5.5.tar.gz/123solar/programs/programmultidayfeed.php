<?php
// Credit Louviaux Jean-Marc 2013
include("../scripts/read_maincfg.php");
date_default_timezone_set('GMT');

if (isset($_COOKIE['user_lang'])) {
    $user_lang = $_COOKIE['user_lang'];
} else {
    $user_lang = "English";
}
;
include("../languages/" . $user_lang . ".php");

function tricsv($var)
{
    return !is_dir($var) && preg_match('/\.csv$/i', $var);
}

$i          = 0;
$latestfile = 0;
for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) { // Check files dates
    $dir    = '../data/invt' . $invt_num . '/csv';
    $output = scandir($dir);
    $output = array_filter($output, "tricsv");
    sort($output);
    $cnt             = count($output);
    $year            = substr($output[$cnt - 1], 0, 4);
    $month           = substr($output[$cnt - 1], 4, 2);
    $day             = substr($output[$cnt - 1], 6, 2);
    $fileUTCdate[$i] = strtotime($year . "-" . $month . "-" . $day);
    if ($fileUTCdate[$i] > $latestfile) {
        $latestfile = $fileUTCdate[$i];
    }
    $i++;
}

$year  = date('Y', $latestfile);
$month = date('m', $latestfile);
$day   = date('d', $latestfile);

$todayUTC = strtotime(date("Ymd"));

$i         = 0;
$MaxPow    = 0;
$MaxTime   = 0;
$LastTime  = 0;
$activeint = $NUMINV;
for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) { // multi
    $invtnum = $invt_num;
    include("../scripts/read_invtcfg.php");
    if ($SKIPMONITORING == true) {
        $activeint--;
    }
}

for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) { // multi
    $dir = '../data/invt' . $invt_num . '/csv';
    if ($fileUTCdate[$i] == $latestfile) { // skip older day files
        $output = scandir($dir);
        $output = array_filter($output, "tricsv");
        sort($output);
        $cnt = count($output);
        
        $invtnum = $invt_num;
        include("../scripts/read_invtcfg.php");
        
        $file       = file($dir . "/" . $output[$cnt - 1]);
        $contalines = count($file);
        
        for ($line_num = 1; $line_num < $contalines; $line_num++) {
            $array = preg_split("/,/", $file[$line_num]);
            
            $SDTE[$line_num] = $array[0];
            $KWHT[$line_num] = $array[14];
            
            if ($line_num == 1) {
                $pastline_num = 1;
            } else {
                $pastline_num = $line_num - 1;
            }
            
            $hour        = substr($SDTE[$line_num], 0, 2);
            $minute      = substr($SDTE[$line_num], 3, 2);
            $seconde     = substr($SDTE[$line_num], 6, 2);
            $pasthour    = substr($SDTE[$pastline_num], 0, 2);
            $pastminute  = substr($SDTE[$pastline_num], 3, 2);
            $pastseconde = substr($SDTE[$pastline_num], 6, 2);
            
            $UTC = strtotime($year . "-" . $month . "-" . $day . " " . $hour . ":" . $minute . ":" . $seconde);
            
            $diffUTCdate       = strtotime($year . "-" . $month . "-" . $day . " " . $pasthour . ":" . $pastminute . ":" . $pastseconde);
            $diffTime          = $UTC - $diffUTCdate;
            $UTCdate[$invtnum] = $UTC * 1000;
            
            if ($diffTime != 0) {
                $AvgPOW[$invtnum] = round((((($KWHT[$line_num] - $KWHT[$pastline_num]) * 3600) / $diffTime) * 1000), 1);
                if (!isset($CumPOW[$hour . $minute])) {
                    $CumPOW[$hour . $minute] = 0;
                }
                $CumPOW[$hour . $minute] += $AvgPOW[$invtnum];
                $sampledate[$hour . $minute][$invtnum] = strtotime($year . "-" . $month . "-" . $day . " " . $hour . ":" . $minute);
                if ($CumPOW[$hour . $minute] >= $MaxPow) { // Past maximum
                    $MaxPow  = $CumPOW[$hour . $minute];
                    $MaxTime = $sampledate[$hour . $minute][$invtnum] * 1000;
                }
                $cnt = count($sampledate[$hour . $minute]);
                if ($sampledate[$hour . $minute][$invtnum] > $LastTime && $cnt == $activeint) {
                    $LastTime  = $sampledate[$hour . $minute][$invtnum]; // Last sample in common
                    $LastValue = $CumPOW[$hour . $minute];
                }
            } else {
                $AvgPOW[$invtnum] = 0;
            }
        }
        $UTCdate[$invtnum] = $sampledate[$hour . $minute][$invtnum] * 1000;
        $contalines--;
        $KWHD[$invtnum] = round((($KWHT[$contalines] - $KWHT[1]) * $CORRECTFACTOR), 1);
    } // skip older file
    $i++;
} // multi

$j       = 0;
$KWHDTOT = 0;

for ($invtnum = 1; $invtnum <= $NUMINV; $invtnum++) {
    if (!isset($fileUTCdate[$invtnum])) {
        $fileUTCdate[$invtnum] = 0;
    }
    if ($fileUTCdate[$j] == $latestfile) {
        $KWHDTOT += $KWHD[$invtnum];
    }
    $j++;
}

$KWHDTOT = round($KWHDTOT, 1);
$KWHDTOT = number_format($KWHDTOT, 1, $DPOINT, $THSEP);

$LastTime *= 1000;
if ($MaxTime == 0) {
    $MaxTime = $LastTime;
}

if ($latestfile == $todayUTC) {
    $PTITLE = stripslashes("$lgTODAYTITLE ($KWHDTOT kWh)");
} elseif ($latestfile == strtotime(date("Ymd", strtotime("-1 day")))) {
    $PTITLE = stripslashes("$lgYESTERDAYTITLE ($KWHDTOT kWh)");
} else {
    $dday   = date($DATEFORMAT, $latestfile);
    $PTITLE = stripslashes("$dday ($KWHDTOT kWh)");
}

$data[0] = array(
    'totTime' => $LastTime,
    'totValue' => $LastValue
);

$j = 0;
for ($invtnum = 1; $invtnum <= $NUMINV; $invtnum++) { // Multi
    if ($fileUTCdate[$j] == $latestfile) {
        $data[$invtnum] = array(
            'x' => $UTCdate[$invtnum],
            'y' => $AvgPOW[$invtnum]
        );
    } else {
        $data[$invtnum] = array(
            'x' => $LastTime,
            'y' => 0
        );
    }
    $j++;
} // multi
$j++;
$data[$j] = array(
    'MaxTime' => $MaxTime,
    'MaxPow' => $MaxPow
);
$j++;
$data[$j] = array(
    'LastTime' => $LastTime,
    'LastValue' => $LastValue
);
$j++;
$data[$j] = array(
    'PTITLE' => $PTITLE
);
header("Content-type: text/json");
echo json_encode($data);
?>
