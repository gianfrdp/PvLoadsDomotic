<?php
// Credit Louviaux Jean-Marc 2013
include('../scripts/read_maincfg.php');
date_default_timezone_set('GMT');
if (!empty($_GET['invtnum']) && is_numeric($_GET['invtnum'])) {
$invtnum = $_GET['invtnum'];
}
include('../scripts/read_invtcfg.php');

if (isset($_COOKIE['user_lang'])) {
    $user_lang = $_COOKIE['user_lang'];
} else {
    $user_lang = 'English';
}
;
include('../languages/' . $user_lang . '.php');

$nbryaxis = 0;

if (!empty($_GET['date1']) && is_string($_GET['date1'])) {
    $date1 = $_GET['date1'];
    $date1 = htmlspecialchars($date1, ENT_QUOTES, 'UTF-8');
} else {
    $date1 = FALSE;
}

$checkpower    = htmlspecialchars($_GET['checkpower'], ENT_QUOTES, 'UTF-8');
$checkPROD     = htmlspecialchars($_GET['checkPROD'], ENT_QUOTES, 'UTF-8');
$checkPEFF     = htmlspecialchars($_GET['checkPEFF'], ENT_QUOTES, 'UTF-8');
$checkavgpower = htmlspecialchars($_GET['checkavgpower'], ENT_QUOTES, 'UTF-8');
$checkI1V      = htmlspecialchars($_GET['checkI1V'], ENT_QUOTES, 'UTF-8');
$checkI1A      = htmlspecialchars($_GET['checkI1A'], ENT_QUOTES, 'UTF-8');
$checkI1P      = htmlspecialchars($_GET['checkI1P'], ENT_QUOTES, 'UTF-8');
$checkPEFF1    = htmlspecialchars($_GET['checkPEFF1'], ENT_QUOTES, 'UTF-8');
$checkI2V      = htmlspecialchars($_GET['checkI2V'], ENT_QUOTES, 'UTF-8');
$checkI2A      = htmlspecialchars($_GET['checkI2A'], ENT_QUOTES, 'UTF-8');
$checkI2P      = htmlspecialchars($_GET['checkI2P'], ENT_QUOTES, 'UTF-8');
$checkPEFF2    = htmlspecialchars($_GET['checkPEFF2'], ENT_QUOTES, 'UTF-8');
$checkGV       = htmlspecialchars($_GET['checkGV'], ENT_QUOTES, 'UTF-8');
$checkGA       = htmlspecialchars($_GET['checkGA'], ENT_QUOTES, 'UTF-8');
$checkGP       = htmlspecialchars($_GET['checkGP'], ENT_QUOTES, 'UTF-8');
$checkFRQ      = htmlspecialchars($_GET['checkFRQ'], ENT_QUOTES, 'UTF-8');
$checkEFF      = htmlspecialchars($_GET['checkEFF'], ENT_QUOTES, 'UTF-8');
$checkINVT     = htmlspecialchars($_GET['checkINVT'], ENT_QUOTES, 'UTF-8');
$checkBOOT     = htmlspecialchars($_GET['checkBOOT'], ENT_QUOTES, 'UTF-8');

$dir = '../data/invt' . $invtnum . '/csv/';
$log = $dir . $date1;

if (file_exists($log)) {
    $file       = file($log);
    $contalines = count($file);
    
    $year  = substr($date1, 0, 4);
    $month = substr($date1, 4, 2);
    $day   = substr($date1, 6, 2);
    
    for ($line_num = 1; $line_num < $contalines; $line_num++) {
        $array = preg_split('/,/', $file[$line_num]);
        
        $SDTE[$line_num] = $array[0];
        $I1V             = $array[1];
        $I1A             = $array[2];
        $I1P             = $array[3];
        $I2V             = $array[4];
        $I2A             = $array[5];
        $I2P             = $array[6];
        $GV              = $array[7];
        $GA              = $array[8];
        $GP              = $array[9];
        $FRQ             = $array[10];
        $EFF             = $array[11];
        $INVT            = $array[12];
        $BOOT            = $array[13];
        $KWHT[$line_num] = $array[14];
        
        $hour    = substr($SDTE[$line_num], 0, 2);
        $minute  = substr($SDTE[$line_num], 3, 2);
        $seconde = substr($SDTE[$line_num], 6, 2);
        
        $epochdate = strtotime($year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute . ':' . $seconde);
        $UTCdate   = $epochdate * 1000;
        
        $countstack = 0; // Count the numbers of Yaxis
        
        if ($checkpower == 'on') {
            $POW                           = round(((($I1P + $I2P) * $EFF) / 100), 1);
            $stackname[$countstack]        = $lgDPOWERINSTANT;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                $POW
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkavgpower == 'on') {
            if ($line_num > 2) {
                $pastline_num = $line_num - 1;
                $pasthour     = substr($SDTE[$pastline_num], 0, 2);
                $pastminute   = substr($SDTE[$pastline_num], 3, 2);
                $pastseconde  = substr($SDTE[$pastline_num], 6, 2);
                //calculate average Power between 2 pooling
                $diffUTCdate  = strtotime($year . '-' . $month . '-' . $day . ' ' . $pasthour . ':' . $pastminute . ':' . $pastseconde);
                $diffTime     = $epochdate - $diffUTCdate;
                $AvgPOW       = round((((($KWHT[$line_num] - $KWHT[$pastline_num]) * 3600) / $diffTime) * 1000), 1);
            } else {
                $AvgPOW = 0;
            }
            $stackname[$countstack]        = $lgDPOWERAVG;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                $AvgPOW
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkI1P == 'on') {
            $stackname[$countstack]        = $lgDPOWER1;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($I1P, 2)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkI2P == 'on') {
            $stackname[$countstack]        = $lgDPOWER2;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($I2P, 2)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkGP == 'on') {
            $stackname[$countstack]        = 'Grid Power';
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($GP, 2)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        
        if ($checkpower == 'on' || $checkavgpower == 'on' || $checkI1P == 'on' || $checkI2P == 'on' || $checkGP == 'on') {
            $nbryaxis++;
        }
        
        if ($checkPROD == 'on') {
            if ($line_num > 2) {
                $PROD = round(($KWHT[$line_num] - $KWHT[1]), 1);
            } else {
                $PROD = 0;
            }
            $stackname[$countstack]        = $lgPROD;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                $PROD
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'areaspline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
            $nbryaxis++;
        }
        if ($checkPEFF == 'on') {
            if ($line_num > 2) {
                $pastline_num = $line_num - 1;
                $pasthour     = substr($SDTE[$pastline_num], 0, 2);
                $pastminute   = substr($SDTE[$pastline_num], 3, 2);
                $pastseconde  = substr($SDTE[$pastline_num], 6, 2);
                $diffUTCdate  = strtotime($year . '-' . $month . '-' . $day . ' ' . $pasthour . ':' . $pastminute . ':' . $pastseconde);
                $diffTime     = $epochdate - $diffUTCdate;
                $PEFF         = round(((($KWHT[$line_num] - $KWHT[$pastline_num]) * 3600 * 1000 * 1000) / ($diffTime * $PLANT_POWER)), 1); //
            } else {
                $PEFF = 0;
            }
            $stackname[$countstack]        = $lgDPEFF;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                $PEFF
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkPEFF1 == 'on') {
            $PEFF                          = round(($I1P / $ARRAY1_POWER) * 1000, 1);
            $stackname[$countstack]        = $lgDPEFF1;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                $PEFF
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkPEFF2 == 'on') {
            $PEFF                          = round(($I2P / $ARRAY2_POWER) * 1000, 1);
            $stackname[$countstack]        = $lgDPEFF2;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                $PEFF
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkPEFF == 'on' || $checkPEFF1 == 'on' || $checkPEFF2 == 'on') {
            $nbryaxis++;
        }
        
        
        
        if ($checkI1V == 'on') {
            $stackname[$countstack]        = $lgDVOLTAGE1;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($I1V, 2)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkI2V == 'on') {
            $stackname[$countstack]        = $lgDVOLTAGE2;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($I2V, 2)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkGV == 'on') {
            $stackname[$countstack]        = $lgDGRIDVOLTAGE;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($GV, 2)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        
        if ($checkI1V == 'on' || $checkI2V == 'on' || $checkGV == 'on') {
            $nbryaxis++;
        }
        
        if ($checkI1A == 'on') {
            $stackname[$countstack]        = $lgDCURRENT1;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($I1A, 2)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkI2A == 'on') {
            $stackname[$countstack]        = $lgDCURRENT2;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($I2A, 2)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkGA == 'on') {
            $stackname[$countstack]        = $lgDGRIDCURRENT;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($GA, 2)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        
        if ($checkI1A == 'on' || $checkI2A == 'on' || $checkGA == 'on') {
            $nbryaxis++;
        }
        
        if ($checkFRQ == 'on') {
            $stackname[$countstack]        = $lgDFREQ;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($FRQ, 2)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $nbryaxis++;
            $countstack++;
        }
        if ($checkEFF == 'on') {
            $stackname[$countstack]        = $lgDEFFICIENCY;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($EFF, 1)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $nbryaxis++;
            $countstack++;
        }
        
        if ($checkINVT == 'on') {
            $stackname[$countstack]        = $lgDINVERTERTEMP;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($INVT, 1)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        if ($checkBOOT == 'on') {
            $stackname[$countstack]        = $lgDBOOSTERTEMP;
            $stack[$countstack][$line_num] = array(
                $UTCdate,
                round($BOOT, 1)
            );
            $yaxis[$countstack]            = $nbryaxis;
            $type[$countstack]             = 'spline';
            $dashStyle[$countstack]        = 'Solid';
            $countstack++;
        }
        
        $nbryaxis = 0;
    } // End of foreach
    
    $contalines--;
    if (!isset($KWHT[0])) {
        $KWHT[0] = 0;
    }
    if (!isset($KWHT[$contalines])) {
        $KWHT[$contalines] = 0;
    }
    $KWHD = round((($KWHT[$contalines] - $KWHT[1]) * $CORRECTFACTOR), 2);
    $KWHD = number_format($KWHD, 2, $DPOINT, $THSEP);
    
    if ($invtnum == 0 || $NUMINV == 1) {
        $parttitle = '';
    } else {
        $parttitle = "$lgINVT$invtnum - ";
    }
    
    $dday = date($DATEFORMAT, mktime(0, 0, 0, $month, $day, $year));
    
    settype($titledate, 'string');
    $title = "$parttitle $lgDETAILEDOFTITLE $dday $titledate ($KWHD kWh)";
    
    $data = array();
    // Return datas via json
    for ($i = 0; $i < $countstack; $i++) {
        sort($stack[$i]);
        $data[$i] = array(
            'name' => $stackname[$i],
            'data' => $stack[$i],
            'yAxis' => $yaxis[$i],
            'type' => $type[$i],
            'dashStyle' => $dashStyle[$i]
        );
    }
    
    $jsonreturn = array(
        'data' => $data,
        'title' => $title
    );
} else {
    $jsonreturn = array(
        'data' => null,
        'title' => 'No Data'
    );
    
}
header("Content-type: text/json");
echo json_encode($jsonreturn);
?>
