<?php 
include("styles/globalheader.php");
if(!empty($_GET['invtnum']) && is_numeric($_GET['invtnum'])) {$invtnum=$_GET['invtnum'];} else {$invtnum=1;}
include('scripts/read_invtcfg.php');
  
$IMAX=round(($YMAX*2/($VGRIDT+$VGRIDUT)),0, PHP_ROUND_HALF_UP)+1;
$VGRIDMin=round(($VGRIDUT*0.96),0);
$VGRIDMax=round(($VGRIDT*1.05),0, PHP_ROUND_HALF_UP);
?>

<script type="text/javascript">
var invtnum = <?php echo $invtnum; ?>;
$(document).ready(function() 
{
Highcharts.setOptions({
global: {useUTC: true},
lang: {
decimalPoint: '<?php echo $DPOINT ?>',
thousandsSep: '<?php echo $THSEP ?>'
}
});

/// Live gauge1 ///
var gauge1, options1 = {
  chart: {
    renderTo: 'container1',
    type: 'gauge',
    backgroundColor: null,
    plotBackgroundColor: null,
    plotBackgroundImage: null,
    plotBorderWidth: 0,
    plotShadow: false,
    height: 230
  },
  loading: {
  labelStyle: { top: '45%'  },
  style: { backgroundColor: null }
  },
  title: {
    text: '--'
  },
  plotOptions: {
  gauge: {
    pivot: {
      radius: 8,
      borderWidth: 1,
      borderColor: '#303030',
      backgroundColor: {
        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
        stops: [
          [0, '#AAA'],
          [1, '#333']
        ]
      }
    },
    dial: {
      baseLength : 10,
      baseWidth: 8,
      backgroundColor: '#666',
      radius : 70,
      rearLength: 40
    }
  }},
  pane: {
    startAngle: -150,
    endAngle: 150,
            background: [{
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 1, x2: 0, y2: 0 },
                    stops: [
                        [0, '#333'],
                        [1, '#AAA']
                    ]
                },
                borderWidth: 0,
                outerRadius: '115%'
            }, {
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 1, x2: 0, y2:0 },
                    stops: [
                        [0, '#AAA'],
                        [1, '#FFF']
                    ]
                },
                borderWidth: 1,
                outerRadius: '113%'
            },{
                // default background
            }, {
                backgroundColor: Highcharts.svg ? {
                    radialGradient: {
                        cx: 0.5,
                        cy: -0.6,
                        r: 1.6
                    },
                    stops: [
                        [0.5, 'rgba(255, 255, 255, 0.1)'],
                        [0.3, 'rgba(200, 200, 200, 0.1)']
                    ]
                } : null },{
                backgroundColor: Highcharts.svg ? {
                    radialGradient: {
                        cx: 0.5,
                        cy: -0.9,
                        r: 2.6
                    },
                    stops: [
                        [0.5, 'rgba(255, 255, 255, 0.1)'],
                        [0.3, 'rgba(200, 200, 200, 0.1)']
                    ]
                } : null }
                        ]
  },
  yAxis: {
    min: 0,
    max: <?php echo "$ARRAY1_POWER";?>,
    labels: {
        distance: 50,
        rotation: 'auto'
    },
    
    minorTickInterval: 'auto',
    minorTickWidth: 1,
    minorTickLength: 5,
    minorTickPosition: 'inside',
    minorTickColor: '#666',

    tickPixelInterval: 50,
    tickWidth: 2,
    tickPosition: 'inside',
    tickLength: 15,
    tickColor: '#666',
    labels: {
      step: 2,
      rotation: 'auto'
    },
    title: {
      style: {
        color: '#555',
        fontSize: '18px'
      },
      y: 105,
      text: 'W'
    },
    plotBands: [{
      from: 0,
      to: <?php $Y9=round(($ARRAY1_POWER/9),0); echo $Y9;?>,
      color: '#F10D17'
    }, {
      from: <?php echo $Y9;?> ,
      to: <?php echo $Y9*2;?>,
      color: '#F76415'
    }, {
      from: <?php echo $Y9*2;?>,
      to: <?php echo $Y9*3;?>,
      color: '#F29D16'
    }, {
      from: <?php echo $Y9*3;?>,
      to: <?php echo $Y9*4;?>,
      color: '#FFEA32'
    }, {
      from: <?php echo $Y9*4;?>,
      to: <?php echo $Y9*5;?>,
      color: '#FFFF45'
    }, {
      from: <?php echo $Y9*5;?>,
      to: <?php echo $Y9*6;?>,
      color: '#ECFF31'
    }, {
      from: <?php echo $Y9*6;?>,
      to: <?php echo $Y9*7;?>,
      color: '#94DE40'
    }, {
      from: <?php echo $Y9*7;?>,
      to: <?php echo $Y9*8;?>,
      color: '#2EC846'
    }, {
      from: <?php echo $Y9*8;?>,
      to: <?php echo $ARRAY1_POWER;?>,
      color: '#0DB44C'
    }]        
  },
  exporting: {enabled: false},
  credits: {enabled: false},
  series: [{
    name: 'power',
    data: [0],
    tooltip: {
      valueSuffix: 'W'
    },
    dataLabels: {
      enabled: true,
  formatter: function() {
    if (this.y>=1000) {
    return Highcharts.numberFormat(this.y,'0');
    } else {
    return Highcharts.numberFormat(this.y,'1');
    }
  },
      color: '#666',
      x: 0,
      y: 30,
      style: {
      fontSize: '12px'
      }
    }
  }]
};
/// Live gauge2 ///
var gauge2, options2 = {
  chart: {
    renderTo: 'container2',
    type: 'gauge',
    backgroundColor: null,
    plotBackgroundColor: null,
    plotBackgroundImage: null,
    plotBorderWidth: 0,
    plotShadow: false,
    height: 230
  },
  loading: {
  labelStyle: { top: '45%'  },
  style: { backgroundColor: null }
  },
  title: {
    text: '--'
  },
  plotOptions: {
  gauge: {
    pivot: {
      radius: 8,
      borderWidth: 1,
      borderColor: '#303030',
      backgroundColor: {
        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
        stops: [
          [0, '#AAA'],
          [1, '#333']
        ]
      }
    },
    dial: {
      baseLength : 10,
      baseWidth: 8,
      backgroundColor: '#666',
      radius : 70,
      rearLength: 40
    }
  }},
  pane: {
    startAngle: -150,
    endAngle: 150,
            background: [{
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 1, x2: 0, y2: 0 },
                    stops: [
                        [0, '#333'],
                        [1, '#AAA']
                    ]
                },
                borderWidth: 0,
                outerRadius: '115%'
            }, {
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 1, x2: 0, y2:0 },
                    stops: [
                        [0, '#AAA'],
                        [1, '#FFF']
                    ]
                },
                borderWidth: 1,
                outerRadius: '113%'
            },{
                // default background
            }, {
                backgroundColor: Highcharts.svg ? {
                    radialGradient: {
                        cx: 0.5,
                        cy: -0.6,
                        r: 1.6
                    },
                    stops: [
                        [0.5, 'rgba(255, 255, 255, 0.1)'],
                        [0.3, 'rgba(200, 200, 200, 0.1)']
                    ]
                } : null },{
                backgroundColor: Highcharts.svg ? {
                    radialGradient: {
                        cx: 0.5,
                        cy: -0.9,
                        r: 2.6
                    },
                    stops: [
                        [0.5, 'rgba(255, 255, 255, 0.1)'],
                        [0.3, 'rgba(200, 200, 200, 0.1)']
                    ]
                } : null }
                        ]
  },
  yAxis: {
    min: 0,
    max: <?php echo "$ARRAY2_POWER";?>,
    labels: {
        distance: 50,
        rotation: 'auto'
    },
    
    minorTickInterval: 'auto',
    minorTickWidth: 1,
    minorTickLength: 5,
    minorTickPosition: 'inside',
    minorTickColor: '#666',

    tickPixelInterval: 50,
    tickWidth: 2,
    tickPosition: 'inside',
    tickLength: 15,
    tickColor: '#666',
    labels: {
      step: 2,
      rotation: 'auto'
    },
    title: {
      style: {
        color: '#555',
        fontSize: '18px'
      },
      y: 105,
      text: 'W'
    },
    plotBands: [{
      from: 0,
      to: <?php $Y9=round(($ARRAY2_POWER/9),0); echo $Y9;?>,
      color: '#F10D17'
    }, {
      from: <?php echo $Y9;?> ,
      to: <?php echo $Y9*2;?>,
      color: '#F76415'
    }, {
      from: <?php echo $Y9*2;?>,
      to: <?php echo $Y9*3;?>,
      color: '#F29D16'
    }, {
      from: <?php echo $Y9*3;?>,
      to: <?php echo $Y9*4;?>,
      color: '#FFEA32'
    }, {
      from: <?php echo $Y9*4;?>,
      to: <?php echo $Y9*5;?>,
      color: '#FFFF45'
    }, {
      from: <?php echo $Y9*5;?>,
      to: <?php echo $Y9*6;?>,
      color: '#ECFF31'
    }, {
      from: <?php echo $Y9*6;?>,
      to: <?php echo $Y9*7;?>,
      color: '#94DE40'
    }, {
      from: <?php echo $Y9*7;?>,
      to: <?php echo $Y9*8;?>,
      color: '#2EC846'
    }, {
      from: <?php echo $Y9*8;?>,
      to: <?php echo $ARRAY2_POWER;?>,
      color: '#0DB44C'
    }]        
  },
  exporting: {enabled: false},
  credits: {enabled: false},
  series: [{
    name: 'power',
    data: [0],
    tooltip: {
      valueSuffix: 'W'
    },
    dataLabels: {
      enabled: true,
  formatter: function() {
    if (this.y>=1000) {
    return Highcharts.numberFormat(this.y,'0');
    } else {
    return Highcharts.numberFormat(this.y,'1');
    }
  },
      color: '#666',
      x: 0,
      y: 30,
      style: {
      fontSize: '12px'
      }
    }
  }]
};

/// Live gauge GV ///
var gauge3, options3 = {
  chart: {
    renderTo: 'container3',
    type: 'gauge',
    backgroundColor: null,
    plotBackgroundImage: null,
    plotBorderWidth: 1,
    plotShadow: true,
    width: 230,
    plotBackgroundColor: {
      linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
      stops: [
        [0, '#FFF'],
        [0.9, '#DDD'],
        [1, '#CCC']
      ]
    },
    plotBackgroundImage: null,
    height: 160
        },
    exporting: {enabled: false},
        credits: {enabled: false},
        title: {
        text: '-- V'
        },
        pane: {
            startAngle: -45,
            endAngle: 45,
            background: null,
            center: ['50%', '145%'],
            size: 220
        },                        
        yAxis: {
            min: <?php echo $VGRIDMin; ?>,
            max: <?php echo $VGRIDMax; ?>,
            minorTickPosition: 'outside',
            tickPosition: 'outside',
      plotBands: [{
                from: <?php echo $VGRIDT; ?>,
                to: <?php echo $VGRIDMax; ?>,
                color: '#C02316',
                innerRadius: '100%',
                outerRadius: '105%'
            }],
           endOnTick: false,
            title: {
              style: {
                color: '#555',
                fontSize: '18px'
              },
            text: 'V~',
            y: -20
            },
            labels: {
                rotation: 'auto',
                distance: 20
            }
        },
        plotOptions: {
            gauge: {
                dataLabels: {
                    enabled: false
                },
                dial: {
                    radius: '100%'
                }
            }
        },
        series: [{
      name: 'Grid V',
      data: [0],
      tooltip: {
      valueSuffix: 'V'
      },
      dataLabels: {
      enabled: false
      }
    }
               ]
    };
/// Live gauge GA ///
var gauge4, options4 = {
  chart: {
    renderTo: 'container4',
    type: 'gauge',
    backgroundColor: null,
    plotBackgroundImage: null,
    plotBorderWidth: 1,
    plotShadow: true,
    width: 230,
    plotBackgroundColor: {
      linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
      stops: [
        [0, '#FFF'],
        [0.9, '#DDD'],
        [1, '#CCC']
      ]
    },
    plotBackgroundImage: null,
    height: 160
        },
    exporting: {enabled: false},
        credits: {enabled: false},
        title: {
        text: '-- A'
        },
        pane: {
            startAngle: -45,
            endAngle: 45,
            background: null,
            center: ['50%', '145%'],
            size: 220
        },                        
        yAxis: {
            min: 0,
            max: <?php echo $IMAX ?>,
            minorTickPosition: 'outside',
            tickPosition: 'outside',
            title: {
              style: {
                color: '#555',
                fontSize: '18px'
              },
            text: 'A',
            y: -20
            },
            labels: {
                rotation: 'auto',
                distance: 20
            }
        },
        plotOptions: {
            gauge: {
                dataLabels: {
                    enabled: false
                },
                dial: {
                    radius: '100%'
                }
            }
        },
        series: [{
      name: 'Grid A',
      data: [0],
      tooltip: {
      valueSuffix: 'A'
      },
      dataLabels: {
      enabled: false
      }
    }
               ]
    };

<?php 
  if ($STRING!=2) {
  echo "
  gauge1 = new Highcharts.Chart(options1);
  gauge1.series[0].data[0].dataLabel.box.hide();
  ";
  }
  if ($STRING!=1) {
  echo "
  gauge2 = new Highcharts.Chart(options2);
  gauge2.series[0].data[0].dataLabel.box.hide();
  ";
  }
?>

gauge3 = new Highcharts.Chart(options3);
  gauge3.renderer.text('<div id="hz"></div>', 185, 143,true)
    .css({
      color: '#555',
      fontSize: '11px'
    })
    .add();
gauge4 = new Highcharts.Chart(options4);

  function updateit() {
  var invtnum = <?php echo $invtnum; ?>;
  $.getJSON("programs/programlive.php", { invtnum: invtnum }, function(rdata){
  json = eval(rdata);
  document.getElementById('stamp').innerHTML = json[0].timestamp;
  <?php
  if ($STRING!=2) {
  echo "
  var point = gauge1.series[0].points[0];
  point.update(json[0].I1P);
  gauge1.setTitle({ text: Highcharts.numberFormat(json[0].I1V,'1') +'VDC  '+ Highcharts.numberFormat(json[0].I1A,'1') + 'A'});
  ";
  }
  if ($STRING!=1) {
  echo "
  var point = gauge2.series[0].points[0];
  point.update(json[0].I2P);
  gauge2.setTitle({ text: Highcharts.numberFormat(json[0].I2V,'1') +'VDC  '+ Highcharts.numberFormat(json[0].I2A,'1') + 'A'});
  ";
  }
  ?>
if (json[0].GP>=1000) {
  document.getElementById('GP').innerHTML = Highcharts.numberFormat(json[0].GP,'0');
} else {
  document.getElementById('GP').innerHTML = Highcharts.numberFormat(json[0].GP,'1');
}
  var point = gauge3.series[0].points[0];
  point.update(json[0].GV);
  gauge3.setTitle({ text: Highcharts.numberFormat(json[0].GV,'1') +"V"});
  $('#hz').html(json[0].FRQ + "Hz");
  var point = gauge4.series[0].points[0];
  point.update(json[0].GA);
  gauge4.setTitle({ text: Highcharts.numberFormat(json[0].GA,'1') +'A'});
  document.getElementById('EFF').innerHTML = Highcharts.numberFormat(json[0].EFF,'1');
  document.getElementById('BOOT').innerHTML = Highcharts.numberFormat(json[0].BOOT,'1');
  document.getElementById('INVT').innerHTML = Highcharts.numberFormat(json[0].INVT,'1');
  document.getElementById('RISO').innerHTML = Highcharts.numberFormat(json[0].riso,'2');
  document.getElementById('ILEAK').innerHTML = Highcharts.numberFormat(json[0].ileak,'1');
  document.getElementById('AWT').innerHTML = json[0].awdate;
  })
  $.getJSON("programs/programdashboard.php", { invtnum: invtnum }, function(rdata){
  	json = eval(rdata);
  	document.getElementById('STATE').innerHTML = json[0];
  	document.getElementById('PPEAK').innerHTML = Highcharts.numberFormat(json[1],'1');
  	document.getElementById('PPEAKOTD').innerHTML = Highcharts.numberFormat(json[2],'1');
  })	
  }
updateit();
setInterval(updateit, 1000);
});
</script>  
<?php
if ($SKIPMONITORING==1) { echo "<img src='images/exclamation.png' width='16' height='16' border='0'><b> Inverter down for maintenance</b><br>";}
?>
<table width="600" border=0 align=left cellpadding="0">
<tr>
<td align='left'><b>
<?php
  echo "$lgDASHBOARD";
if($NUMINV>1) {
  echo " $lgINVT $invtnum"; 
}
?>
</b>
</td>
<td align='right'><span id='stamp'>--</span></td>
</tr>
</table>
<br><hr width="600" align="left">
<table width=600 border=0 align=left cellpadding="0">
<tr>
<td width=300>
<?php
if ($STRING!=2) {
echo "<b>$lgINPUT1 :</b>
<br><div id='container1'></div>
";
}
?>
</td>
<td width=300>
<?php
if ($STRING!=1) {
echo "<b>$lgINPUT2 :</b>
<br><div id='container2'></div>
";
}
?>
</td>
</tr>
<tr>
<td COLSPAN="2">
<b><?php echo "$lgGRID";?> <span id='GP'>--</span>W :</b>
</td>
</tr>
<tr align='center'>
<td>
<div id="container3"></div>
</td>
<td>
<div id="container4"></div>
</td>
</tr>
<tr>
<td COLSPAN="2">
<br>
<?php echo "$lgDEFFICIENCY ";?><span id='EFF'>--</span>%<br>
<?php echo "$lgDBOOSTERTEMP ";?><span id='BOOT'>--</span>°c<br>
<?php echo "$lgDINVERTERTEMP ";?><span id='INVT'>--</span>°c<br>
<br><?php echo "$lgPPEAK ";?><span id='PPEAK'>--</span>W, <?php echo "$lgPPEAKOTD ";?><span id='PPEAKOTD'>--</span>W 
<br><br>
<?php echo "$lgAWCHK ";?> <span id='AWT'>--</span><br>
R.iso. <span id='RISO'>--</span>Mohm - iLeak <span id='ILEAK'>--</span>mA
<br>
<span id='STATE'>--</span>
</td>
</tr>
</table>

<?php include("styles/".$user_style."/footer.php"); ?>
