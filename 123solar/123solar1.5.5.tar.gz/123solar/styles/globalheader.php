<?php
include('scripts/read_maincfg.php'); 
date_default_timezone_set($DTZ);
if (!empty ($_POST['user_lang']) && is_string($_POST['user_lang'])) { 
  $user_lang = htmlspecialchars($_POST['user_lang'], ENT_QUOTES, "UTF-8");
  setcookie('user_lang',$_POST['user_lang'],strtotime('+5 year'));
} elseif (isset($_COOKIE['user_lang'])){
$user_lang=$_COOKIE['user_lang'];
} else {
$user_lang="English";  
}
include("languages/".$user_lang.".php");

if (!empty ($_POST['user_style']) && is_string($_POST['user_style'])) { 
  $user_style = htmlspecialchars($_POST['user_style'], ENT_QUOTES, "UTF-8");
  setcookie('user_style',$_POST['user_style'],strtotime('+5 year'));
} elseif (isset($_COOKIE['user_style'])){
$user_style=$_COOKIE['user_style'];
} else {
$user_style="default";  
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?php echo "$TITLE";?></title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link href="favicon.ico" rel="icon" type="image/x-icon">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<link rel="stylesheet" href="js/jqueryuicss/jquery-ui.css" type="text/css">
<script type="text/javascript" src="js/highcharts.js"></script>
<script type="text/javascript" src="js/highcharts-more.js"></script>
<script type="text/javascript" src="js/modules/exporting.js"></script>
<link rel="stylesheet" href="styles/<?php echo $user_style;?>/css/style.css" type="text/css">
<?php include("styles/yourheader.php");?>
</head>
<?php 
  if ($NUMINV==1) {
  include("styles/".$user_style."/header.php");
  } else {
  include("styles/".$user_style."/header_multi.php");
  }
?>
