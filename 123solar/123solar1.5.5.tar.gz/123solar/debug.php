<?php include("config/version.php");
include("scripts/read_maincfg.php");
date_default_timezone_set($DTZ);
$nowUTC = strtotime(date("Ymd H:i:s"));
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>123Solar debug</title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
</head> 
<body>
<b>123Solar debug (Press F5 to refresh)</b>
<hr>
<table border=0 CELLPADDING=0>
<tr><td>  
<b>Checking hardware :</b><br>
<?php
$datareturn = shell_exec('lsusb');
?>
<textarea style="resize: none;background-color: #DCDCDC" cols="100" rows="5">
<?php echo $datareturn; ?>
</textarea> 
</td>
  <td>Check if your USB/RS485 converter is present. eg: Chipset PL2303.
</td></tr>
  <tr><td>  
<?php
$datareturn = shell_exec('lsmod');
?>
<textarea style="resize: none;background-color: #DCDCDC" cols="100" rows="5">
<?php echo $datareturn; ?>
</textarea> 
</td>
  <td>If using a converter, usbserial module <b>should</b> be loaded
</td></tr>
<tr><td>  
<b>Checking PHP:</b><br>
<?php echo 'PHP version: ' . phpversion();
$input = '{ "jsontest" : " <br>Json extension loaded" }';
$val = json_decode($input, true);
if ($val["jsontest"]!="") {
echo $val["jsontest"];
} else {
echo "<br>Json extension -NOT- loaded";
}

if (extension_loaded('calendar')) {
echo "<br>Calendar extension loaded";
} else {
echo "<br>Calendar extension -NOT- loaded";
}

if (extension_loaded('shmop')) {
echo "<br>Shmop extension loaded";
} else {
echo "<br>Shmop extension -NOT- loaded";
}
$ndday    = date($DATEFORMAT . " H:i:s", $nowUTC);
echo "<br>You timezone is set to $DTZ ($ndday)";
if (ini_get('sendmail_path')) {
    echo '<br>Your sendmail_path is set to ' . ini_get('sendmail_path');
} else {
    echo '<br>Your sendmail_path is NOT set';
}
?>
</td><td>
<br>PHP > v5<br>
<b>Php.ini configuration</b><br>
json, shmod and calendar extensions <b>must</b> be loaded<br>
The date and time should be correct<br>
Check also if your sendmail command is correct.
</td></tr>
<tr><td>  
<b>Checking Software:</b><br>
<?php
$datareturn = shell_exec('ps -ef | egrep -i "123solar|aurora|sma_get|SMAspot" | grep -v grep');
?>
<textarea style="resize: none;background-color: #DCDCDC" cols="100" rows="3">
<?php echo $datareturn; ?>
</textarea>
</td>
  <td>Version : <?php echo $VERSION;?>
    <br>You <b>should</b> see 123solar start and sometimes aurora -a2 -c -T -d0 -e and/or sma_get and/or SMAspot..
</td></tr>
<?php $datareturn = substr(shell_exec('curl -V'),0,12);
  if (empty($datareturn)){
    $datareturn = "NOT installed";
  }
echo "<tr><td>
<b>Checking PVoutput :</b>
<br>Curl version : $datareturn";
if (extension_loaded('curl')) {
echo "<br>curl extension loaded";
} else {
echo "<br>curlextension -NOT- loaded";
}
  
$lines  = file('data/pvoutput_return.txt');
echo "<br>
PVoutput return log :<br>
<textarea style='resize: none;background-color: #DCDCDC' cols='100' rows='5'>";
foreach ($lines as $line_num => $line) {
    echo "$line";
}
?>
</textarea>  
</td>
<td>
Curl must be installed
<br>Extension must be enable
<br>
<br>
<br>/!\ Debug must be enable in the admin interface to update pvoutput logs
</td></tr>
<tr><td>PVoutput Errors log :
<br><textarea style='resize: none;background-color: #DCDCDC' cols='100' rows='5'>
<?php
$lines  = file('data/pvoutput_err.txt');
foreach ($lines as $line_num => $line) {
    echo "$line";
} 
?>
</textarea>  
</td><td></td>
</tr>
<tr><td>
<b>Checking communication app :</b>
<br>Current settings are
<?php 
if ($DEBUG!=true) {
echo "-c -T $COMOPTION -d0 -e $PORT";
} else {
echo "-b -c -T $COMOPTION -d0 -e $PORT 2> data/errors/de.err";
}
?>
<br>
<a href="data/invt1/errors/">Inverters communication errors</a> (You have to enable debug to get all details)
<br>  
<b>Others :</b>
<br>
<a href="scripts/debugmem_read.php">Shared memory usage</a>
</td>
<td>
</td></tr>
</table>
</body>
