#!/bin/bash
# Louviaux Jean-Marc
# 123Solar install script
SOURCE="${BASH_SOURCE[0]}"
DIR="$( dirname "$SOURCE" )"
while [ -h "$SOURCE" ]
do 
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
  DIR="$( cd -P "$( dirname "$SOURCE"  )" && pwd )"
done
DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

  function pause(){
     read -p "$*"
  }

clear
  echo "Welcome to 123Solar - Louviaux Jean-Marc"
  echo ""
  echo "Please, read carefully the README before installing"
  echo ""
read -p "Do you want to install (y/n) ? " choice
case "$choice" in 
  y|Y )

   if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 1>&2
   echo "Aborting.."; exit 1;
   fi

   if ps ax | grep -v grep | grep "123solar" > /dev/null
   then
    echo "123Solar is already running, please stop it first"
    echo "Aborting.."; exit 1;
   fi
   if ps ax | grep -v grep | grep "123aurora" > /dev/null
   then
    echo "An old version of 123aurora is already running, please stop it first"
    echo "Aborting.."; exit 1;
   fi
   if [ -f /usr/bin/123aurora ]
   then
     rm -f /usr/bin/123aurora
   fi
   if [ -f /usr/bin/123solar ]
   then
     rm -f /usr/bin/123solar
   fi
   ln -sf "$DIR"/scripts/123solar.sh /usr/bin/123solar

  chmod 666 config/config_*
  chmod 770 scripts/123solar.sh scripts/worker.php
  chmod 770 scripts/123solar.sh scripts/123solar.sh
	 # clear
          echo "Thanks for using 123Solar !"
          echo ""
          echo "Usage: 123solar { admin | start | stop }"
          echo ""
          echo "/!\  Please check the configuration then"
	  echo "save for general and for each inverters"
	  echo ""
	  pause 'Press [Enter] key to continue '
	  123solar admin
  ;;
  n|N ) echo "Aborting..";;
  * ) echo "Aborting..";;
esac
