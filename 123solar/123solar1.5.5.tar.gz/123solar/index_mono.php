<?php 
include('styles/globalheader.php');
if(!empty($_GET['invtnum'])) {
$invtnum = $_GET['invtnum']; 
} else {$invtnum = 1;}
include('scripts/read_invtcfg.php'); 
?>

<script type="text/javascript">
var PLANT_POWER='<?php echo $PLANT_POWER;?>';
$(document).ready(function() 
{
Highcharts.setOptions({
global: {useUTC: true},
lang: {
decimalPoint: '<?php echo $DPOINT ?>',
thousandsSep: '<?php echo $THSEP ?>',
months: ['<?php for($i=1;$i<12;$i++) {echo "$lgMONTH[$i]','";} echo $lgMONTH[12]?>'],
shortMonths: ['<?php for($i=1;$i<12;$i++) {echo "$lgSMONTH[$i]','";} echo $lgSMONTH[12]?>'],
weekdays: ['<?php for($i=1;$i<7;$i++) {echo "$lgWEEKD[$i]','";} echo $lgWEEKD[7]?>']
}
});
var invtnum = <?php echo $invtnum; ?>;
/// Day prod ///
var Mychart1, options1 = {
chart: {
renderTo: 'container1',
backgroundColor: null,
         events: {
            load: function() {
            var invtnum = <?php echo $invtnum; ?>; 
              setInterval(function() { 
               $.getJSON("programs/programdayfeed.php", { invtnum: invtnum }, function(data){
               json = eval(data);
                 x = json[0].LastTime;
                 y = json[0].LastValue;
                 a = json[1].MaxTime;
                 b = json[1].MaxPow;
                 ptitle = json[2].PTITLE;
   		   Mychart1.series[0].addPoint([x, y]);
		   Mychart1.series[1].data[0].update([a, b],false,false,true);
		   Mychart1.series[1].data[1].update([x, y],false,false,true);
		   Mychart1.setTitle({ text: ptitle});
               });
	    Mychart1.redraw();
               }, 30000);
            }
         }
},
colors: [
	'#4572A7', 
	'#AA4643', 
	'#89A54E', 
	'#80699B', 
	'#3D96AE', 
	'#DB843D', 
	'#92A8CD', 
	'#A47D7C', 
	'#B5CA92'
],
loading: {
 labelStyle: { top: '45%'  },
  style: { backgroundColor: null }
},
title: {
<?php echo "text: '$lgTODAYTITLE (... kWh)'";?>
},
subtitle: {
  <?php echo "text: '$lgSUNRISE ..... - $lgTRANSIT ..... - $lgSUNSET .....'";?>  
},  
credits: {enabled: false},
legend: {enabled: false},
plotOptions: {
areaspline: {
   marker: {
   enabled: false,
   symbol: 'circle',
   radius: 2,
   states: {hover: {enabled: true}}
}
},
scatter: {
  dataLabels: {
  enabled: true,
  color: '#4572A7',
  formatter: function() {
  return Highcharts.numberFormat(this.y,'0') + 'W'
  }
  },
   marker: {
   fillColor: '#FFFFFF',
   lineWidth: 2,
   lineColor: '#4572A7', 
   states: {hover: {enabled: false}}
}
}  
},
xAxis: {type: 'datetime'},
yAxis: {
<?php echo "max: $YMAX,";?>
title: {text: '<?php echo "$lgAVGP";?> (W)'},
endOnTick: false,
minorTickInterval: 'auto',
<?php echo "tickInterval: $YINTERVAL,";?>
min: 0
},
tooltip: {
formatter: function() {
return '<b>' + Highcharts.numberFormat(this.y,'0') + 'W' + '</b><br/>' + Highcharts.dateFormat('%H:%M', this.x)
}
},
exporting: {enabled: false},
series: []
};

/// Yesterday prod ///
var Mychart2, options2 = {
chart: {
renderTo: 'container2',
backgroundColor: null
},
colors: [
	'#4572A7', 
	'#AA4643', 
	'#89A54E', 
	'#80699B', 
	'#3D96AE', 
	'#DB843D', 
	'#92A8CD', 
	'#A47D7C', 
	'#B5CA92'
],
loading: {
 labelStyle: { top: '45%'  },
  style: { backgroundColor: null }
},
title: {
<?php echo "text: '$lgYESTERDAYTITLE (... kWh)'";?>
},
credits: {enabled: false},
legend: {enabled: false},
plotOptions: {
areaspline: {
   marker: {
   enabled: false,
   symbol: 'circle',
   radius: 2,
   states: {hover: {enabled: true}}
}
},
scatter: {
  dataLabels: {
  enabled: true,
  color: '#4572A7',
  formatter: function() {
  return Highcharts.numberFormat(this.y,'0') + 'W'
  }
  },
   marker: {
   fillColor: '#FFFFFF',
   lineWidth: 2,
   lineColor: '#4572A7', 
   states: {hover: {enabled: false}
   }
}
}  
},
xAxis: {type: 'datetime'},
yAxis: {
<?php echo "max: $YMAX,";?>
title: {text: '<?php echo "$lgAVGP";?> (W)'},
endOnTick: false,
minorTickInterval: 'auto',
<?php echo "tickInterval: $YINTERVAL,";?>
min: 0
},
tooltip: {
formatter: function() {
return '<b>' + Highcharts.numberFormat(this.y,'0') + 'W' + '</b><br/>' + Highcharts.dateFormat('%H:%M', this.x)
}
},
exporting: {enabled: false},
series: []
};

/// Last days prod ///
var Mychart3, options3 = {
chart: {
renderTo: 'container3',
backgroundColor: null,
defaultSeriesType: 'column'
},
colors: [
	'#4572A7', 
	'#AA4643', 
	'#89A54E', 
	'#80699B', 
	'#3D96AE', 
	'#DB843D', 
	'#92A8CD', 
	'#A47D7C', 
	'#B5CA92'
],
loading: {
 labelStyle: { top: '45%'  },
  style: { backgroundColor: null }
},
credits: {enabled: false},
title: {
<?php echo "text: '$lgLASTPRODTITLE $PRODXDAYS $lgDAYS'";?>
},
subtitle: {text: '<?php echo $lgLASTPRODSUBTITLE;?>'},
xAxis: {
type: 'datetime',
tickmarkPlacement: 'on',
dateTimeLabelFormats: {day: '%e %b'}
},
yAxis: {
title: {text: '<?php echo "$lgENERGY";?> (kWh)'},
minorGridLineWidth: 1,
minorTickInterval: 'auto'
},
min: 0,
legend: {enabled: false},
tooltip: {
formatter: function() {
var point = this.point,
s = '<b>'+Highcharts.dateFormat('%a %e %b', this.x) + ': '+ Highcharts.numberFormat(this.y,'1') +' kWh</b><br>';
s += '<?php echo "$lgEFFICIENCY";?>: ' + Highcharts.numberFormat((this.y/(PLANT_POWER/1000)).toFixed(2),'2')+ ' kWh/kWp';
return s;
}
},
plotOptions: {
  series: {
  	 shadow: true,
    minPointLength: 3,
    point:{
      events: {
        click: function(event) {
          window.location = 'detailed.php?invtnum='+invtnum+'&date2='+this.x;
        }
      }
    }
  },
column: {dataLabels: {enabled: true}}
},
exporting: {enabled: false},
series: [{
        name: 'kWh',
        animation: false,
        dataLabels: {
            enabled: true,
            formatter: function() {
                return Highcharts.numberFormat(this.y,'1');
            }
        }
}]
};

/// Live gauge ///
var Mygauge, options4 = {
  chart: {
    renderTo: 'container',
    type: 'gauge',
    backgroundColor: null,
    plotBackgroundColor: null,
    plotBackgroundImage: null,
    plotBorderWidth: 0,
    plotShadow: false,
    height: 250,
          events: {
        load: function() {
        var invtnum = <?php echo $invtnum; ?>;  
        setInterval(function () {
        $.getJSON("programs/programlive.php", { invtnum: invtnum }, function(rdata){
        json = eval(rdata);
        var point = Mygauge.series[0].points[0];
        point.update(json[0].GP);
        document.getElementById('PMAXOTD').innerHTML = json[0].PMAXOTD;
        document.getElementById('PMAXOTDTIME').innerHTML = json[0].PMAXOTDTIME;  
         });
        }, 500);
            }
         }
  },
  loading: {
  labelStyle: { top: '45%'  },
  style: { backgroundColor: null }
  },
  title: {
    text: ''
  },
  plotOptions: {
  gauge: {
    pivot: {
      radius: 8,
      borderWidth: 1,
      borderColor: '#303030',
      backgroundColor: {
        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
        stops: [
          [0, '#AAA'],
          [1, '#333']
        ]
      }
    },
    dial: {
      baseLength : 10,
      baseWidth: 8,
      backgroundColor: '#666',
      radius : 70,
      rearLength: 40
    }
  }},
  pane: {
    startAngle: -150,
    endAngle: 150,
            background: [{
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 1, x2: 0, y2: 0 },
                    stops: [
                        [0, '#333'],
                        [1, '#AAA']
                    ]
                },
                borderWidth: 0,
                outerRadius: '115%'
            }, {
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 1, x2: 0, y2:0 },
                    stops: [
                        [0, '#AAA'],
                        [1, '#FFF']
                    ]
                },
                borderWidth: 1,
                outerRadius: '113%'
            },{
                // default background
            }, {
                backgroundColor: Highcharts.svg ? {
                    radialGradient: {
                        cx: 0.5,
                        cy: -0.6,
                        r: 1.6
                    },
                    stops: [
                        [0.5, 'rgba(255, 255, 255, 0.1)'],
                        [0.3, 'rgba(200, 200, 200, 0.1)']
                    ]
                } : null },{
                backgroundColor: Highcharts.svg ? {
                    radialGradient: {
                        cx: 0.5,
                        cy: -0.9,
                        r: 2.6
                    },
                    stops: [
                        [0.5, 'rgba(255, 255, 255, 0.1)'],
                        [0.3, 'rgba(200, 200, 200, 0.1)']
                    ]
                } : null }
                        ]
  },
  yAxis: {
    min: 0,
    max: <?php echo "$YMAX";?>,
    labels: {
        distance: 50,
        rotation: 'auto'
    },
    
    minorTickInterval: 'auto',
    minorTickWidth: 1,
    minorTickLength: 5,
    minorTickPosition: 'inside',
    minorTickColor: '#666',

    tickPixelInterval: 50,
    tickWidth: 2,
    tickPosition: 'inside',
    tickLength: 15,
    tickColor: '#666',
    labels: {
      step: 2,
      rotation: 'auto'
    },
    title: {
      style: {
        color: '#555',
        fontSize: '18px'
      },
      y: 125,
      text: 'W'
    },
    plotBands: [{
      from: 0,
      to: <?php $Y9=round(($YMAX/9),0); echo $Y9;?>,
      color: '#F10D17'
    }, {
      from: <?php echo $Y9;?> ,
      to: <?php echo $Y9*2;?>,
      color: '#F76415'
    }, {
      from: <?php echo $Y9*2;?>,
      to: <?php echo $Y9*3;?>,
      color: '#F29D16'
    }, {
      from: <?php echo $Y9*3;?>,
      to: <?php echo $Y9*4;?>,
      color: '#FFEA32'
    }, {
      from: <?php echo $Y9*4;?>,
      to: <?php echo $Y9*5;?>,
      color: '#FFFF45'
    }, {
      from: <?php echo $Y9*5;?>,
      to: <?php echo $Y9*6;?>,
      color: '#ECFF31'
    }, {
      from: <?php echo $Y9*6;?>,
      to: <?php echo $Y9*7;?>,
      color: '#94DE40'
    }, {
      from: <?php echo $Y9*7;?>,
      to: <?php echo $Y9*8;?>,
      color: '#2EC846'
    }, {
      from: <?php echo $Y9*8;?>,
      to: <?php echo $YMAX;?>,
      color: '#0DB44C'
    }]        
  },
  exporting: {enabled: false},
  credits: {enabled: false},
  series: [{
    name: 'power',
    data: [0],
    tooltip: {
      valueSuffix: 'W'
    },
    dataLabels: {
      enabled: true,
	formatter: function() {
		if (this.y>=1000) {
		return Highcharts.numberFormat(this.y,'0');
		} else {
		return Highcharts.numberFormat(this.y,'1');
		}
	},
      color: '#666',
      x: 0,
      y: 40,
      style: {
      fontSize: '12px'
      }
    }
  }]
};
  
Mychart1 = new Highcharts.Chart(options1);
Mychart1.showLoading();
Mychart2 = new Highcharts.Chart(options2);
Mychart2.showLoading();
Mychart3 = new Highcharts.Chart(options3);
Mychart3.showLoading();
  
$.getJSON('programs/programday.php', { invtnum: invtnum }, function(JSONResponse) {
options1.series = JSONResponse.data;
Mychart1 = new Highcharts.Chart(options1);
Mychart1.setTitle({text: JSONResponse.title}, {text: JSONResponse.subtitle});
Mychart1.hideLoading();
});

$.getJSON('programs/programyesterday.php', { invtnum: invtnum }, function(JSONResponse) {
options2.series = JSONResponse.data;
Mychart2= new Highcharts.Chart(options2);
Mychart2.setTitle({text: JSONResponse.title});
Mychart2.hideLoading();
});
  
$.getJSON('programs/programlastdays.php', { invtnum: invtnum }, function(JSONResponse) {
options3.series[0].data = JSONResponse;
Mychart3 = new Highcharts.Chart(options3);
Mychart3.hideLoading();
});

Mygauge = new Highcharts.Chart(options4);
Mygauge.series[0].data[0].dataLabel.box.hide();

});
</script>

<table width="100%" border=0 align=center cellpadding="0">
<tr><td width="80%">
<?php 
if ($NUMINV>1) {
echo "<b>$lgINVT $invtnum -</b>"; 
}
if (!empty($INVNAME)) {echo "<b> $INVNAME</b>";}
if ($SKIPMONITORING==1) { echo " <img src='images/exclamation.png' width='16' height='16' border='0'><b> (Inverter down for maintenance) </b>";}
?>
<div id="container1" style="height: 300px"></div></td>
<td width="20%"><div id="container" align="center" valign="MIDDLE"></div>
<p align="center"><font size="-1"><?php echo "$lgPMAX";?><br><b id='PMAXOTD'>--</b> W @ <b id='PMAXOTDTIME'>--</b><br>
<?php echo "<a href='dashboard.php?invtnum=$invtnum'>$lgDASHBOARD</a>";?>
</font></p>
</td></tr>
</table>
<table width="100%" border=0 align=center cellpadding="0">
<tr><td width="50%"><div id="container2" style="height: 300px"></div></td>
<td width="50%"><div id="container3" style="height: 300px"></div></td></tr>
</table>
<?php include("styles/".$user_style."/footer.php"); ?>
