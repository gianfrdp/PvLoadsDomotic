<?php
//Load main variables from memory

$systemid = 1230;

$shmid = shmop_open($systemid, 'a', 0444, 1024);
$main_cfgdata = shmop_read($shmid, 0, 1024);
shmop_close($shmid);
$main_cfgarray = preg_split('/;/', $main_cfgdata);

$SCRDIR=$main_cfgarray[14]; // Full path

// ### GENERAL
$NUMINV=$main_cfgarray[0];
$NUMSMA=$main_cfgarray[1];  
$AUTOMODE=$main_cfgarray[2];
$DISTRO=$main_cfgarray[3];
// ### LOCALIZATION
$DTZ=$main_cfgarray[4];
$LATITUDE=$main_cfgarray[5];
$LONGITUDE=$main_cfgarray[6];
$DATEFORMAT=$main_cfgarray[7];
$DPOINT=$main_cfgarray[8];
$THSEP=$main_cfgarray[9];
// ### WEB PAGE
$TITLE=$main_cfgarray[10];
$SUBTITLE=$main_cfgarray[11];
// ### CLEANUP
$KEEPDDAYS=$main_cfgarray[12];
$AMOUNTLOG=$main_cfgarray[13];
?>
