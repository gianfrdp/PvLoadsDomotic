#!/bin/bash
# Louviaux Jean-Marc
# 123Solar start and stop script
SOURCE="${BASH_SOURCE[0]}"
DIR="$( dirname "$SOURCE" )"
EPOCH=`date +%s`

while [ -h "$SOURCE" ]
do 
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
  DIR="$( cd -P "$( dirname "$SOURCE"  )" && pwd )"
done
DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
WWWDIR="$( dirname "$DIR" )"

lockFile=/var/run/123solar.pid
if [ -f $lockFile ]; then
CPID="`cat $lockFile`"
fi

looping ()
{ 
while [ "true" ] # To infinity ... and beyond!
do
$WWWDIR"/scripts/worker.php" > /dev/null 2>&1
#$WWWDIR"/scripts/worker.php" 2>> $WWWDIR"/scripts/worker.err"
done
}

case $1 in
start)
  type php >/dev/null 2>&1 || { echo >&2 "Php not installed. Aborting."; exit 1; }
  if ! type sma_get >/dev/null 2>&1 && ! type aurora >/dev/null >/dev/null 2>&1 && ! type SMAspot >/dev/null 2>&1
  then
  echo >&2 "aurora, sma_get or SMAspot is not installed. Aborting."; exit 1;
  fi
  { 
  while [ "$EPOCH" -lt "1242975600" ]
  do
  EPOCH=`date +%s`
  date; echo >&2 "Computer date is not correct. Restarting..";
  sleep 5
  done
  }

  if [ ! -f $lockFile ]; then
    echo "Starting 123Solar.."
    php $WWWDIR"/config/loadcfg.php" > /dev/null 2>&1
    looping &
    echo $! > /var/run/123solar.pid
  else
    echo "123Solar is already started as PID:$CPID"
  fi
;;
stop)
  if [ -f $lockFile ]; then
    kill -9 $CPID
    rm $lockFile
    sleep 1
    echo "Stopping 123Solar"
  else
    echo "123Solar was already stopped"
  fi
;;
admin)  
  clear
  type shuf >/dev/null 2>&1 || { echo >&2 "NOTICE: shuf not installed."; }
  type netstat >/dev/null 2>&1 || { echo >&2 "NOTICE: netstat not installed."; }
  echo "<?php die;?>" > $WWWDIR"/config/123pass.php"
  shuf -i 10000-9999999 -n 1 >> $WWWDIR"/config/123pass.php"

  set -e
  function cleanup {
    echo "Admin session terminated"
    rm -f $WWWDIR"/config/123pass.php"
  }

  function pause(){
     read -p "$*"
     trap cleanup EXIT
  }

  IP=`netstat -n -t | awk '{print $4}' | grep -o "[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*" | grep -v "127.0.0.1" | sort -u`

  echo "123Solar administration"
  echo ""
  echo "Log on to http://$IP/123solar/config/index.php"
  echo "User: admin"
  echo "One-time password :" `tail -n1 $WWWDIR"/config/123pass.php"`
  echo ""
  pause 'Press [Enter] key to quit...'
  if [ ! -f $lockFile ]; then
    read -p "Do you want to start 123Solar (y/n) ? " choice
    case "$choice" in 
      y|Y )
    123solar start
    ;;
      n|N ) echo "Skipping..";;
            * ) echo "Skipping..";;
    esac
  else 
  echo "Restarting.."
  123solar stop
  123solar start
  fi
;;
*)
clear
echo "Welcome to 123Solar - Louviaux Jean-Marc

Usage: 123solar { admin | start | stop }
"
;;
esac
exit 0
