#!/bin/bash
# Louviaux Jean-Marc
# 123Solar shared memory purge

lockFile=/var/run/123solar.pid
if [ -f $lockFile ]; then
CPID="`cat $lockFile`"
fi

clear
echo ""
read -p "/!\ Do you want to clear the shared memory used by 123Solar (y/n) ? " choice
case "$choice" in 
y|Y )
  if [ ! -f $lockFile ]; then
	   if [[ $EUID -ne 0 ]]; then
	   echo "This script must be run as root" 1>&2
	   echo "Aborting.."; exit 1;
	   fi
	echo "How many inverter(s) do you have ?"
	read numi
		if [ $numi -gt 1 ]
		then ipcrm -M 12320
		fi
	while [ $numi -gt 0 ]
	do
	echo "clearing invt #$numi"
	ipcrm -M "123$numi"
	ipcrm -M "1231$numi"
	ipcrm -M "1232$numi"
	ipcrm -M "1233$numi"
	ipcrm -M "1234$numi"
	ipcrm -M "1235$numi"
	ipcrm -M "1236$numi"
	numi=$(( $numi - 1 ))
	done

	echo "clearing main cfg"
	ipcrm -M 1230
	ipcrm -M 12310

  else
    echo "Please stop 123Solar before"
  fi
;;
n|N ) echo "Aborting.."; exit 1;
;;
esac
