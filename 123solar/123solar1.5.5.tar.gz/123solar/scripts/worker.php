#!/usr/bin/php
<?php
// Credit Louviaux Jean-Marc 2013
if (isset($_SERVER['REMOTE_ADDR'])) {
    die('Direct access not permitted');
}
set_time_limit(90);
include('read_maincfg.php'); //Load main constants
date_default_timezone_set($DTZ);

function sma_daemon_control($COMMAND, $now, $DEBUG)
{
    include('read_maincfg.php');
    if ($COMMAND == 'CHECK') {
        $datareturn = shell_exec('sma_get -r');
        if (strpos($datareturn, 'down') > 0) {
            for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) { // log on all SMA
                $invtnum = $invt_num;
                include('read_invtcfg.php');
                if ($PROTOCOL == 'sma_get' && $DAEMONMODE == 1) {
                    $DATADIR    = dirname($SCRDIR) . "/data/invt$invt_num";
                    $stringData = "$now\tStart daemon for " . ($NUMSMA) . " SMA(s)\n\n";
                    $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                    file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                }
            }
            $NUMSMA--;
            if ($DEBUG != true) {
                shell_exec('nohup $CMD_POOLINGsma_get -D -n' . $NUMSMA . ' >/dev/null 2>&1 &');
            } else {
                $DATADIR = dirname($SCRDIR) . '/data/';
                shell_exec('nohup sma_get -D -b -n' . $NUMSMA . ' >' . $DATADIR . 'sma_daemon.err 2>&1 &');
            }
            sleep(10); // min is 3 secs    
        }
    }
    if ($COMMAND == 'SHUTDOWN') {
        for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) {
            $invtnum = $invt_num;
            include('read_invtcfg.php');
            if ($PROTOCOL == 'sma_get' && $DAEMONMODE == 1) {
                $DATADIR    = dirname($SCRDIR) . "/data/invt$invt_num";
                $stringData = "$now\tShutdown sma_get daemon\n\n";
                $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                shell_exec('sma_get -x');
            }
        }
    }
}

if ($AUTOMODE == 1) {
    @$shmid = shmop_open(12310, 'a', 0444, 1); // awake flag
    if (!empty($shmid)) {
        $awakeflag = shmop_read($shmid, 0, 1);
        shmop_close($shmid);
    } else {
        $awakeflag = 0;
    }
    
    $nowUTC   = strtotime(date('Ymd H:i'));
    $sun_info = date_sun_info((strtotime(date('Ymd'))), $LATITUDE, $LONGITUDE);
    
    if ($awakeflag == 0 && $nowUTC > ($sun_info['sunrise'] - 300) && $nowUTC < ($sun_info['sunset'])) { // Wake up
        $shmid = shmop_open(12310, 'c', 0666, 1);
        shmop_write($shmid, 1, 0);
        shmop_close($shmid);
        $awakeflag = 1;
        $pvoconsu  = false;
        
        for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) {
            $invtnum = $invt_num;
            include('read_invtcfg.php');
            if ($PVOC != 'no') {
                $pvoconsu = true;
            }
        }
        $minute = date('i');
        if ($pvoconsu && $minute == 5) { // Reset 5minflag to log
            for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) {
                $memid = '1233' . $invt_num;
                $shmid = shmop_open($memid, 'c', 0666, 1);
                shmop_write($shmid, 0, 0);
                shmop_close($shmid);
            }
        }
        
        if ($NUMSMA > 0) {
            $now = date($DATEFORMAT . ' H:i:s');
            sma_daemon_control('CHECK', $now, $DEBUG); // Wake up sma daemon
        }
    }
    
    if ($nowUTC > ($sun_info['sunset'] + 300) && $awakeflag == 1) { // Go to bed
        $shmid = shmop_open(12310, 'c', 0666, 1);
        shmop_write($shmid, 0, 0);
        shmop_close($shmid);
        $awakeflag = 0;
        
        for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) {
            $memid = '1236' . $invt_num; // Reset Invt State
            @$shmid = shmop_open($memid, 'a', 0444, 256);
            if (!empty($shmid)) {
                shmop_delete($shmid);
            }
            $shmid = shmop_open($memid, 'c', 0666, 256);
            shmop_write($shmid, '\n---', 0);
            shmop_close($shmid);
            
            $now        = date($DATEFORMAT . ' H:i:s');
            $DATADIR    = dirname($SCRDIR) . "/data/invt$invt_num";
            $stringData = "$now\t123Solar asleep\n\n";
            $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
            file_put_contents($DATADIR . '/infos/events.txt', $stringData);
        }
        if ($NUMSMA > 0) {
            $now = date($DATEFORMAT . ' H:i:s');
            sma_daemon_control('SHUTDOWN', $now); // sma daemon
        }
    }
    
    if ($nowUTC < ($sun_info['sunrise'] - 300) || $nowUTC > ($sun_info['sunset'] + 300)) { // Sleep
        $pvoconsu   = false;
        $SDTE       = date('Ymd-H:i:s');
        $stringData = "$SDTE,0,0,0,0,0,0,0,0,0,0,0,0,0,0"; // reset live values
        for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) {
            $memid = '1231' . $invt_num;
            @$shmid = shmop_open($memid, 'a', 0444, 256);
            if (!empty($shmid)) {
                shmop_delete($shmid);
            }
            $shmid = shmop_open($memid, 'c', 0666, 256);
            shmop_write($shmid, $stringData, 0);
            shmop_close($shmid);
            
            $invtnum = $invt_num;
            include('read_invtcfg.php');
            if ($PVOC != 'no') {
                $pvoconsu = true;
            }
        }
        if ($pvoconsu) {
            sleep(15); // Take a nap but continue to feed PVo
        } else {
            sleep(60); // Is he alive ? 
            die;
        }
    }
} else {
    $awakeflag = 1;
}

$GOPVO = 1; // Go to feed PVoutput

for ($invt_num = 1; $invt_num <= $NUMINV; $invt_num++) { //Multi inverters pooling
    $DATADIR = dirname($SCRDIR) . "/data/invt$invt_num";
    $invtnum = $invt_num;
    include('read_invtcfg.php');
    include("protocols/$PROTOCOL.php");
    $GP2m[$invt_num] = 0;
    
    if ($SKIPMONITORING != 1) {
        $now     = date($DATEFORMAT . ' H:i:s');
        $nowUTC  = strtotime(date('Ymd H:i'));
        $nowUTCs = strtotime(date('Ymd H:i:s'));
        $today   = date('Ymd');
        // Initialize variables
        $match   = '';
        $msg     = '';
        
        if ($RET == 'OK' && $FRQ > 0 && $awakeflag == 1) { // avoid null values at early startup
            $stringData = "$SDTE,$I1V,$I1A,$I1P,$I2V,$I2A,$I2P,$GV,$GA,$GP,$FRQ,$EFF,$INVT,$BOOT,$KWHT";
            $memid      = '1231' . $invt_num; // Live
            @$shmid = shmop_open($memid, 'a', 0444, 256);
            if (!empty($shmid)) {
                shmop_delete($shmid);
            }
            $shmid = shmop_open($memid, 'c', 0666, 256);
            shmop_write($shmid, $stringData, 0);
            shmop_close($shmid);
            
            $memid = '1232' . $invt_num; // Max instant power of the day
            @$shmid = shmop_open($memid, 'a', 0444, 32);
            if (!empty($shmid)) {
                $pmotd_data = shmop_read($shmid, 0, 32);
                shmop_close($shmid);
                $array = preg_split('/,/', $pmotd_data);
            } else {
                $array[1] = 0;
            }
            $array[1] = floatval($array[1]);
            $GP2      = round($GP * $CORRECTFACTOR, 1);
            if ($GP2 > $array[1]) {
                $stringData = "$nowUTC,$GP2";
                @$shmid = shmop_open($memid, 'a', 0444, 32);
                if (!empty($shmid)) {
                    shmop_delete($shmid);
                }
                $shmid = shmop_open($memid, 'c', 0666, 32);
                shmop_write($shmid, $stringData, 0);
                shmop_close($shmid);
            }
            
            if ($NUMINV > 1) { // Max instant power of the day on multi
                @$shmid = shmop_open(12320, 'a', 0444, 32);
                if (!empty($shmid)) {
                    $pmotd_data = shmop_read($shmid, 0, 32);
                    shmop_close($shmid);
                    $array = preg_split('/,/', $pmotd_data);
                } else {
                    $array[1] = 0;
                }
                $array[1]        = floatval($array[1]);
                $GP2m[$invt_num] = floatval($GP2);
                
                $GP2multi = array_sum($GP2m);
                if ($GP2multi > $array[1]) {
                    $stringData = "$nowUTC,$GP2multi";
                    @$shmid = shmop_open($memid, 'a', 0444, 32);
                    if (!empty($shmid)) {
                        shmop_delete($shmid);
                    }
                    $shmid = shmop_open(12320, 'c', 0666, 32);
                    shmop_write($shmid, $stringData, 0);
                    shmop_close($shmid);
                }
            }
        } // End of OK
        
        $minute  = date('i');
        $minlist = array(
            '00',
            '05',
            '10',
            '15',
            '20',
            '25',
            '30',
            '35',
            '40',
            '45',
            '50',
            '55'
        );
        
        $memid = '1233' . $invt_num; // 5 min flag
        @$shmid = shmop_open($memid, 'a', 0444, 1);
        if (!empty($shmid)) {
            $fiveflag = shmop_read($shmid, 0, 1);
            shmop_close($shmid);
        } else {
            $fiveflag = 0;
        }
        
        if (in_array($minute, $minlist) && $fiveflag != 1) { // 5 min jobs
            $shmid = shmop_open($memid, 'c', 0666, 1);
            shmop_write($shmid, 1, 0);
            shmop_close($shmid);
            $fiveflag = 1;
            
            if ($awakeflag == 1 && $RET == 'OK' && $FRQ > 0) {
                $PCnow      = date('H:i:s'); // PC time
                $stringData = "$PCnow,$I1V,$I1A,$I1P,$I2V,$I2A,$I2P,$GV,$GA,$GP,$FRQ,$EFF,$INVT,$BOOT,$KWHT\r\n";
                $myFile     = $DATADIR . "/csv/$today.csv";
                file_put_contents($myFile, $stringData, FILE_APPEND);
                $lines      = file($myFile);
                $contalines = count($lines);
                
                // Dawn startup 
                if ($contalines == 1) {
                    $file       = $DATADIR . "/csv/$today.csv";
                    $header     = "Time,I1V,I1A,I1P,I2V,I2A,I2P,GV,GA,GP,FRQ,EFF,INVT,BOOT,KWHT\r\n";
                    $old_lignes = file($DATADIR . "/csv/$today.csv");
                    array_unshift($old_lignes, $header);
                    $new_content = implode('', $old_lignes);
                    $fp          = fopen($file, 'w');
                    fwrite($fp, $new_content);
                    fclose($fp);
                    
                    $dir    = $DATADIR . '/csv/';
                    $output = array();
                    $output = glob($dir . '*.csv');
                    sort($output);
                    $xdays = count($output);
                    
                    if ($xdays > 1) {
                        $yesterdaylog  = $output[$xdays - 2]; // Yesterday production
                        $lines         = file($yesterdaylog);
                        $contalines    = count($lines);
                        $array         = preg_split('/,/', $lines[1]);
                        $prodyesterday = $array[14];
                        $array         = preg_split('/,/', $lines[$contalines - 1]);
                        $prodtoday     = $array[14];
                        settype($prodtoday, 'float');
                        settype($prodyesterday, 'float');
                        if ($prodtoday >= $prodyesterday) {
                            $production = round(($prodtoday - $prodyesterday), 3);
                        } else { // passed 100.000kWh
                            $production = round((($prodtoday + 100000) - $prodyesterday), 3);
                        }
                        $option     = $output[$xdays - 2];
                        $option     = str_replace($dir, '', $option);
                        $date1      = substr($option, 0, 8);
                        $year       = substr($option, 0, 4); // For new year
                        $stringData = "$date1,$production\r\n";
                        $myFile     = $DATADIR . '/production/energy' . $year . '.csv';
                        file_put_contents($myFile, $stringData, FILE_APPEND);
                        
                        if ($REPORT == 'daily') { // Reports
                            $year       = substr($date1, 0, 4);
                            $month      = substr($date1, 4, 2);
                            $day        = substr($date1, 6, 2);
                            $date1      = date($DATEFORMAT, mktime(0, 0, 0, $month, $day, $year));
                            $production = round($production * $CORRECTFACTOR, 2);
                            $kwhkc      = round(($production / ($PLANT_POWER / 1000)), 2);
                            $msg        = "$date1\t$production kWh ($kwhkc kWh/kWp)\r\n";
                            mail("$EMAIL", "123Solar: Inverter #$invt_num $date1 daily production report", $msg, "From: \"123Solar\" $EMAIL");
                        } elseif ($REPORT == 'monthly') {
                            $day1 = date('d');
                            if ($day1 == '01') {
                                $y_year     = date('Y', time() - 60 * 60 * 24); // yesterday
                                $y_month    = date('m', time() - 60 * 60 * 24);
                                $myFile     = file($DATADIR . "/production/energy$y_year.csv");
                                $contalines = count($myFile);
                                $i          = 0;
                                for ($line_num = 0; $line_num < $contalines; $line_num++) {
                                    $array = preg_split('/,/', $myFile[$line_num]);
                                    $month = substr($array[0], 4, 2);
                                    if ($month == $y_month) {
                                        $year         = substr($array[0], 0, 4);
                                        $month        = substr($array[0], 4, 2);
                                        $day          = substr($array[0], 6, 2);
                                        $dayname[$i]  = date($DATEFORMAT, mktime(0, 0, 0, $month, $day, $year));
                                        $prod_day[$i] = round($array[1], 1);
                                        $i++;
                                    }
                                }
                                $prod_month = round(array_sum($prod_day) * $CORRECTFACTOR, 1);
                                $cnt        = count($dayname);
                                for ($i = 0; $i < $cnt; $i++) {
                                    $prod_day[$i] = round($prod_day[$i] * $CORRECTFACTOR, 2);
                                    $kwhkc        = round(($prod_day[$i] / ($PLANT_POWER / 1000)), 2);
                                    $msg .= "$dayname[$i]\t$prod_day[$i] kWh ($kwhkc kWh/kWp)\r\n";
                                }
                                $kwhkc = round(($prod_month / ($PLANT_POWER / 1000)), 2);
                                $msg .= "\r\n---\r\n$prod_month kWh produced on $y_month $y_year ($kwhkc kWh/kWp)";
                                mail("$EMAIL", "123Solar: Inverter #$invt_num monthly $y_month production report", $msg, "From: \"123Solar\" $EMAIL");
                            }
                        }
                    }
                    
                    $stringData = "$nowUTC,0"; // Reset past pmotd
                    $memid      = '1232' . $invt_num;
                    @$shmid = shmop_open($memid, 'a', 0444, 32);
                    if (!empty($shmid)) {
                        shmop_delete($shmid);
                    }
                    $shmid = shmop_open($memid, 'c', 0666, 32);
                    shmop_write($shmid, $stringData, 0);
                    shmop_close($shmid);
                    
                    if ($NUMINV > 1) {
                        $stringData = "$nowUTC,0"; // Reset past multi pmotd
                        @$shmid = shmop_open(12320, 'a', 0444, 32);
                        if (!empty($shmid)) {
                            shmop_delete($shmid);
                        }
                        $shmid = shmop_open(12320, 'c', 0666, 32);
                        shmop_write($shmid, $stringData, 0);
                        shmop_close($shmid);
                    }
                    
                    $memid = '1234' . $invt_num; // Reset awmsg
                    @$shmid = shmop_open($memid, 'a', 0444, 64);
                    if (!empty($shmid)) {
                        shmop_delete($shmid);
                    }
                    $shmid      = shmop_open($memid, 'c', 0666, 64);
                    $stringData = '0,0,0,0,0';
                    shmop_write($shmid, $stringData, 0);
                    shmop_close($shmid);
                    
                    $stringData = "$now\t123Solar awake\n\n";
                    $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                    file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                    
                    if ($KEEPDDAYS != 0) { // Morning cleanup, purge detailed files
                        if ($xdays > $KEEPDDAYS) {
                            $i = 0;
                            while ($i < $xdays - $KEEPDDAYS) {
                                unlink($DATADIR . '/csv/' . $output[$i]);
                                $i++;
                            }
                            
                            $stringData = "$now\tPurging $i detailed csv file(s)\n\n";
                            $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                            file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                        }
                    } // Clean up logs
                    
                    if ($AMOUNTLOG != 0) {
                        $myFile = $DATADIR . '/infos/events.txt';
                        $file   = file($myFile);
                        $cnt    = count($file);
                        if ($cnt >= $AMOUNTLOG) {
                            array_splice($file, $AMOUNTLOG);
                        }
                        $file2      = fopen($myFile, 'w');
                        $new_lignes = "$now\tClean up events log\n\n";
                        fwrite($file2, $new_lignes);
                        fwrite($file2, implode('', $file));
                        fclose($file2);
                        
                        $myFile = $DATADIR . '/data/pvoutput_err.txt';
                        $file   = file($myFile);
                        $cnt    = count($file);
                        if ($cnt >= $AMOUNTLOG) {
                            array_splice($file, $AMOUNTLOG);
                        }
                        $file2 = fopen($myFile, 'w');
                        fwrite($file2, implode('', $file));
                        fclose($file2);
                    } // End of morning clean up 
                } // End of dawn startup
                
                if ($contalines == 14) { // Wait 60 min after startup to make sure the inverter is fully awake
                    include('protocols/' . $PROTOCOL . '_startup.php');
                    if (isset($CMD_INFO)) {
                        $info = shell_exec($CMD_INFO); // Info file
                    } else {
                        $info = 'No infos';
                    }
                    file_put_contents($DATADIR . '/infos/infos.txt', $info);
                    
                    if ($SYNC == 1 && isset($CMD_SYNC)) {
                        $info = shell_exec($CMD_SYNC); //Sync inverter time 
                        
                        $stringData = "$now\tSync. inverter time\n\n";
                        $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                        file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                    }
                }
            } // Awake
        } // End of 5 min jobs
        
        if (!in_array($minute, $minlist) && $fiveflag == 1) { // 1,6,11,16,..
            if ($invt_num == $GOPVO) {
                $GOPVO       = 0;
                // Initialize variables
                $SYSlist     = array();
                $APIKEYlist  = array();
                $KWHDtotlist = array();
                $GPtotlist   = array();
                $GVlist      = array();
                $INVTlist    = array();
                if ($NUMSMA > 0 && $awakeflag == 1) {
                    sma_daemon_control('CHECK', $now, $DEBUG); // Check sma daemon
                }
                $stringData = '';
                
                for ($i = 1; $i <= $NUMINV; $i++) { // PVoutput
                    $invtnum = $i;
                    include('read_invtcfg.php');
                    
                    if ($PVOUTPUT != 0) {
                        if ($awakeflag == 1) {
                            $dir    = dirname($SCRDIR) . "/data/invt$i/csv/";
                            $output = array();
                            $output = glob($dir . '*.csv');
                            sort($output);
                            $xdays      = count($output);
                            $option     = $output[$xdays - 1];
                            $lines      = file($option);
                            $option     = str_replace($dir, '', $option);
                            $array      = preg_split('/,/', $lines[1]);
                            $contalines = count($lines);
                            if ($contalines == 2) { // daily startup
                                $array2 = $array;
                            } else {
                                $array2 = preg_split('/,/', $lines[$contalines - 1]);
                            }
                            $year        = substr($option, 0, 4);
                            $month       = substr($option, 4, 2);
                            $day         = substr($option, 6, 2);
                            $hour        = substr($array2[0], 0, 2);
                            $minut       = substr($array2[0], 3, 2);
                            $seconde     = substr($array2[0], 6, 2);
                            $UTCfiledate = strtotime($year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minut . ':' . $seconde);
                            
                            if ("$year" . "$month" . "$day" == date('Ymd')) { // Today's file
                                if ($nowUTC - $UTCfiledate < 300) {
                                    $KWHT_strt = $array[14];
                                    $KWHT_stop = $array2[14];
                                    $KWHD      = round((($KWHT_stop - $KWHT_strt) * 1000 * $CORRECTFACTOR), 0); //Wh
                                    $GP        = round($array2[9], 0);
                                    $GV        = round($array2[7], 0);
                                    $INVT      = round($array2[12], 0);
                                } else { // too old
                                    $KWHT_strt = $array[14];
                                    $KWHT_stop = $array2[14];
                                    $KWHD      = round((($KWHT_stop - $KWHT_strt) * 1000 * $CORRECTFACTOR), 0); //Wh
                                    $GP        = 0;
                                    $GV        = 0;
                                    $INVT      = 0;
                                }
                            } else {
                                $KWHD = 0;
                                $GP   = 0;
                                $GV   = 0;
                                $INVT = 0;
                            }
                        } else {
                            $KWHD = 0;
                            $GP   = 0;
                            $GV   = 0;
                            $INVT = 0;
                        }
                        settype($SYSID, 'integer');
                        if (!in_array($SYSID, $SYSlist)) {
                            array_push($SYSlist, $SYSID);
                        }
                        $PVOC = trim($PVOC);
                        if ($PVOC != 'no' && !isset($consumed_whdlist[$SYSID])) { // Consumption
                            include("pvoconsumption/$PVOC.php");
                            $consumed_wlist[$SYSID]   = $CONSUMED_W;
                            $consumed_whdlist[$SYSID] = $CONSUMED_WHD;
                        }
                        
                        $APIKEYlist[$SYSID] = $APIKEY;
                        if (!isset($KWHDtot[$SYSID])) {
                            $KWHDtot[$SYSID] = 0;
                        }
                        if (!isset($GPtot[$SYSID])) {
                            $GPtot[$SYSID] = 0;
                        }
                        $KWHDtot[$SYSID] += $KWHD;
                        $GPtot[$SYSID] += $GP;
                        if (!isset($GVlist[$SYSID])) {
                            
                            $GVlist[$SYSID] = 0;
                        }
                        if ($GV > $GVlist[$SYSID]) { // highest Volt
                            $GVlist[$SYSID] = $GV;
                        }
                        if (!isset($INVTlist[$SYSID])) {
                            $INVTlist[$SYSID] = 0;
                        }
                        if ($INVT > $INVTlist[$SYSID]) { // highest temp
                            $INVTlist[$SYSID] = $INVT;
                        }
                        if ($DEBUG == 1) {
                            $stringData .= "#invt$i ($SYSID) $KWHD Wh $GP W $GVlist[$SYSID] V $INVTlist[$SYSID] C\n";
                        }
                    }
                }
                if ($DEBUG == 1) {
                    $myFile = dirname($SCRDIR) . '/data/pvoutput_return.txt';
                    file_put_contents($myFile, $stringData);
                }
                
                $SYScount   = count($SYSlist);
                $stringData = '';
                
                $today2 = date('Ymd');
                $time   = date('H:i', mktime(date('H'), date('i') - 1, 0, date('m'), date('d'), date('Y')));
                for ($i = 0; $i < $SYScount; $i++) { // Sending to PVo
                    $sysnum = $SYSlist[$i];
                    
                    if (!isset($consumed_whdlist[$sysnum])) {
                        $pvoutput = shell_exec('curl -d "d=' . $today2 . '" -d "t=' . $time . '" -d "c1=0" -d "v1=' . $KWHDtot[$sysnum] . '" -d "v2=' . $GPtot[$sysnum] . '" -d "v5=' . $INVTlist[$sysnum] . '" -d "v6=' . $GVlist[$sysnum] . '" -H "X-Pvoutput-Apikey: ' . $APIKEYlist[$sysnum] . '" -H "X-Pvoutput-SystemId: ' . $sysnum . '" http://pvoutput.org/service/r2/addstatus.jsp &');
                    } else { // with consumption
                        if ($awakeflag == 1 && $GVlist[$sysnum] != 0) {
                            $pvoutput = shell_exec('curl -d "d=' . $today2 . '" -d "t=' . $time . '" -d "c1=0" -d "v1=' . $KWHDtot[$sysnum] . '" -d "v2=' . $GPtot[$sysnum] . '" -d "v3=' . $consumed_whdlist[$sysnum] . '" -d "v4=' . $consumed_wlist[$sysnum] . '" -d "v5=' . $INVTlist[$sysnum] . '" -d "v6=' . $GVlist[$sysnum] . '" -H "X-Pvoutput-Apikey: ' . $APIKEYlist[$sysnum] . '" -H "X-Pvoutput-SystemId: ' . $sysnum . '" http://pvoutput.org/service/r2/addstatus.jsp &');
                        } else { // Inverter asleep or dozes
                            $pvoutput = shell_exec('curl -d "d=' . $today2 . '" -d "t=' . $time . '" -d "v3=' . $consumed_whdlist[$sysnum] . '" -d "v4=' . $consumed_wlist[$sysnum] . '" -H "X-Pvoutput-Apikey: ' . $APIKEYlist[$sysnum] . '" -H "X-Pvoutput-SystemId: ' . $sysnum . '" http://pvoutput.org/service/r2/addstatus.jsp &');
                        }
                    }
                    if ($DEBUG == 1) {
                        $stringData .= "\nSend for SYSID $sysnum : $today2 $time- $KWHDtot[$sysnum] Wh $GPtot[$sysnum] W $GVlist[$sysnum] V $INVTlist[$sysnum] C";
                        if (isset($consumed_whdlist[$sysnum])) {
                            $stringData .= "\nDaily consumption $consumed_whdlist[$sysnum] Wh Consumption power $consumed_wlist[$sysnum] W";
                        }
                        $stringData .= "\nPVoutput returned: $pvoutput";
                        file_put_contents($myFile, $stringData, FILE_APPEND);
                    }
                    if ($pvoutput != 'OK 200: Added Status') {
                        $myFile  = dirname($SCRDIR) . '/data/pvoutput_err.txt';
                        $current = "$now $pvoutput\n";
                        file_put_contents($myFile, $current, FILE_APPEND);
                    }
                }
            } // End of once PVoutput feed
            
            $shmid = shmop_open($memid, 'c', 0666, 1); // Reset 5minflag
            shmop_write($shmid, 0, 0);
            shmop_close($shmid);
        } // 1,6,11,..
        
        if ($awakeflag == 1) { // If awake
            $invtnum = $invt_num;
            include('read_invtcfg.php');
            if (($RET != 'OK' && !empty($datareturn) && $AUTOMODE == 0) || ($RET != 'OK' && !empty($datareturn) && $AUTOMODE == 1 && ($nowUTCs > ($sun_info['sunrise'] + 1800) && $nowUTCs < ($sun_info['sunset'] - 1800)))) { //NOK
                if ($LOGCOM == 1) {
                    $stringData = "$now\tCommunication error\n\n";
                    $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                    file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                }
                if ($DEBUG == 1) {
                    // Comm test errors logs
                    $time = date('Ymd-H:i:s');
                    file_put_contents($DATADIR . "/errors/de$time.dat", $datareturn);
                    $datareturn = shell_exec('cp ' . $DATADIR . '/errors/de.err ' . $DATADIR . '/errors/de' . $time . '.err');
                }
            } // End of NOK
            
            $memid = '1234' . $invt_num; // Alarms, warnings and peak
            @$shmid = shmop_open($memid, 'a', 0444, 64);
            if (!empty($shmid)) {
                $awmsg = shmop_read($shmid, 0, 64);
                shmop_close($shmid);
            } else {
                $awmsg = '0,0,0,0,0'; // AWdate,ileak,riso,peakp,peakotd
            }
            $awarray = preg_split('/,/', $awmsg);
            
            if ((($nowUTC - $awarray[0]) >= ($AWPOOLING * 60)) && $SKIPMONITORING != 1) { // Checks pooling
                
                include('protocols/' . $PROTOCOL . '_checks.php');
                if ($RET == 'OK') {
                    if (($RISO <= $RISOT && $RISO > 0)) { // Riso
                        $RISO       = round($RISO, 1);
                        $stringData = "$now\tRiso warning $RISO Mohm\n\n";
                        $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                        file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                        
                        if ($RISOTM == 1) {
                            $msg = "$now\r\nRiso: $RISO Mohm (Below threshold $RISOT Mohm)\r\n---\r\n";
                            if ($DIGESTMAIL > 0) {
                                file_put_contents($DATADIR . '/mailqueue/' . $nowUTC . 'R.txt', $msg);
                            } else {
                                mail("$EMAIL", "123Solar: Inverter #$invt_num RISO warning", $msg, "From: \"123Solar\" $EMAIL");
                                if ($PUSHO == 1) {
                                    $pushover = shell_exec('curl -s -F "title=Inverter #' . $invt_num . ' RISO warning" -F "token=soh71JI4Eln1eecvyV8G87NrRiLwxS" -F "user=' . $POUKEY . '" -F "message=' . $msg . '" https://api.pushover.net/1/messages.json &');
                                }
                            }
                        }
                    }
                    
                    if ($ILEAK >= $ILEAKT && $ILEAK > 0) { // iLeak
                        $stringData = "$now\tiLeak warning $ILEAK mA\n\n";
                        $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                        file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                        if ($ILEAKTM == 1) {
                            $msg = "$now\r\niLeak: $ILEAK mA (Exceeded threshold $ILEAKT mA)\r\n---\r\n";
                            if ($DIGESTMAIL > 0) {
                                file_put_contents($DATADIR . '/mailqueue/' . $nowUTC . 'I.txt', $msg);
                            } else {
                                mail("$EMAIL", "123Solar: Inverter #$invt_num iLeak warning", $msg, "From: \"123Solar\" $EMAIL");
                                if ($PUSHO == 1) {
                                    $pushover = shell_exec('curl -s -F "title=Inverter #' . $invt_num . ' iLeak warning" -F "token=soh71JI4Eln1eecvyV8G87NrRiLwxS" -F "user=' . $POUKEY . '" -F "message=' . $msg . '" https://api.pushover.net/1/messages.json &');
                                }
                            }
                        }
                    }
                }
                $memid = '1234' . $invt_num; // iLeak, riso and Peak power
                if (!isset($ILEAK)) {
                    $ILEAK = 0;
                }
                if (!isset($RISO)) {
                    $RISO = 0;
                }
                if (!isset($PPEAK)) {
                    $PPEAK = 0;
                }
                if (!isset($PPEAKOTD)) {
                    $PPEAKOTD = 0;
                }
                @$shmid = shmop_open($memid, 'a', 0444, 64);
                if (!empty($shmid)) {
                    shmop_delete($shmid);
                }
                $stringData = "$nowUTC,$ILEAK,$RISO,$PPEAK,$PPEAKOTD";
                $shmid      = shmop_open($memid, 'c', 0666, 64);
                shmop_write($shmid, $stringData, 0);
                shmop_close($shmid);
                
                if (isset($CMD_STATE)) {
                    $state = shell_exec($CMD_STATE); // Inverter state
                } else {
                    $state = '';
                }
                $memid = '1236' . $invt_num;
                @$shmid = shmop_open($memid, 'a', 0444, 256);
                if (!empty($shmid)) {
                    shmop_delete($shmid);
                }
                $shmid = shmop_open($memid, 'c', 0666, 256);
                shmop_write($shmid, $state, 0);
                shmop_close($shmid);
                
                if (isset($CMD_ALARM)) {
                    $alarm = shell_exec($CMD_ALARM); // Alarms
                } else {
                    $alarm = '';
                }
                
                // Log alarms in events
                if ($PROTOCOL == 'aurora') {
                    if (strstr($alarm, 'E0') || strstr($alarm, 'W0')) {
                        $stringData = "$now $alarm";
                        $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                        file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                    }
                } elseif ($PROTOCOL == 'sma_get') {
                    if (!strstr($alarm, '-------') && !empty($alarm)) {
                        $stringData = "$now $alarm";
                        $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                        file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                    }
                } else {
                    if (!empty($alarm)) {
                        $stringData = "$now $alarm";
                        $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                        file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                    }
                }
                
                $FILTER = preg_split('/,/', $FILTER);
                $match  = trim($alarm);
                foreach ($FILTER as $word) { // Email filter
                    $match = str_replace($word, '', $match);
                }
                
                if ($PROTOCOL == 'aurora' && $SENDALARMS == 1 && strstr($match, 'E0')) {
                    $msg = "$now $alarm---\r\n";
                    if ($DIGESTMAIL > 0) {
                        file_put_contents($DATADIR . '/mailqueue/' . $nowUTC . 'A.txt', $msg);
                    } else {
                        mail("$EMAIL", "123Solar: Inverter #$invt_num ERROR", $msg, "From: \"123Solar\" $EMAIL", "From: \"123Solar\" $EMAIL");
                        if ($PUSHO == 1) {
                            $pushover = shell_exec('curl -s -F "title=Inverter #' . $invt_num . ' ERROR" -F "token=soh71JI4Eln1eecvyV8G87NrRiLwxS" -F "user=' . $POUKEY . '" -F "message=' . $msg . '" https://api.pushover.net/1/messages.json &');
                        }
                    }
                }
                
                if ($PROTOCOL == 'aurora' && $SENDMSGS == 1 && strstr($match, 'W0')) {
                    $msg = "$now $alarm---\r\n";
                    if ($DIGESTMAIL > 0) {
                        file_put_contents($DATADIR . '/mailqueue/' . $nowUTC . 'M.txt', $msg);
                    } else {
                        mail("$EMAIL", "123Solar: Inverter #$invt_num message", $msg, "From: \"123Solar\" $EMAIL");
                        if ($PUSHO == 1) {
                            $pushover = shell_exec('curl -s -F "title=Inverter #' . $invt_num . ' message" -F "token=soh71JI4Eln1eecvyV8G87NrRiLwxS" -F "user=' . $POUKEY . '" -F "message=' . $msg . '" https://api.pushover.net/1/messages.json &');
                        }
                    }
                }
                
                if ($PROTOCOL == 'sma_get' && !empty($match) && ($SENDMSGS == 1 || $SENDALARMS == 1) && !strstr($match, '-------')) { // SMA
                    $msg = "$now $alarm\r\n---";
                    if ($DIGESTMAIL > 0) {
                        file_put_contents($DATADIR . '/mailqueue/' . $nowUTC . 'SMA.txt', $msg);
                    } else {
                        mail("$EMAIL", "123Solar: Inverter #$invt_num message", $msg, "From: \"123Solar\" $EMAIL");
                        if ($PUSHO == 1) {
                            $pushover = shell_exec('curl -s -F "title=Inverter #' . $invt_num . ' message" -F "token=soh71JI4Eln1eecvyV8G87NrRiLwxS" -F "user=' . $POUKEY . '" -F "message=' . $msg . '" https://api.pushover.net/1/messages.json &');
                        }
                    }
                }
                
                if ($PROTOCOL != 'sma_get' && $PROTOCOL != 'aurora' && !empty($match) && ($SENDMSGS == 1 || $SENDALARMS == 1)) { // Other inverters
                    $msg = "$now $alarm\r\n---";
                    if ($DIGESTMAIL > 0) {
                        file_put_contents($DATADIR . '/mailqueue/' . $nowUTC . 'other.txt', $msg);
                    } else {
                        mail("$EMAIL", "123Solar: Inverter #$invt_num message", $msg, "From: \"123Solar\" $EMAIL");
                        if ($PUSHO == 1) {
                            $pushover = shell_exec('curl -s -F "title=Inverter #' . $invt_num . ' message" -F "token=soh71JI4Eln1eecvyV8G87NrRiLwxS" -F "user=' . $POUKEY . '" -F "message=' . $msg . '" https://api.pushover.net/1/messages.json &');
                        }
                    }
                }
                
                if (isset($GV)) {
                    if ((($GV > $VGRIDT) || ($GV < $VGRIDUT)) && $GV != 0) { // Avoid 0 values at early wake up
                        $GV = round($GV, 2);
                        if ($GV >= $VGRIDT) {
                            $msg        = "$now\r\nVGrid: $GV V (Exceeded threshold $VGRIDT V)\r\n---\r\n";
                            $stringData = "$now\tVGrid high warning $GV V\n\n";
                        } else {
                            $msg        = "$now\r\nVGrid: $GV V (Below threshold $VGRIDUT V)\r\n---\r\n";
                            $stringData = "$now\tVGrid low warning $GV V\n\n";
                        }
                        $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                        file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                        
                        if ($VGRIDTM == 1) {
                            if ($DIGESTMAIL > 0) {
                                file_put_contents($DATADIR . '/mailqueue/' . $nowUTC . 'GV.txt', $msg);
                            } else {
                                mail("$EMAIL", "123Solar: Inverter #$invt_num VGRID warning", $msg, "From: \"123Solar\" $EMAIL");
                                if ($PUSHO == 1) {
                                    $pushover = shell_exec('curl -s -F "title=Inverter #' . $invt_num . ' VGRID warning" -F "token=soh71JI4Eln1eecvyV8G87NrRiLwxS" -F "user=' . $POUKEY . '" -F "message=' . $msg . '" https://api.pushover.net/1/messages.json &');
                                }
                            }
                        }
                    }
                }
                
                if ($AUTOMODE == 1 && $awakeflag == 1) { // Lost of connection
                    $memid = '1231' . $invt_num; // Live
                    @$shmid = shmop_open($memid, 'a', 0444, 256);
                    if (!empty($shmid)) {
                        $stringData = shmop_read($shmid, 0, 256);
                        shmop_close($shmid);
                    } else {
                        $SDTE       = date('Ymd-H:i:s');
                        $stringData = "$SDTE,0,0,0,0,0,0,0,0,0,0,0,0,0,0";
                    }
                    
                    $array         = preg_split('/,/', $stringData);
                    $year          = substr($array[0], 0, 4);
                    $month         = substr($array[0], 4, 2);
                    $day           = substr($array[0], 6, 2);
                    $hour          = substr($array[0], 9, 2);
                    $minute        = substr($array[0], 12, 2);
                    $seconde       = substr($array[0], 15, 2);
                    $lastsampleUTC = strtotime($year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute . ':' . $seconde);
                    
                    if ($nowUTCs > ($sun_info['sunrise'] + 1800) && $nowUTCs < ($sun_info['sunset'] - 1800)) {
                        if ($nowUTCs - $lastsampleUTC > 90) {
                            $stringData = "$now\tConnection lost\n\n";
                            $stringData .= file_get_contents($DATADIR . '/infos/events.txt');
                            file_put_contents($DATADIR . '/infos/events.txt', $stringData);
                            
                            if ($NORESPM == 1) {
                                $msg = "$now\r\nConnection lost with inverter #$invt_num\r\n---\r\n";
                                if ($DIGESTMAIL > 0) {
                                    file_put_contents($DATADIR . '/mailqueue/' . $nowUTC . 'L.txt', $msg);
                                } else {
                                    mail("$EMAIL", "123Solar: Inverter #$invt_num Connection lost", $msg, "From: \"123Solar\" $EMAIL");
                                    if ($PUSHO == 1) {
                                        $pushover = shell_exec('curl -s -F "title=Inverter #' . $invt_num . ' Connection lost" -F "token=soh71JI4Eln1eecvyV8G87NrRiLwxS" -F "user=' . $POUKEY . '" -F "message=' . $msg . '" https://api.pushover.net/1/messages.json &');
                                    }
                                }
                            }
                        }
                    }
                    
                }
                
            } // Alarms pooling
            
            $memid = '1235' . $invt_num; // MailQ date
            @$shmid = shmop_open($memid, 'a', 0444, 16);
            if (!empty($shmid)) {
                $mqdate = shmop_read($shmid, 0, 16);
                shmop_close($shmid);
            } else {
                $mqdate = 0;
            }
            
            if ($DIGESTMAIL > 0 && ((($nowUTC - $mqdate) >= ($DIGESTMAIL * 60)) || ($nowUTC > ($sun_info['sunset']) && $AUTOMODE == 1)) && ($SENDALARMS == 1 || $SENDMSGS == 1 || $VGRIDTM == 1 || $RISOTM == 1 || $ILEAKTM == 1 || $NORESPM == 1)) { // Checking mail queue and sending last msgs before going to bed
                $dir    = $DATADIR . '/mailqueue/';
                $output = array();
                $output = glob($dir . '*.txt');
                
                if (!empty($output[0])) {
                    sort($output);
                    $cnt = count($output);
                    
                    if ($cnt > 0) {
                        // Will send the first alarm as it arrive, the following will be digested
                        $memid = '1235' . $invt_num;
                        $shmid = shmop_open($memid, 'c', 0666, 16);
                        shmop_write($shmid, $nowUTC, 0);
                        shmop_close($shmid);
                        
                        $contents = '';
                        $msg      = '';
                        
                        for ($i = 0; $i < $cnt; $i++) {
                            
                            $filename = $output[$i];
                            $handle   = fopen($filename, 'r');
                            $contents = fread($handle, filesize($filename));
                            $msg      = $contents . $msg;
                            fclose($handle);
                        }
                        $i = 0;
                        while ($i < $cnt) {
                            unlink($output[$i]);
                            $i++;
                        }
                        mail("$EMAIL", "123Solar: Inverter #$invt_num Alarms Warnings digest", $msg, "From: \"123Solar\" $EMAIL");
                        if ($PUSHO == 1) {
                            if (strlen($msg) > 485) { // Limited to 512 characters, including title
                                $msg = substr($msg, 0, 482);
                                $msg = $msg . '...';
                            }
                            $pushover = shell_exec('curl -s -F "title=Inv#' . $invt_num . ' Alarms Warnings digest" -F "token=soh71JI4Eln1eecvyV8G87NrRiLwxS" -F "user=' . $POUKEY . '" -F "message=' . $msg . '" https://api.pushover.net/1/messages.json &');
                        }
                    }
                }
            } // Checking mail queue
        } // If awake  
    } else { // Skiping monitoring
        $GOPVO++;
        $SDTE       = date('Ymd-H:i:s');
        $memid      = '1231' . $invt_num;
        $stringData = "$SDTE,0,0,0,0,0,0,0,0,0,0,0,0,0,0"; // reset live values
        @$shmid = shmop_open($memid, 'a', 0444, 256);
        if (!empty($shmid)) {
            shmop_delete($shmid);
        }
        $shmid = shmop_open($memid, 'c', 0666, 256);
        shmop_write($shmid, $stringData, 0);
        shmop_close($shmid);
    }
} // Multi inverters pooling
?>
