<?php
// For meterN Electrical household meter 
// You'll need to setup the following variables :
$meterndir = '/srv/http/metern/'; // meterN csv data path
$metnum    = 1; // meterN household meter number

//////
//include("$meterndir" . '/scripts/read_maincfg.php');
include('read_maincfg.php');
date_default_timezone_set($DTZ);
include("$meterndir" . '/scripts/read_metcfg.php');
$dir    = "$meterndir" . 'data/csv/';
$output = scandir($dir);
$output = glob($dir . '*.csv');
sort($output);
$xdays = count($output);

if ($xdays > 0) {
    $lines       = file($output[$xdays - 1]);
    $first_array = preg_split('/,/', $lines[1]);
    $contalines  = count($lines);
    
    if ($contalines > 2) { // daily file
        $last_array = preg_split('/,/', $lines[$contalines - 1]);
        $prev_array = preg_split('/,/', $lines[$contalines - 2]);
    } elseif ($contalines == 2 && $xdays > 1) { // yesterd file
        $lines2      = file($output[$xdays - 2]);
        $contalines2 = count($lines2);
        $last_array  = preg_split('/,/', $lines2[$contalines2 - 1]);
        $prev_array  = preg_split('/,/', $lines2[$contalines2 - 2]);
    } else {
        $last_array = $first_array;
        $prev_array = $first_array;
    }
    $val_first    = trim($first_array[$metnum]);
    $val_last = trim($last_array[$metnum]);
    
    $year  = substr($output[$xdays - 1], -12, 4);
    $month = substr($output[$xdays - 1], -8, 2);
    $day   = substr($output[$xdays - 1], -6, 2);
    $today       = date('Ymd');

if ($today=="$year$month$day") {
    settype($val_first, 'int');
    settype($val_last, 'int');
    if ($val_last < $val_first && $PASSO > 0) { // counter pass over
        $val_last += $PASSO;
    }
    $CONSUMED_WHD = $val_last-$val_first; // Daily energy Consumption
}else {
   $CONSUMED_WHD=0;
}

    $hour       = substr($last_array[0], 0, 2);
    $minute     = substr($last_array[0], 3, 2);
    $prevhour   = substr($prev_array[0], 0, 2);
    $prevminute = substr($prev_array[0], 3, 2);
    $UTCdate     = strtotime($year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute);
    $diffUTCdate = strtotime($year . '-' . $month . '-' . $day . ' ' . $prevhour . ':' . $prevminute);
    $diffTime    = $UTCdate - $diffUTCdate;
    
    if ($diffTime >= 300) {
        settype($first_array[$metnum], 'int');
        settype($last_array[$metnum], 'int');
        if ($last_array[$metnum] < $prev_array[$metnum] && $PASSO > 0) { // counter just pass over
            $last_array[$metnum] += $PASSO;
        }
        $CONSUMED_W = round((($last_array[$metnum] - $prev_array[$metnum]) * 3600) / $diffTime, 0); // Avg Power Consumption
    } else {
        $CONSUMED_W = 0;
    }
    
} else {
    $CONSUMED_WHD = 0;
    $CONSUMED_W   = 0;
}

//$now= date('Ymd H:i');
//echo "$now Daily energy : $CONSUMED_WHD Avg. power : $CONSUMED_W\n";
?>
