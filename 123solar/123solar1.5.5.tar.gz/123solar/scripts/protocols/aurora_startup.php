<?php
// Info text file on daily start-up
$CMD_INFO = "aurora -a $ADR $COMOPTION -p -n -f -g -m -v $PORT";
// Sync command on daily start-up
$CMD_SYNC ="aurora -a $ADR $COMOPTION -L5 $PORT"; //if drift >5sec from computer
?>