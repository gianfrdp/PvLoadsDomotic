<?php
// rklogger is a command line program for reading the parameters out of Danfoss inverters.
// http://www.petig.eu/rklogger/

$ILEAK = 0;
$RISO = 0;
$PPEAK = 0
$PPEAKOTD = 0;
$RET = 'NOK'; // No output

// Info file
// unset no info $CMD_INFO = "";

// Alarm
// unset no alarm $CMD_ALARM = "";

?>
