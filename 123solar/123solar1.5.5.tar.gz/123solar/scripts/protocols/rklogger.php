<?php
// rklogger is a command line program for reading the parameters out of Danfoss inverters.
// http://www.petig.eu/rklogger/
// With the help of Gino Rosi

$I1V = shell_exec("rklogger 11 1 2 28 8"); 
settype($I1V, 'float');
$I1V /= 10;

$I1A = shell_exec("rklogger 11 1 2 2d 8");
settype($I1A, 'float');
$I1A /= 1000;

$I1P = shell_exec("rklogger 11 1 2 32 8");
settype($I1P, 'float');

$I2V = shell_exec("rklogger 11 1 2 29 8");
settype($I2V, 'float');
$I2V /= 10;

$I2A = shell_exec("rklogger 11 1 2 2e 8");
settype($I2A, 'float');
$I2A /= 1000;

$I2P = shell_exec("rklogger 11 1 2 33 8");
settype($I2P, 'float');

$a = shell_exec("rklogger 11 1 2 3c 8");
$b = shell_exec("rklogger 11 1 2 3d 8");
$c = shell_exec("rklogger 11 1 2 3e 8");
settype($GV, 'float');
$GV = ($a+$b+$c)/30;

$a = shell_exec("rklogger 11 1 2 3f 8");
$b = shell_exec("rklogger 11 1 2 40 8");
$c = shell_exec("rklogger 11 1 2 41 8");
settype($GA, 'float');
$GA = ($a+$b+$c)/3000;

$GP = shell_exec("rklogger 11 1 2 46 8");
settype($GP, 'float');

$FRQ = shell_exec("rklogger 11 1 2 50 8");
settype($FRQ, 'float');
$FRQ /= 1000;

$EFF = ($GP/($I1P+$I2P));
settype($EFF, 'float');

$INVT = shell_exec("rklogger 11 1 2 3 8");
settype($INVT, 'float');

$BOOT = shell_exec("rklogger 11 1 2 4 8");
settype($BOOT, 'float');

$KWHT = shell_exec("rklogger 11 1 2 4a 8");
settype($KWHT, 'float');

$RET = 'OK';

?>
