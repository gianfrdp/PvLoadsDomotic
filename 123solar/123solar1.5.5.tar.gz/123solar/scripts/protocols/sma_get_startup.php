<?php
// Info file
$CMD_INFO = "sma_get -i -n $ADR";
// Sync
// unset no sync for sma $CMD_SYNC ="";
?>