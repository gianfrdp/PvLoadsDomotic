<?php
// For Aurora http://www.curtronics.com/Solar
// Riso iLeak test & Peak Powers 
  
$CMD_RISOLEAK = "aurora -a $ADR -D -c $COMOPTION $PORT";

$i=0;
$RET = 'NOK';

while ($i <= 3 && $RET!='OK' ) { // Try 3 times
$datareturn = shell_exec($CMD_RISOLEAK);
$alarmarray = preg_split('/[[:space:]]+/', $datareturn);
  	if(!isset($alarmarray[32])) {
	$alarmarray[32]='NOK';
	}  
	if ($alarmarray[32]=='OK') {
	  settype($alarmarray[7], 'float');
	  $ILEAK = round(($alarmarray[7] * 1000), 1); // ileak in mA
	  settype($alarmarray[8], 'float');
	  $RISO = round($alarmarray[8], 2); // riso in Mohm
	  settype($alarmarray[13], 'float');
	  $PPEAK = round($alarmarray[13], 1); // peak power of all time
	  settype($alarmarray[14], 'float');
	  $PPEAKOTD = round($alarmarray[14], 1); // peak power of the day
	  $RET = 'OK';
	} 
$i++;	
}

// State text file
$CMD_STATE = "aurora -a $ADR $COMOPTION -s $PORT";
// Alarm
$CMD_ALARM = "aurora -a $ADR $COMOPTION -A $PORT";
?>
