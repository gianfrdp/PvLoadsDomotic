<?php
// For SMAspot http://code.google.com/p/sma-spot/
// Use $COMOPTION for SMAspot CSV command switches (-ad# -am# -nocsv etc)

// Timeout setup : for SMAspot timeout management by 123Solar
// ( relies on timeout command )
$timeout_setup = "timeout --kill-after=10s 5s"; // TERM after 5" & KILL after 10"

$cfgdir = dirname($SCRDIR) . "/config";

if ($DEBUG != 1) {
$CMD_POOLING = $timeout_setup." SMAspot -finq -q -123s=DATA -cfg".$cfgdir."/SMAspot_$ADR.cfg $COMOPTION";
} else {
$CMD_POOLING = $timeout_setup." SMAspot -finq -d5 -v5 -123s=DATA -cfg".$cfgdir."/SMAspot_$ADR.cfg $COMOPTION"; // Pooling with errors output ?
}

$datareturn = shell_exec($CMD_POOLING);
$array = preg_split('/[[:space:]]+/', $datareturn);
if (isset($array[24])) {                // SMAspot might send trames shorter than 24
  if ($array[24]=='>>>S123:OK') {
            $SDTE = $array[0];
            $G1V  = $array[1];          // GridMs.PhV.phsA
            settype($G1V, 'float');
            $G1A  = $array[2];          // GridMs.A.phsA
            settype($G1A, 'float');
            $G1P  = $array[3];          // GridMs.W.phsA
            settype($G1P, 'float');
            $G2V  = $array[4];          // GridMs.PhV.phsB
            settype($G2V, 'float');
            $G2A  = $array[5];          // GridMs.A.phsB
            settype($G2A, 'float');
            $G2P  = $array[6];          // GridMs.W.phsB
            settype($G2P, 'float');
            $G3V  = $array[7];          // GridMs.PhV.phsC
            settype($G3V, 'float');
            $G3A  = $array[8];          // GridMs.A.phsC
            settype($G3A, 'float');
            $G3P  = $array[9];          // GridMs.W.phsC
            settype($G3P, 'float');
            $FRQ = $array[10];          // GridMs.Hz
            settype($FRQ, 'float');
            $EFF = $array[11];          // Value computed by SMAspot
            settype($EFF, 'float');
            $INVT = $array[12];         // Inverter temperature - n/a for SMA inverters
            settype($INVT, 'float');
            $BOOT = $array[13];         // Booster temperature - n/a for SMA inverters
            settype($BOOT, 'float');
            $KWHT = $array[14];         // Metering.TotWhOut (kWh)
            settype($KWHT, 'float');
            $I1V = $array[15];          // DcMs.Vol[A]
            settype($I1V, 'float');
            $I1A = $array[16];          // DcMs.Amp[A]
            settype($I1A, 'float');
            $I1P = $array[17];          // DcMs.Watt[A]
            settype($I1P, 'float');
            $I2V = $array[18];          // DcMs.Vol[B]
            settype($I2V, 'float');
            $I2A = $array[19];          // DcMs.Amp[B]
            settype($I2A, 'float');
            $I2P = $array[20];          // DcMs.Watt[B]
            settype($I2P, 'float');
            $GV = $array[21];            // Was grid voltage in monophase 123Solar ( = Max Vac1, Vac2, Vac3 )
            settype($GV, 'float');
            $GA = $array[22];            // Was grid current in monophase 123Solar ( = Iac1 + Iac2 + Iac3 )
            settype($GA, 'float');
            $GP = $array[23];            // Was grid power in monophase 123Solar ( = Pac1 + Pac2 + Pac3 )
            settype($GP, 'float');
            $RET = 'OK';

  } else {
    $RET = '';
  }

} else {
  $RET = '';
}
?>
