<?php
// For SMAspot http://code.google.com/p/sma-spot/
// Use $COMOPTION for SMAspot CSV command switches (-ad# -am# -nocsv etc)

// Timeout setup : for SMAspot timeout management by 123Solar
// ( relies on timeout command )
$timeout_setup = "timeout --kill-after=10s 5s"; // TERM after 5" & KILL after 10"

$cfgdir = dirname($SCRDIR) . "/config";

// State
$CMD_STATE = $timeout_setup." SMAspot -finq -q -123s=STATE -cfg".$cfgdir."/SMAspot_$ADR.cfg $COMOPTION";

// Alarms
// Functionality is not implemented in SMAspot yet
$CMD_ALARM = "";

// Riso, iLeak - Peak Powers
// Functionality is not implemented in SMAspot yet
$CMD_RISOLEAK = "";
$RISO = 0;
$ILEAK = 0;

?>
