<?php
// /!\ Be careful, uncomment only to debug !
include("read_maincfg.php"); //Load main constants

echo "Shared memory Usage: ";
echo memory_get_usage();
echo "bytes - ";
echo convert(memory_get_usage(true));
echo "<br>";

@$shmid = shmop_open(12310, "a", 0444, 1);
if (!empty($shmid)) {
$data = shmop_read($shmid, 0, 1);
shmop_close($shmid);
} else {
$data = "empty";
}
echo "<hr>Awake flag (12310)\t$data<br>";

for ($i = 1; $i <= $NUMINV; $i++) {
$memid="1231".$i; // Live
@$shmid = shmop_open($memid, "a", 0444, 256);
if (!empty($shmid)) {
$shm_size = shmop_size($shmid);
$data = shmop_read($shmid, 0, $shm_size);
shmop_close($shmid);
} else {
$data = "empty";
}
echo "Live #$i ($memid) $data<br>";
}

for ($i = 1; $i <= $NUMINV; $i++) {
$memid="1232".$i; // pmotd
@$shmid = shmop_open($memid, "a", 0444, 32);
if (!empty($shmid)) {
$data = shmop_read($shmid, 0, 32);
shmop_close($shmid);
} else {
$data = "empty";
}
echo "Pmotd #$i ($memid)\t$data<br>";
}

@$shmid = shmop_open(12320, "a", 0444, 32);
if (!empty($shmid)) {
$data = shmop_read($shmid, 0, 32);
shmop_close($shmid);
} else {
$data = "empty";
}
echo "Pmotd multi (12320)\t$data<br>";

for ($i = 1; $i <= $NUMINV; $i++) {
$memid="1233".$i; // 5minflag
@$shmid = shmop_open($memid, "a", 0444, 1);
if (!empty($shmid)) {
$data = shmop_read($shmid, 0, 1);
shmop_close($shmid);
} else {
$data = "empty";
}
echo "5minflag #$i $memid\t$data<br>";
}

for ($i = 1; $i <= $NUMINV; $i++) {
$memid="1234".$i; // aw date, ileak,riso
@$shmid = shmop_open($memid, "a", 0444, 32);
if (!empty($shmid)) {
$data = shmop_read($shmid, 0, 32);
shmop_close($shmid);
} else {
$data = "empty";
}
echo "AWPeak #$i ($memid)\t$data<br>";
}

for ($i = 1; $i <= $NUMINV; $i++) {
$memid="1236".$i;
@$shmid = shmop_open($memid, "a", 0444, 256);
if (!empty($shmid)) {
$data = shmop_read($shmid, 0, 256);
shmop_close($shmid);
} else {
$data = "empty";
}
echo "Invt State #$i ($memid)\t$data<br>";
}

for ($i = 1; $i <= $NUMINV; $i++) {
$memid="1235".$i;
@$shmid = shmop_open($memid, "a", 0444, 16);
if (!empty($shmid)) {
$data = shmop_read($shmid, 0, 16);
shmop_close($shmid);
} else {
$data = "empty";
}
echo "MailQ #$i ($memid)\t$data<br>";
}

$memid="1230"; //Main cgf
@$shmid = shmop_open($memid, "a", 0444, 1024);
if (!empty($shmid)) {
$data = shmop_read($shmid, 0, 1024);
} else {
$data = "empty";
}
shmop_close($shmid);
echo "<br>
Main CFG ($memid)<br><hr>
SCRDIR: $SCRDIR<br>
NUMINV: $NUMINV<br>
NUMSMA: $NUMSMA<br>
AUTOMODE: $AUTOMODE<br>
DISTRO: $DISTRO<br>
DTZ: $DTZ<br>
LATITUDE: $LATITUDE<br>
LONGITUDE: $LONGITUDE<br>
DATEFORMAT: $DATEFORMAT<br>
DPOINT: $DPOINT<br>
THSEP: $THSEP<br>
TITLE: $TITLE<br>
SUBTITLE: $SUBTITLE<br>
KEEPDDAYS: $KEEPDDAYS<br>
AMOUNTLOG: $AMOUNTLOG<br><br>
  ";

for ($i = 1; $i <= $NUMINV; $i++) {
$invtnum=$i;
include("read_invtcfg.php"); //Load main constants
$memid="123".$i; // invt cfg
@$shmid = shmop_open($memid, "a", 0444, 1024);
if (!empty($shmid)) {
$shm_size = shmop_size($shmid);
$data = shmop_read($shmid, 0, $shm_size);
} else {
$data = "empty";
}
shmop_close($shmid);
echo "Invt Cfg #$i ($memid)<br><hr>
  INVNAME: $INVNAME<br>
  PLANT_POWER: $PLANT_POWER<br>
  CORRECTFACTOR: $CORRECTFACTOR<br>
  INITIALCOUNT: $INITIALCOUNT<br>
  STRING: $STRING<br> 
  PORT: $PORT<br>
  PROTOCOL: $PROTOCOL<br>
  DAEMONMODE: $DAEMONMODE<br>  
  ADR: $ADR<br> 
  COMOPTION: $COMOPTION<br>
  SYNC: $SYNC<br>  
  SKIPMONITORING: $SKIPMONITORING<br>
  DEBUG: $DEBUG<br>
  LOGCOM: $LOGCOM<br>
  YMAX: $YMAX<br>
  YINTERVAL: $YINTERVAL<br>
  PRODXDAYS: $PRODXDAYS<br>
  LOCATION: $LOCATION<br>
  PANELS1: $PANELS1<br>
  ROOF_ORIENTATION1: $ROOF_ORIENTATION1<br>
  ROOF_PITCH1: $ROOF_PITCH1<br>
  PANELS2: $PANELS2<br>
  ROOF_ORIENTATION2: $ROOF_ORIENTATION2<br>
  ROOF_PITCH2: $ROOF_PITCH2<br>
  ARRAY1_POWER: $ARRAY1_POWER<br>
  ARRAY2_POWER: $ARRAY2_POWER<br>
  EXPECTEDPROD: $EXPECTEDPROD<br>
  EXPECTJAN: $EXPECTJAN<br>
  EXPECTFEB: $EXPECTFEB<br>
  EXPECTMAR: $EXPECTMAR<br>
  EXPECTAPR: $EXPECTAPR<br>
  EXPECTMAY: $EXPECTMAY<br>
  EXPECTJUN: $EXPECTJUN<br>
  EXPECTJUI: $EXPECTJUI<br>
  EXPECTAUG: $EXPECTAUG<br>
  EXPECTSEP: $EXPECTSEP<br>
  EXPECTOCT: $EXPECTOCT<br>
  EXPECTNOV: $EXPECTNOV<br>
  EXPECTDEC: $EXPECTDEC<br>
";
  // EMAIL: $EMAIL<br>
echo"
  REPORT: $REPORT<br>
  PUSHO: $PUSHO<br>";
  // POUKEY: $POUKEY<br>
echo "
  AWPOOLING: $AWPOOLING<br>
  DIGESTMAIL: $DIGESTMAIL<br>
  FILTER: $FILTER<br>
  SENDALARMS: $SENDALARMS<br>
  SENDMSGS: $SENDMSGS<br>
  NORESPM: $NORESPM<br>
  VGRIDUT: $VGRIDUT<br>
  VGRIDT: $VGRIDT<br>
  VGRIDTM: $VGRIDTM<br>
  RISOT: $RISOT<br>
  RISOTM: $RISOTM<br>
  ILEAKT: $ILEAKT<br>
  ILEAKTM: $ILEAKTM<br>
  PVOUTPUT: $PVOUTPUT<br>";
  // APIKEY: $APIKEY<br>
echo "
  SYSID: $SYSID<br>
  PVOC: $PVOC<br><br>
";
}


function convert($size)
 {
    $unit=array('b','kb','mb','gb','tb','pb');
    return @round($size/pow(1024,($i=floor(log($size,1024)))),2).' '.$unit[$i];
 }
?>
