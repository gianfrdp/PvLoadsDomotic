<?php
//Load invt variables from memory

$systemid='123'.$invtnum;

$shmid = shmop_open($systemid, 'a', 0444, 1024);
$invt_data = shmop_read($shmid, 0, 1024);
shmop_close($shmid);
$invt_dataarray = preg_split('/;/', $invt_data);
  
// ### GENERAL FOR INVERTER #$invtnum
$INVNAME=$invt_dataarray[0];
// ### SPECS
$PLANT_POWER=$invt_dataarray[1];
$CORRECTFACTOR=$invt_dataarray[2];
$INITIALCOUNT=$invt_dataarray[3]; 
$STRING=$invt_dataarray[4];
// #### PROTOCOL
$PORT=$invt_dataarray[5];
$PROTOCOL=$invt_dataarray[6];
$DAEMONMODE=$invt_dataarray[7];
$ADR=$invt_dataarray[8];
$COMOPTION=$invt_dataarray[9];
$SYNC=$invt_dataarray[10];
$SKIPMONITORING=$invt_dataarray[11];
$DEBUG=$invt_dataarray[12];
$LOGCOM=$invt_dataarray[13];
  
// ### FRONT PAGE
$YMAX=$invt_dataarray[14];
$YINTERVAL=$invt_dataarray[15];
$PRODXDAYS=$invt_dataarray[16];
// ### INFO DETAILS
$LOCATION=$invt_dataarray[17];
$PANELS1=$invt_dataarray[18];
$ROOF_ORIENTATION1=$invt_dataarray[19];
$ROOF_PITCH1=$invt_dataarray[20];
$PANELS2=$invt_dataarray[21];
$ROOF_ORIENTATION2=$invt_dataarray[22];
$ROOF_PITCH2=$invt_dataarray[23];
// ### DASHBOARD
$ARRAY1_POWER=$invt_dataarray[24];
$ARRAY2_POWER=$invt_dataarray[25];
// ### EXPECTED PRODUCTION
$EXPECTEDPROD=$invt_dataarray[26];
$EXPECTJAN=$invt_dataarray[27];
$EXPECTFEB=$invt_dataarray[28];
$EXPECTMAR=$invt_dataarray[29];
$EXPECTAPR=$invt_dataarray[30];
$EXPECTMAY=$invt_dataarray[31];
$EXPECTJUN=$invt_dataarray[32];
$EXPECTJUI=$invt_dataarray[33];
$EXPECTAUG=$invt_dataarray[34];
$EXPECTSEP=$invt_dataarray[35];
$EXPECTOCT=$invt_dataarray[36];
$EXPECTNOV=$invt_dataarray[37];
$EXPECTDEC=$invt_dataarray[38];
// ### NOTIFICATION
$EMAIL=$invt_dataarray[39];
$REPORT=$invt_dataarray[40];
$PUSHO=$invt_dataarray[41];
$POUKEY=$invt_dataarray[42];
// ### ALARMS AND WARNINGS
$AWPOOLING=$invt_dataarray[43];
$DIGESTMAIL=$invt_dataarray[44];
$FILTER=$invt_dataarray[45];
$SENDALARMS=$invt_dataarray[46];
$SENDMSGS=$invt_dataarray[47];
$NORESPM=$invt_dataarray[48];
$VGRIDUT=$invt_dataarray[49];
$VGRIDT=$invt_dataarray[50];
$VGRIDTM=$invt_dataarray[51];
$RISOT=$invt_dataarray[52];
$RISOTM=$invt_dataarray[53];
$ILEAKT=$invt_dataarray[54];
$ILEAKTM=$invt_dataarray[55];
// ### PVOUTPUT.org 
$PVOUTPUT=$invt_dataarray[56];
$APIKEY=$invt_dataarray[57];
$SYSID=$invt_dataarray[58];
$PVOC=$invt_dataarray[59];
?>
