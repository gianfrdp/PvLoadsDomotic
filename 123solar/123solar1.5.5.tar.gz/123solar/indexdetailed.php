<?php 
include("styles/globalheader.php");
if(!empty($_POST['invtnum']) && is_numeric($_POST['invtnum'])) {
$invtnum=$_POST['invtnum'];
} else {
$invtnum=1;
}
include("scripts/read_invtcfg.php");

$dir = 'data/invt'.$invtnum.'/csv/';
$output = glob($dir . "*.csv");
sort($output);
$contalogs=count($output);

$ollog=$output[0];
$lstlog=$output[$contalogs-1];

$startdate=(substr($ollog,-12,4)).",".(substr($ollog,-8,2))."-1,".(substr($ollog,-6,2)); 
$stopdate=(substr($lstlog,-12,4)).",".(substr($lstlog,-8,2))."-1,".(substr($lstlog,-6,2)); 
$prefilldate=(substr($lstlog,-6,2))."/".(substr($lstlog,-8,2))."/".(substr($lstlog,-12,4));
?>
<script>
  $(function() {
    $( "#datepickid" ).datepicker({ dateFormat: 'dd/mm/yy' ,minDate: new Date(<?php echo $startdate;?>), maxDate: new Date(<?php echo $stopdate;?>)});
    });
</script>
<table border="0" cellspacing="0" cellpadding="5" width="40%" align="left">
<tr><td> 
<?php if ($NUMINV>1) {
echo "<form method='POST' action='indexdetailed.php'>
<select name='invtnum' onchange='this.form.submit()'>";
for ($i=1;$i<=$NUMINV;$i++) {
if ($invtnum==$i) {
echo "<option SELECTED value=$i>";
} else {
echo "<option value=$i>";
}
  echo "$lgINVT$i</option>";
    }
echo "</select></form>";
} ?>
</td><td>
<form method="POST" action="detailed.php" name="chooseDateForm" id="chooseDateForm" action="#">
<?php echo "$lgCHOOSEDATE";?> :&nbsp;
<input name="date1" id="datepickid" value="<?php echo $prefilldate;?>" size="7" maxlength="10">
</td></tr>
<tr><td><input type="checkbox" name="checkpower" value='on'><?php echo "$lgPOWERINSTANT";?></td><td><input type="checkbox" name="checkavgpower" value='on'><?php echo "$lgPOWERAVG";?> <img src="images/info10.png" width="10" height="10" border="0" title="<?php echo "$lgPOWERAVGINFO";?>"</td></tr>
<tr><td><input type="checkbox" name="checkPROD" value='on'><?php echo "$lgPROD";?></td><td><input type="checkbox" name="checkPEFF" value='on'><?php echo "$lgPEFF";?></td></tr>
<tr><td>
  <?php 
  echo "<input type='checkbox' name='checkI1P' value='on' ";
  if ($STRING==2) {
  echo "DISABLED";
  }
  echo ">$lgPOWER1";
  ?>
  </td>
  <td>
    <?php 
  echo "<input type='checkbox' name='checkI2P' value='on' ";
  if ($STRING==1) {
  echo "DISABLED";
  }
  echo ">$lgPOWER2";
  ?>
  </td>
</tr>
<tr>
  <td>
  <?php 
  echo "<input type='checkbox' name='checkPEFF1' value='on' ";
  if ($STRING==2) {
  echo "DISABLED";
  }
  echo ">$lgPEFF1";
  ?>
  </td>
  <td>
  <?php 
  echo "<input type='checkbox' name='checkPEFF2' value='on' ";
  if ($STRING==1) {
  echo "DISABLED";
  }
  echo ">$lgPEFF2";
  ?>
  </td>
</tr>
<tr>
  <td>
  <?php 
  echo "<input type='checkbox' name='checkI1V' value='on' ";
  if ($STRING==2) {
  echo "DISABLED";
  }
  echo ">$lgVOLTAGE1";
  ?>
  </td>
  <td>
  <?php 
  echo "<input type='checkbox' name='checkI2V' value='on' ";
  if ($STRING==1) {
  echo "DISABLED";
  }
  echo ">$lgVOLTAGE2";
  ?>
  </td>
</tr>
<tr>
  <td>
  <?php 
  echo "<input type='checkbox' name='checkI1A' value='on' ";
  if ($STRING==2) {
  echo "DISABLED";
  }
  echo ">$lgCURRENT1";
  ?>
  </td>
  <td>
  <?php 
  echo "<input type='checkbox' name='checkI2A' value='on' ";
  if ($STRING==1) {
  echo "DISABLED";
  }
  echo ">$lgCURRENT2";
  ?>
  </td>
</tr>
<tr>
  <td><input type="checkbox" name="checkGV" value='on'><?php echo "$lgGRIDVOLTAGE";?></td>
  <td><input type="checkbox" name="checkGA" value='on'><?php echo "$lgGRIDCURRENT";?></td>
</tr>
<tr>
  <td><input type="checkbox" name="checkFRQ" value='on'><?php echo "$lgFREQ";?></td>
  <td><input type="checkbox" name="checkEFF" value='on'><?php echo "$lgEFFICIENCYINVT";?></td>
</tr>
<tr>
  <td><input type="checkbox" name="checkINVT" value='on'><?php echo "$lgINVERTERTEMP";?></td>
  <td><input type="checkbox" name="checkBOOT" value='on'><?php echo "$lgBOOSTERTEMP";?></td>
</tr>
<tr><td align=center colspan=3><br>&nbsp;<input type="submit" value="   <?php echo $lgOK;?>   "></td></tr>
</table>
<input type="hidden" name="invtnum" value="<?php echo $invtnum; ?>"> 
</form>

<?php include("styles/".$user_style."/footer.php"); ?>
